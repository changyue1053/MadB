# Rust C/C++ 跨语言边界工程清单

整理日期：2026-10-23

**Rust ↔ C/C++ 的重点是把原生代码的隐含约束转换成可执行、可验证的安全契约。** 绑定生成解决声明和调用接线；所有权、借用、线程、回调退出、异常恢复与制品兼容需要另外设计。

范围包括 Rust 调用 C/C++、C/C++ 调用 Rust 导出，以及双向回调。保留已有 C ABI 路线，新增边界可控的 Rust/C++ 模块按需评估 CXX；更广的自动导入方案单独验证工具链与目标能力。本清单延续讨论中的四组、23 项问题，补充验收重点。

项目依据分别使用：旧 mad 的 IMLink 手写声明、MadDemo 的 IMLink 生成绑定与安全包装、仓内 IMDB C API、llama 后端的资源与线程声明。库中存在某个导出接口，不等于当前应用已在生产路径直接消费它。

配套决策：[Rust C/C++ 架构总结与新版 mad-boundary 设计输入](/Users/changyue/Desktop/mad设计/Rust_C_CPP/Rust_C_CPP_架构总结与新版_mad-boundary_设计输入.md)。

## 一 接口与数据

目标：保证权威声明、实际二进制与 Rust 类型表达一致。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **1. 两端重复维护声明** | 每条接口选择权威源，其他声明生成或编译校验；语义策略补充信息而不复制签名 | bindgen、cbindgen、CXX 静态检查、再生成检查 | 旧 mad 手写 Rust extern；MadDemo 从 mad_link.h 生成 sys.rs。[旧声明](/Users/changyue/Desktop/学习2/mad-kernel/libs/imlink-native/src/lib.rs:25)、[生成与检查](/Users/changyue/Desktop/MadDemo/tools/kernel.sh:23) | 参数、常量、事件结构、测试接口同步；生成物不手改；签名漂移在构建期阻断 |
| **2. Rust 类型与 C ABI 不等价** | 公共 C 接口限定为有明确 ABI 的值、指针和句柄；复杂 Rust/C++ 类型通过后端支持的包装表达 | repr(C)、不透明类型、受限 DTO、CXX 桥接 | repr(C) 不会改变内部字段自身的表示；不能据此外露任意 String、Vec 或 trait object 布局。[Rust 布局规则](https://doc.rust-lang.org/reference/type-layout.html) | 不把 Rust 默认布局当作稳定 ABI；区分 C API 的结构与 CXX 支持的专门映射；合法的特殊 Option 表示单独检查，不一概禁止或放行 |
| **3. 布局与目标配置不一致** | 将目标、宏、系统头、对齐和调用约定纳入生成输入；按承诺目标编译验证 | Clang AST、布局探针、sizeof/alignof/offsetof、编译断言 | MadDemo 原生事件约束大小、对齐和字段偏移；当前生成脚本采用特定宿主配置。[原生布局](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:73)、[生成参数](/Users/changyue/Desktop/MadDemo/tools/kernel.sh:23) | 一个宿主生成结果不自动覆盖任意目标；扩展平台、packing 或类型后重新证明兼容；ABI 不只比较 sizeof |
| **4. 非法数值直接进入 Rust 类型** | 在原始表示层接收整数，验证后构造领域 enum、bool、范围受限值和长度 | TryFrom、显式 match、未知值策略、受检算术 | IMLink 对关闭原因和返回码逐项转换，未知值有明确处理。[类型转换](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/src/lib.rs:31) | 不 transmute 未验证整数为 enum；覆盖负值、溢出、未知标志和未定义变体；错误码保留诊断信息 |
| **5. 字符串 切片与输出参数** | 明确编码、NUL、元素数/字节数、输出有效条件；先验证再构造安全引用；未初始化输出按协议处理 | CStr/CString、UTF-8 校验、MaybeUninit、容量检查、受检切片转换 | Rust 切片即使长度为 0 也要求非空且对齐的指针；C 的 NULL + 0 应专门转换为空切片。[切片要求](https://doc.rust-lang.org/std/slice/fn.from_raw_parts.html) | 检查范围、对齐、单一分配区、初始化与借用条件；失败时不 assume_init；set_len 不超过实际初始化范围；不把 C++ string 默认当 UTF-8 |

bindgen 主要生成底层类型和调用声明，不会自动赋予 C++ 对象正确的构造、移动和析构语义。部分 static/static inline 函数可通过生成 C 包装后再编译接入；不能据此推断任意 C++ 模板都可自动绑定。[C++ 支持范围](https://rust-lang.github.io/rust-bindgen/cpp.html)、[静态函数包装](https://rust-lang.github.io/rust-bindgen/faq.html)

## 二 内存与所有权

目标：让对象存活、地址有效、借用权限和关闭责任一致。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **6. 分配器与释放器不匹配** | 每类返回资源声明来源、接收方、转移点和释放函数；原分配方提供对应回收能力 | Rust Drop、C++ RAII、专用 deleter、配对 free | IMDB 返回 CString，并要求使用 imdb_string_free 归还。[实现与约束](/Users/changyue/Desktop/MadDemo/kernel/libs/imdb/crates/imdb-ffi/src/lib.rs:74) | 不混用 malloc/free、new/delete、Box/Vec/CString 的回收协议；失败与取消也成对；CString::from_raw 不接收任意 C 字符串 |
| **7. 借用超过有效期** | 同步调用只借用至返回；异步保留需要复制、转移或独立 owner；指针有效期绑定实际存储 | 生命周期包装、拥有型缓冲区、操作保活 | IMLink 声明输入在返回前复制，Rust 包装据此借用切片。[输入契约](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:1)、[调用处](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/src/lib.rs:122) | C++ 不保存已结束的 Rust 借用；Vec 扩容、释放或移动其相关存储后不使用旧地址；Future 结束不自动结束原生借用 |
| **8. C++ 修改破坏 Rust 别名规则** | 依据真实共享关系表达引用、原始指针或内部可变性；同步必须覆盖两端访问 | 小范围 unsafe、受限访问 API、锁、必要的 UnsafeCell 封装 | from_raw_parts 得到的共享切片在借用期间不得被外部任意修改。[借用条件](https://doc.rust-lang.org/std/slice/fn.from_raw_parts.html) | Rust 存在 &T/&[T] 时，C++ 不通过另一入口任意写入；不同时形成冲突的 &mut；UnsafeCell 不是自动同步机制 |
| **9. C++ 对象的移动与析构语义** | 非平凡对象通过间接持有操作；由正确语言执行构造、移动和析构；不能只按字节复制 | CXX UniquePtr、Pin、opaque 类型、C 包装 | bindgen 不自动调用 C++ 特殊成员；CXX 对不透明 C++ 可变访问使用 Pin 等约束。[bindgen 限制](https://rust-lang.github.io/rust-bindgen/cpp.html)、[CXX 约束](https://cxx.rs/extern-c++.html) | 自引用对象不能因 Rust 普通移动失效；不随意 derive Copy/Clone；Pin 不替代线程安全、外部对象存活或内部容器有效期 |
| **10. 父子资源释放顺序** | 将资源依赖编码到持有关系或生命周期；区分所有权、共享引用与关闭权限 | Arc、借用生命周期、组合 owner、明确释放顺序 | llama ContextHandle 持有 Arc<ModelHandle>，表达模型晚于上下文释放。[资源依赖](/Users/changyue/Desktop/MadDemo/kernel/libs/iminfer/crates/iminfer-backend-llama/src/sys.rs:272) | 子资源使用期间父资源不释放；共享引用不产生多个关闭责任者；跨 Rust/C++ 强引用环可被打断 |
| **11. 关闭 句柄与在途调用竞争** | 关闭先停止准入，再停止或等待工作，最后释放；可重用句柄需防止旧值命中新对象 | 关闭状态机、调用许可、句柄代次、停止确认、最终回收 | IMLink 通过 Arc<Native> 保活，Engine 停止派发，最终 Drop 释放原生引擎。[安全包装](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/src/lib.rs:156) | 检查 closed 与实际使用不能存在无保护窗口；重复关闭安全；析构线程合法；仍有对象或回调时不卸载代码 |

判空、范围检查和布局验证不能证明任意外部地址就是合法分配。Box::from_raw、Vec::from_raw_parts 等操作还要求满足来源、布局、容量和唯一回收责任；不得把这些函数当作任意裸指针的安全修复器。

## 三 多线程 异步与回调

目标：分别证明线程能力、任务结束、结果交付与回调退出。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **12. 无依据地声明 Send/Sync** | 分别证明可跨线程转移和可并发共享；约束销毁线程、隐藏可变状态与原生全局状态 | 安全论证、受限方法、线程断言、并发测试 | llama 对 model 声明 Send/Sync，对 context 只声明 Send；CXX 不默认给不透明 C++ 类型这些标记。[项目代码](/Users/changyue/Desktop/MadDemo/kernel/libs/iminfer/crates/iminfer-backend-llama/src/sys.rs:126)、[CXX](https://cxx.rs/extern-c++.html) | 不因指针可复制就生成 Send/Sync；“const 方法”不自动证明线程安全；上游实现改变后重新验证 |
| **13. 回调上下文提前释放** | 回调注册拥有明确的 context 保活责任；区分取消注册与在途回调退出；失败也必须清理 | 注册对象、引用计数、回调代次、退出确认 | IMDB 观察接口创建泵线程，user_data 由回调使用，接口需要明确安全释放时刻。[观察实现](/Users/changyue/Desktop/MadDemo/kernel/libs/imdb/crates/imdb-ffi/src/lib.rs:595) | 注册失败、同步首回调和注销竞争都安全；不能在每次回调里重复 Box::from_raw 消耗同一 owner；确认退出前不释放 context |
| **14. Future 丢弃与原生工作不一致** | 分开定义停止等待、停止观察、原生取消和副作用处理；保留后台收尾责任 | 操作状态机、native cancel/stop、可等待的停止确认 | llama 后端明确取消在词元间检查，不能据此承诺单次 decode 内即时中断。[后端约束](/Users/changyue/Desktop/MadDemo/kernel/libs/iminfer/crates/iminfer-backend-llama/src/sys.rs:1) | Future drop 不被当作原生停止证明；超时后输入仍按需存活；阻塞原生调用的取消粒度准确 |
| **15. 完成认领与结果投递竞争** | 先登记再启动；统一终态认领；等待者消失时，结果仍有明确回收者 | 单次完成通道、状态机、结果 owner、交错测试 | 场景：接收方取消后 C++ 才返回图像，投递失败不能泄漏或重复释放 | 覆盖同步完成、重复通知、注册失败与迟到结果；重复通知的资源是同一对象还是独立转移必须明确；不只依赖一次 is_cancelled 检查 |
| **16. 回调重入 锁顺序与死锁** | 默认不持业务锁调用外部代码；明确回调中允许的方法；关闭不能等待当前回调自己退出 | 锁顺序、分阶段操作、异步投递、重入测试 | 场景：Rust 持锁调 C++，C++ 同步回调 Rust，再请求同一把锁或执行关闭 | 不靠递归锁掩盖错误生命周期；回调异常有边界；析构与 join 不造成环形等待 |
| **17. 阻塞 高频事件与背压** | 原生阻塞工作使用受控线程；事件按需批量化；声明队列容量、顺序和恢复策略 | 专用线程、阻塞执行池、有界队列、批量 poll | IMLink C++ 维护事件队列，Rust 派发线程成批处理，并校验载荷长度。[派发实现](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/src/lib.rs:227) | 不在异步执行器工作线程上长时间阻塞；满队列有确定行为；有限缓冲不自动形成生产者流控；关键事件不静默丢失 |

线程串行不等于固定 OS 线程；Arc 和 shared_ptr 主要管理存活期，不证明被引用对象可并发使用。安全 Rust API 必须准确反映原生约束，不能只把 unsafe 藏到库内部就宣布完成。

## 四 异常 构建与交付

目标：明确失败边界，让声明、运行语义和实际制品一致。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **18. panic 与 C++ exception 越界** | 按后端声明展开与错误策略；默认在所属语言内捕获并转换；C-unwind 作为单独受验证协议 | catch_unwind、C++ try/catch、CXX Result 映射 | IMLink 包装将部分 C++ 入口异常转换为内部错误；Rust 工作区固定 unwind 策略。[C++ 边界](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/bridge.cc:18)、[panic 配置](/Users/changyue/Desktop/MadDemo/kernel/Cargo.toml:56) | panic=abort 不被当作可捕获；catch_unwind 不用来可靠捕获外部 C++ 异常；释放和错误查询路径也审查；普通 Result 与 panic 分开 |
| **19. 捕获失败后的状态损坏** | 区分业务错误、对象失效和进程级故障；对部分修改规定回滚、隔离或停止 | poisoned 状态、事务式更新、对象重建、失败策略 | 旧 mad 的 C ABI 防火墙区分普通 panic 与全局锁中毒；IMDB 提供独立 panic 错误码。[旧 mad 策略](/Users/changyue/Desktop/学习2/mad-kernel/crates/im-core-cabi/src/lib.rs:59)、[IMDB guard](/Users/changyue/Desktop/MadDemo/kernel/libs/imdb/crates/imdb-ffi/src/lib.rs:116) | 返回错误码不等于恢复一致性；AssertUnwindSafe 不是恢复证明；错误处理自身不引入未约定的二次失败 |
| **20. 编译和原生运行库不一致** | 将编译器、目标、宏、异常开关、标准库、链接模式与传递依赖纳入构建身份 | Cargo、CMake/cc、工具链锁、依赖清单、nm/readelf/otool | llama build.rs 按目标选择构建参数，并支持经过检查的预编静态库。[构建入口](/Users/changyue/Desktop/MadDemo/kernel/libs/iminfer/crates/iminfer-backend-llama/build.rs:1) | 正确链接 C++ runtime；跨端与 Release 真正消费；重复静态库不生成互相独立的全局状态；LTO/插桩能力按工具链验证 |
| **21. API ABI 与行为漂移** | 绑定、声明、原生库配套交付；独立比较签名、布局、导出符号和行为协议 | 再生成检查、基线、旧消费者、manifest、接口版本 | IMLink 生成物入库并做零差异检查；这只是完整兼容验证的一部分。[检查脚本](/Users/changyue/Desktop/MadDemo/tools/kernel.sh:58) | 返回阶段、线程、取消和关闭语义改变也进入审查；extern C 不等于任意二进制都兼容；CXX 桥不自动形成长期独立 ABI 承诺 |
| **22. 零拷贝与细粒度调用成本** | 先量化真实跨界次数、复制量和资源保留成本；优先优化批量及数据形状 | 端到端基准、分配/复制计数、延迟与峰值内存预算 | IMLink 已采用批量派发；无需为了追求零拷贝削弱其明确的输入复制协议。[派发接口](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/src/lib.rs:65) | 不用空函数基准替代业务负载；借用导致长期保留的大缓冲计入成本；生命周期与性能同时验收 |
| **23. 测试只覆盖单侧或错误目标** | 建立真实双向消费者、边界值、故障注入和可控交错；记录工具与插桩覆盖 | Rust/C/C++ 集成测试、适用的 Sanitizer、模糊测试、Miri、符号化 | IMLink 暴露专门测试钩子；Miri 对任意外部原生调用存在能力边界。[测试接口](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link_test.h:1)、[Miri](https://github.com/rust-lang/miri) | 模拟通过不等于真实 FFI 通过；覆盖原生消费者和目标设备；符号匹配产物；未执行、不支持、失败与通过分开 |

异常规则需要逐条记录：

| 场景 | 采用的口径 |
|---|---|
| 普通 C ABI | 业务失败使用显式结果；异常不应意外穿越边界 |
| panic=abort | panic 终止进程，catch_unwind 不能转换它 |
| extern C-unwind | 允许约定的展开路径，不自动变成 Result，也不修复对象状态 |
| CXX 中声明为 Result 的函数 | 按 CXX 的异常转换规则工作；默认 C++ 捕获范围与异常类别需要核对 |
| CXX 的 Rust 导出发生未处理 panic | CXX 会终止进程，不自动变成普通 Err |
| catch_unwind 捕获 foreign exception | 不能作为可靠的跨语言异常处理方案 |

依据：[FFI 展开规则](https://doc.rust-lang.org/nomicon/ffi.html#ffi-and-unwinding)、[catch_unwind](https://doc.rust-lang.org/std/panic/fn.catch_unwind.html)、[CXX Result](https://cxx.rs/binding/result.html)。

## mad-boundary 的职责划分

- **契约与能力模型**：记录方向、后端、支持子集和所有权、借用、线程、异常及关闭协议。
- **声明读取与生成适配**：对接 bindgen、cbindgen、CXX 等工具；绑定类型与真实构建上下文关联。
- **安全包装与运行原语**：根据明确协议实现资源、回调、操作、取消和结果回收；复用已有 owner。
- **验证与交付**：管理双向消费者、兼容基线、测试证据、性能与原生依赖。
- **SDK 作者**：确定领域模型和公开能力，证明 unsafe 前提，决定 Send/Sync、恢复策略及原生同步协议。

## 通用规则需要统一的口径

| 容易误用的说法 | 采用的口径 |
|---|---|
| bindgen 与 cbindgen 是同一个生成器的两个模式 | 两者读取不同的权威源，分别生成 Rust 声明和 C/C++ 头 |
| cbindgen 将普通业务代码自动变成完整 C SDK | 需要已有导出 API，工具主要生成声明 |
| repr(C) 让所有字段都能跨语言 | 内部字段表示、值有效性、所有权和调用约定仍需验证 |
| 指针非空且长度合理就安全 | 地址有效、分配来源、初始化、别名与存活期仍是前提 |
| CXX 自动证明任意 C++ 代码安全 | 它约束桥接与类型；原生行为和线程能力仍需要依据 |
| Pin 解决线程安全和全部地址问题 | Pin 主要约束相应值的移动，不等于共享状态同步或所有内部地址都稳定 |
| Future drop 就是 native 取消完成 | 等待者、原生操作与回调上下文分别管理生命周期 |
| Arc/shared_ptr 保证对象线程安全 | 它们管理引用存活，不能代替被引用对象的同步 |
| catch_unwind 是内存安全防火墙 | 它处理特定 panic 展开，不能恢复 UB、任意崩溃或所有原生异常 |
| 所有 inline 都必须手写包装 | 部分 static/static inline 可由 bindgen 包装；其他情况按实际能力评估 |
| autocxx 仍适合默认新项目选型 | 官网已标记不再积极维护，新接入优先评估其他可维护路线 |
| Miri 通过等于真实 C++ 边界安全 | 原生代码、平台和双向调用仍需要独立验证 |

autocxx 的维护状态依据其当前[官方说明](https://google.github.io/autocxx/)；工具能力和支持矩阵在升级时重新核对。

