# Kotlin/Native Swift 架构总结与新版 mad-boundary 设计输入

整理日期：2026-10-23

**新版 mad-boundary 应复用 Kotlin/Native 的导出能力和成熟协程桥，重点补齐契约、受限适配、生命周期协议与真实 Swift 消费验证。** 设计时分别决定导出路线、模型表示、异步语义、资源归属和交付方式。

范围是 **Kotlin/Native ↔ Swift**：Swift 调用 Kotlin SDK、Kotlin 调用 Swift 提供的宿主能力，以及双方的回调和异步交互。以 mad / MadDemo 的 iOS 工程为案例；其他 Apple 平台需要各自的目标与消费测试。

本文作为新版 mad-boundary 的设计输入，沿用 Kotlin ArkTS 总结的结构。配套明细为 [Kotlin Swift 跨语言边界工程清单](/Users/changyue/Desktop/mad设计/Kotlin_Swift/Kotlin_Swift_跨语言边界工程清单.md)，覆盖六组、24 项问题。

## 1 已明确的架构结论

| 结论 | 对新设计的要求 |
|---|---|
| **导出路线必须区分** | Objective-C 导出与官方 Swift export 使用不同的类型、异步和交付能力表 |
| **跨语言传递不要求 JSON** | 常规 SDK 使用类型化调用；仅在持久化、网络协议或明确的动态载荷需求下选择序列化 |
| **模型转换按需求增加** | 先评估直接使用导出类型；需要改善调用方式时加 Facade，需要独立值语义时再做快照 |
| **协程桥有明确责任方** | 同一公开接口的取消和订阅由选定桥接方案负责，避免重复转换与重复订阅 |
| **双向调用分别验证** | 导出 Kotlin API、实现宿主接口、导入 Swift 库是不同能力 |
| **单一所有权明确关闭责任** | 多个引用可以共存；取消观察、释放引用和关闭底层资源分别定义 |
| **语法易用性与运行安全分别验证** | `async`、Swift `struct`、`Sendable` 标注或属性封装器，都不能单独证明完整边界协议正确 |

### 1.1 导出路线与组合方式

| 路线 | 主要能力 | 选型与限制 |
|---|---|---|
| **Kotlin/Native Objective-C 导出** | 生成 framework 和 ObjC 接口，经 Swift importer 使用 | 适合受支持的接口形状；原生 `async` 调用外观本身不补齐协程取消 |
| **ObjC 导出加 SKIE** | 改善 enum / sealed 的使用体验，将受支持的 `suspend` / Flow 接入 Swift Concurrency | 适合以 `async/await`、`AsyncSequence` 为主的接入；仍需处理值类、资源及业务语义 |
| **ObjC 导出加 KMP-NativeCoroutines** | 根据注解生成协程桥，提供 Async、Combine、RxSwift 接口 | 适合需要这些消费方式的项目；普通类型导出仍由 Kotlin/Native 等机制处理 |
| **SKIE 与 KMP-NativeCoroutines 组合** | 保留 SKIE 的类型增强，由另一套工具负责协程 | 必须配置功能分工、固定版本并验证组合；例如关闭 SKIE 的协程互操作 |
| **官方 Swift export** | 直接生成 Swift 接口，支持可空基本类型、enum / sealed、`suspend` 和 Flow 等映射 | 当前为 Alpha，仅支持直接集成；类形状、泛型等仍有限制，单独作为候选后端验证 |

依据：[ObjC 互操作](https://kotlinlang.org/docs/native-objc-interop.html)、[SKIE sealed 包装](https://skie.touchlab.co/features/sealed)、[SKIE Flow](https://skie.touchlab.co/features/flows)、[KMP-NativeCoroutines](https://github.com/rickclephas/KMP-NativeCoroutines)、[SKIE 协程开关](https://skie.touchlab.co/configuration/coroutines)、[官方 Swift export](https://kotlinlang.org/docs/native-swift-export.html)。

**MadDemo 当前案例路线是 ObjC 导出加 SKIE。** `MadKit` 通过静态 framework 导出多个模块，Swift 会话页使用 `SkieSwiftStateFlow(presenter.uiState)` 观察状态。[导出配置](/Users/changyue/Desktop/MadDemo/app/mad/build.gradle.kts:85)、[Swift 消费入口](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:44)

KMP-NativeCoroutines 已提供面向 Swift export 的兼容模式，但其说明仍列出 `NativeSuspend` / `NativeFlow` 的限制；兼容模式与原有 ObjC 桥的实现、取消表现并不相同。该组合必须作为独立支持项，不能沿用旧测试结论。[兼容与迁移说明](https://github.com/rickclephas/KMP-NativeCoroutines/blob/master/SWIFT_EXPORT.md)

### 1.2 三种模型使用方式

| 方式 | 运行时路径 | 适用场景与工具职责 |
|---|---|---|
| **直接使用导出类型** | Kotlin 对象 → 导出桥 → Swift 使用导入类型 | 已有模型适合公开；复用编译器和桥接工具，避免重复模型 |
| **薄 Facade 或辅助函数** | 导出类型 → 少量 Swift 封装或 Kotlin 辅助方法 | 改善命名、操作入口、ID 读取或局部类型限制；不要求整对象复制 |
| **独立 Swift 快照** | Kotlin 对象 → 受支持的导出表示 → Swift 原生值模型 | 明确需要独立模型、受控并发传递、原生协议或独立 API 演进；生成受限字段映射 |

**桥接时的表示转换，不等于必须再维护一套业务模型。** 例如 MadDemo 的 `MessageRow` 已是 UI 投影，Swift 直接持有 `[MessageRow]`；可空 `MessageSeq` 不方便使用时，通过 Kotlin `seenAction(row)` 构造动作即可，不必复制全部模型。[模型定义](/Users/changyue/Desktop/MadDemo/feature/conversation/api/src/commonMain/kotlin/com/mad/feature/conversation/api/ConversationContract.kt:36)、[辅助函数](/Users/changyue/Desktop/MadDemo/shell/ios/src/iosMain/kotlin/com/mad/shell/ios/NativeActions.kt:6)

需要独立快照时，生成器应按字段检查可空性、范围、集合及嵌套对象。若源类型无法直接导出，再增加 Kotlin 导出投影；若已有合适投影，就直接生成 Swift 转换。快照在源对象的隔离或锁协议下形成，保证字段读取的一致性；源数据后续变化需发布新快照，修改 Swift 快照也不会自动写回 Kotlin。

Swift `struct` 内包含 Kotlin 引用时，仍可能共享原对象；只有转换范围内的数据满足独立性与并发要求，才能承诺快照或声明相应协议。

SKIE 的 sealed 包装 enum 内可以携带原 Kotlin 对象，因此它主要改善穷尽匹配，不等于独立 DTO 或深拷贝。[实现方式](https://skie.touchlab.co/features/sealed)

### 1.3 反向宿主调用

常用方式是由 Kotlin 定义宿主接口，Swift 实现导出后的协议并注入 Kotlin；调用和回调经过同一套互操作设施。另一路径是把 Swift 能力暴露为 Objective-C 可见接口，再由 Kotlin/Native 导入。两者都需约定错误、执行器、保活和关闭责任。

纯 Swift 模块不能因此被视为可任意导入 Kotlin。官方 Swift export 解决 Kotlin 的导出，不等于所有 Swift 类型、Actor、AsyncSequence 都能反向自动映射。[官方导入范围](https://kotlinlang.org/docs/native-objc-interop.html#importing-swift-objective-c-libraries-to-kotlin)、[SKIE 反向 Flow 限制](https://skie.touchlab.co/features/flows)

## 2 新方案必须覆盖的问题范围

原有 24 项清单归纳为九组，用于确定模块职责和验收范围。

| 问题组 | 必须明确的内容 | 工具或手段 |
|---|---|---|
| **公开接口与类型** | 导出面、名称、值类、可空值、泛型、enum / sealed、ID 与数值范围 | 导出能力检查、类型编译探针、受限映射、API 基线 |
| **模型与输入** | 引用还是快照、比较规则、字段约束、快照一致性、更新是否回写 | Facade、受检构造器、映射规则、字段级测试 |
| **错误与异步** | 空结果、业务失败、取消、异常；同步回调、重入、重复或迟到完成 | 类型化结果、NSError 适配、协程桥、一次完成状态机 |
| **状态与事件** | 冷热流、订阅次数、回放、顺序、背压、丢弃、确认、受理与完成 | StateFlow / SharedFlow、队列与 ack、共享订阅策略、契约测试 |
| **所有权与生命周期** | 创建、持有、借用、关闭、在途任务、页面与账户作用域 | 显式关闭、取消登记、必要的保活、生命周期适配、泄漏诊断 |
| **线程与并发** | Kotlin Dispatcher、Swift Actor、回调执行器、共享状态同步、阻塞 I/O | MainActor、隔离审查、Mutex / 串行执行器、运行时断言、竞态测试 |
| **UI 与性能** | 输入回声、组合输入、列表身份、跨界频率、集合及字节复制 | revision、UIKit / SwiftUI 适配、批量与增量接口、Instruments |
| **兼容与交付** | 工具链组合、依赖导出、多 framework、API / ABI / 行为兼容、目标切片 | 版本锁、依赖检查、Swift 消费编译、XCFramework / SwiftPM、制品 manifest |
| **验证与诊断** | 正反调用、取消与关闭竞态、Release、真实设备、异常栈与符号 | XCTest / Swift Testing、故障注入、CrashKiOS、dSYM 配对、证据记录 |

以下约束需要写入契约与验收：

- **错误不能被空值吞掉。** ObjC 导出路径中，`@Throws` 只允许指定的 Kotlin 异常按规则传播；其他异常可能终止进程。Swift `throws` 的反向导入也不能假定自动变成 Kotlin 异常。[异常映射](https://kotlinlang.org/docs/native-objc-interop.html#errors-and-exceptions)
- **取消不能替代副作用协议。** 分开定义停止观察、停止等待、请求停止工作和撤销操作；取消后结果未知时，查询、幂等与补偿由领域层决定。
- **完成与取消之间必须处理资源交接。** continuation 已接收资源但调用方尚未恢复时仍可能取消；只检查 `isActive` 不足以保证资源有人接管。[及时取消与资源交接](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines/suspend-cancellable-coroutine.html)
- **状态流不能充当可靠事件日志。** StateFlow 按相等性合并，慢消费者可能跳过中间状态；需要逐条确认的事件应声明独立交付协议。[StateFlow 语义](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines.flow/-state-flow/)
- **Flow 错误与取消按后端建模。** SKIE 对 Flow 自定义异常传播存在限制，可能导致崩溃；可恢复错误要使用明确的状态或错误通道。[SKIE 限制](https://skie.touchlab.co/features/flows)
- **ARC 与 GC 不提供业务关闭时限。** 解除跨运行时引用环，确定性资源显式关闭；析构线程与回收延迟按实际机制处理，不能把正常回收一律报成泄漏。[ARC 与 GC](https://kotlinlang.org/docs/native-arc-integration.html)
- **并发安全覆盖两侧访问。** Swift Actor 不能约束绕过它的 Kotlin 访问；挂起后应重验状态或版本。`@unchecked Sendable` 和 `@preconcurrency` 不代替同步协议。[Actor 隔离与重入](https://github.com/swiftlang/swift-evolution/blob/main/proposals/0306-actors.md)
- **关闭超时不授权提前释放。** 在途调用仍可能使用对象；应区分关闭已完成、仍在进行、已放弃，并保留对应的内存安全条件。

## 3 工具生态在新架构中的位置

| 工具或机制 | 负责什么 | mad-boundary 补充什么 |
|---|---|---|
| **Kotlin/Native 编译器与 cinterop** | 导出 Kotlin，导入受支持的原生接口，完成基础互操作 | 导出面检查、双向能力探针、版本与目标约束 |
| **SKIE** | 改善 Swift 使用体验，桥接受支持的类型与协程 | 配置生成、组合准入、语义适配、真实消费测试 |
| **KMP-NativeCoroutines** | 生成协程桥，接入 Async / Combine / RxSwift | Scope 绑定、订阅生命周期、错误分类与组合验证 |
| **Swift export** | 官方直接 Swift 导出及其内置映射 | 独立后端能力表、限制诊断、迁移与行为回归 |
| **KSP 或受支持的编译器前端** | 读取 Kotlin 声明，供自定义生成器分析 | 只生成语言桥未覆盖且可机械推导的适配；核对最终导出结果 |
| **Swift extension、属性封装器、宏** | 提供惯用 API、状态观察入口或局部代码生成 | 显式关联作用域、执行器及清理；支持条件由生成规则检查 |
| **UIKit / SwiftUI 状态与生命周期机制** | 页面显示、观察、任务管理和界面更新 | 跨语言订阅模板、可见性策略、账户切换接线 |
| **Gradle、Xcode、SwiftPM** | 构建、链接、打包与消费 | 依赖顺序、工具链锁、生成物漂移和 SDK 制品配对 |
| **测试、分析与诊断工具** | 编译验证、运行测试、性能测量和崩溃定位 | 统一场景、阈值、失败分类与证据格式 |

KMP-NativeCoroutines 的 Combine / RxSwift 接口按订阅启动相应工作，取消句柄需绑定到消费作用域。不能因为 API 返回 Publisher 或 Observable，就默认多个订阅共享一次操作。[使用说明](https://github.com/rickclephas/KMP-NativeCoroutines)

SKIE 也提供 Combine 预览功能，不能将其描述为“完全不支持 Combine”。其 Future 扩展有立即启动和取消方面的限制，必须按具体适配器验证，不能把不同工具的 Future 当作同一协议。[SKIE Combine](https://skie.touchlab.co/features/combine)

属性封装器适合简化状态读取或订阅登记；涉及网络发送、删除、支付等副作用时，继续暴露明确的动作方法。**开发者可以不处理桥接细节，但需要看得懂何时启动、何时取消、谁负责关闭。**

## 4 mad 与 MadDemo 的工程经验

| 工程案例 | 应沉淀的规则或测试 |
|---|---|
| **可空值类导致 Swift 调用编不过**：MadDemo 的 `MessageSeq?` 与非空参数导出形状不一致 | 检查具体签名，支持局部辅助方法；用真实 Swift 编译探针覆盖可空与非空两条路径。[复盘](/Users/changyue/Desktop/MadDemo/docs/progress/S4.md:73) |
| **接口上的 StateFlow 仍需包装**：会话页显式创建 `SkieSwiftStateFlow` | 依据实际导出类型生成接线；不要假设启用 SKIE 后所有调用位置都无需适配。[代码](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:44) |
| **ID 比较依赖字符串描述**：消息、已读和提示去重使用插值 | 定义稳定 raw value 与比较规则；生成强类型 ID 的便捷读取，避免把调试输出作为公开协议。[代码](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:81) |
| **输入状态回声会覆盖新编辑**：会话页用 `draftRevision` 和 `markedTextRange` 保护输入 | 提供状态接入模板；草稿何时清空、受理代表什么由业务契约决定。[代码](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:70) |
| **页面隐藏与对象释放不同**：会话页在 `viewDidLoad` 开始订阅，在 `deinit` 取消 | 用实际钩子判断作用域；需要隐藏即暂停时，另接可见性生命周期，不能把析构当作隐藏通知。[代码](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:40) |
| **切号需要关闭顺序**：先等待界面树卸载，再清 ViewModel，最后关账户域；等待有上限 | 测试卸载超时和迟到回调；页面适配器只取消自身观察，账户 owner 负责底层关闭。[代码](/Users/changyue/Desktop/MadDemo/shell/common/src/commonMain/kotlin/com/mad/shell/common/AccountSession.kt:20) |
| **nil 与失败可能混淆**：mad 使用 ObjC Adapter 实现可空返回及 NSError 协议 | 明确“键不存在”和“读取失败”，针对 Swift 实现宿主协议的形状做反向消费测试。[桥接头](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ios/Sources/MadObjCBridge/include/MADDurableStoreBridge.h:4) |
| **同一接口有同步与异步回调**：mad 安全存储校验失败直接回调，其余路径进入队列 | 验证注册期间完成、重入、线程切换和重复完成；不假定回调总在方法返回后发生。[代码](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ios/Sources/MadShellKit/HostSecureKeyStore.swift:63) |
| **取消需要接到底层**：mad HTTP 适配调用 `URLSessionTask.cancel()` 并检查迟到回调 | 把底层取消接线列入验收；单次回调假设与结果资源交接分别测试。[代码](/Users/changyue/Desktop/学习2/mad-platform/products/mad/assembly/src/iosMain/kotlin/com/mad/product/mad/assembly/IosHttpTransport.kt:36) |
| **加锁不会改变执行线程**：mad 配置存储同步写盘，部分调用来自 UI 协程 | 独立检查阻塞 I/O 与隔离协议；不能用锁或 Sendable 标注代替调度。[代码](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ios/Sources/MadShellKit/HostConfigServices.swift:24) |
| **字节转换产生逐元素调用**：mad 的 ByteArray 与 Data 转换逐字节复制 | 建立大数据基准，再选择批量复制或有明确生命周期的缓冲协议。[代码](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ios/Sources/MadShellKit/KotlinByteArray+Data.swift:4) |
| **插件与构建环境会破坏接入**：SKIE 类加载器冲突、fork 版本不兼容，SwiftPM 提前解析不存在的 XCFramework | 锁定组合，明确构建依赖，运行全新环境消费测试。[插件复盘](/Users/changyue/Desktop/MadDemo/docs/plan/07-risks.md:31)、[构建复盘](/Users/changyue/Desktop/MadDemo/docs/progress/S6.md:135) |
| **本机可用不代表分发可用**：x86_64 消费曾缺少 SKIE 模块；API 基线仅做文本 diff | 平台与架构分别验收；文本变化、源码兼容和二进制兼容分开判断。[切片复盘](/Users/changyue/Desktop/MadDemo/docs/progress/S2.md:60)、[基线说明](/Users/changyue/Desktop/MadDemo/abi-baseline/README.md:3) |

这些案例对应不同层次：类型导出问题可以通过生成和编译探针尽早发现；取消、关闭和同步需要运行协议与竞态测试；草稿受理、重试和恢复仍属于领域决策。

## 5 新版 mad-boundary 的模块职责建议

| 模块 | 单一职责 | 主要输入与输出 |
|---|---|---|
| **契约模型与能力检查** | 描述接口、调用方向、类型形状、语义、所有权及支持范围 | 源声明、行为策略、后端能力 → 契约视图与缺口 |
| **导出后端适配** | 接入 ObjC export、SKIE、KMP-NativeCoroutines、Swift export，检查组合 | 后端选择与工具链身份 → 导出任务、实际接口视图 |
| **类型投影与代码生成** | 生成必要的辅助方法、受限 Facade、快照转换及校验 | 类型视图与映射规则 → Kotlin / Swift 代码、来源摘要 |
| **运行时协议适配** | 执行声明过的回调、订阅、取消、调度、资源交接和关闭协议 | 成熟桥接能力与行为策略 → 受控任务、订阅及资源适配 |
| **语言 API 与 UI 集成** | 提供惯用 Swift 接口，将观察关系绑定 UIKit / SwiftUI 生命周期 | 状态、动作、生命周期 → UI 适配器与接入模板 |
| **验证与诊断** | 检查类型、API、竞态、真实消费和性能，输出结论与证据缺口 | 契约、生成物、场景、制品 → Findings、Gaps、测试证据 |
| **构建与交付** | 固定工具链与输入，管理生成物、目标切片、符号和 SDK 分发 | 构建计划、依赖锁、验证结果 → 可追溯 SDK 制品 |

这些是职责模块，可以映射到现有 `model/rules`、Reader、Generator、Verifier、Toolchain、`sdk/runtime` 和 UI adapter，不要求每项都建立独立运行时或独立仓库。[当前模块边界](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)

设计原则落实为以下约束：

- **单一职责与依赖倒置**：契约、能力判定和规则保持纯数据与纯函数，Gradle、Xcode 和文件操作留在适配器。
- **Adapter 与 Strategy**：用窄接口接入导出和协程后端；支持组合显式登记，不建立接管所有功能的万能后端。
- **Facade**：只隐藏重复转换与接线，保留受理、取消和关闭的可见语义。
- **状态机**：管理注册、完成、取消、关闭的合法转移；状态必须对应可测试的实际保证。
- **组合优于继承**：复用后端的取消和引用管理，不额外创建第二个底层资源 owner。
- **最小公开面与整洁代码**：小接口、明确命名、集中错误分类；生成文件与手写扩展分离，生成区可确定性重建。

## 6 自动生成与手写的分界

| 内容 | 工具承担 | 开发者决定或实现 |
|---|---|---|
| **导出与类型** | 支持检查、名称适配、受限字段映射、数值和可空校验 | 公开哪些模型，ID、单位、默认值、未知变体的含义 |
| **异步接线** | 调用选定协程桥，生成取消、回调和订阅适配 | 任务归属，取消能停止什么，操作何时算受理或完成 |
| **所有权** | 执行保活、关闭准入、清理登记和约定的释放协议 | 谁关闭、是否等待在途任务、借用期、底层资源实现 |
| **Swift 易用 API** | extension、受限属性封装、状态观察与作用域模板 | 哪些能力适合属性，哪些必须是动作；页面交互和恢复策略 |
| **验证与交付** | 确定性生成、漂移检查、测试骨架、消费编译、打包和证据关联 | 独立期望值、领域不变量、性能预算及支持范围 |

**每类信息有明确权威源。** Kotlin SDK 声明提供公开类型与能力；行为策略补充无法从类型推断的语义；生成的导出接口用于核对编译器实际结果。中间契约视图由这些输入派生，避免要求开发者重复维护另一份完整业务 IDL。

业务开发者最终使用类型化动作与状态观察，SDK 作者补充语义与特殊适配，平台维护者管理支持组合和制品。复杂对象图、循环引用、跨线程可变对象、自定义领域映射出现时，通过显式扩展点处理；不能静默退化成 JSON、强制转换或未经验证的 Sendable 声明。

## 7 下一轮设计的决策与验收

先确定五项设计决策：

1. **后端与交付范围**：以当前 ObjC 加 SKIE 路线建立参考消费者；KMP-NativeCoroutines、组合模式和 Swift export 分别设准入条件。
2. **模型策略**：逐接口选择直接使用、薄 Facade 或独立快照，列出可生成的类型子集与不支持项。
3. **运行时协议**：声明错误、回调执行器、订阅、取消、受理、关闭和结果交接的保证。
4. **UI 与宿主扩展**：明确 UIKit / SwiftUI 的作用域绑定，覆盖 Swift 实现宿主协议及 Kotlin 回调 Swift。
5. **兼容基线**：明确 Kotlin、插件、Swift/Xcode、最低系统、平台、架构、Debug / Release 和 SDK 升级策略。

验收逐层建立：

**契约检查 → 确定性生成 → Kotlin 与 Swift 类型探针 → 双向消费测试 → 取消与关闭竞态测试 → Release 与分发验证 → 性能和诊断验证。**

| 验收层 | 最少覆盖的场景 |
|---|---|
| **类型与接口** | 可空值类、整数边界、泛型、嵌套集合、enum / sealed、宿主协议；核对真实导出名称与调用形状 |
| **错误与异步** | 空结果、业务失败、允许传播的异常、同步回调、重复完成、取消与完成相撞、迟到结果、资源无人接收 |
| **状态与生命周期** | 重复订阅、慢消费者、页面隐藏与销毁、后台、切号、关闭超时、旧账户回调；分别覆盖所选桥接模式 |
| **并发与内存** | Swift 6 严格并发检查、Kotlin 与 Swift 同时访问、Actor 重入、引用环、持续订阅后的内存趋势 |
| **制品与兼容** | 真机与模拟器、声明支持的架构、Release、干净环境、旧消费者重编译；独立升级策略下补充重链接与运行 |
| **性能与诊断** | 真实消息量、集合与字节规模、复制和分配预算；Kotlin 异常可定位，最终二进制与 dSYM UUID 对应 |

XCFramework 负责容纳目标制品，Swift 模块稳定性和跨 Xcode 消费需要额外配置与验证。SKIE 提供可分发 framework 配置；是否开启及支持哪些消费者应写入交付档位。[SKIE 分发配置](https://skie.touchlab.co/configuration/swift-compiler)

多 framework 方案要检查共同依赖、类型互通、全局状态和内核实例归属；可以按产品边界采用统一导出入口，再验证确需独立分发的模块。MadDemo 的 `MadKit` 组合导出可作为参考入口。[组合配置](/Users/changyue/Desktop/MadDemo/app/mad/build.gradle.kts:84)

测试结果应关联源码、工具链、生成物和具体制品。Kotlin/JVM 单测、Swift 编译、模拟器运行和真机运行分别记录；未知能力、未运行项、启发式零命中都不能计作安全性证明。[mad-boundary 证据测试](/Users/changyue/Desktop/mad-boundary/tests/test_evidence.py:44)、[已知漏报探针](/Users/changyue/Desktop/mad-boundary/tests/test_known_misses.py:1)

## 8 旧设计与讨论需要统一的表述

| 待统一内容 | 新方案采用的口径 |
|---|---|
| Kotlin 到 Swift 一定经过 ObjC | 区分 ObjC 导出和官方 Swift export；每个后端按版本、方向与集成方式验证 |
| Kotlin 模型都要再生成 Kotlin DTO 和 Swift struct | 直接复用优先评估；额外导出投影和独立快照按具体需求增加 |
| SKIE 会把全部业务模型变成独立 Swift 值 | SKIE 的类型增强有具体范围；sealed 包装可保留 Kotlin 对象引用 |
| Swift 有 async 就已有完整协程取消 | 按所选桥验证传播链；底层工作是否停止及副作用处理另行声明 |
| SKIE 没有 Combine，或与 KMP-NativeCoroutines 可以随意叠加 | 存在 Combine 预览能力；组合需划分责任并验证启动、取消和订阅语义 |
| 句柄与业务 ID 都禁止持久化 | 业务身份按领域规则持久化；运行时句柄受实例和生命周期限制 |
| 跨异步边界一律复制 | 按协议选择复制、所有权转移或安全共享；短期借用不能直接逃逸 |
| ARC / GC / 析构发生即算泄漏 | 普通内存回收是正常行为；诊断未按契约关闭、引用环或异常滞留 |
| 标注 Sendable 或使用 struct 就安全 | 检查所有字段、引用关系及两侧访问；按实际隔离规则声明能力 |
| 页面释放、页面隐藏、取消订阅、关闭账户等价 | 分别定义事件、作用域与 owner，按需要接入不同生命周期钩子 |
| API 文本 diff 或打包成功代表兼容 | 分开验证源码、二进制、行为和目标消费者；证据绑定具体版本 |

需要修订的通用规则位置：[业务 ID 与句柄](/Users/changyue/Desktop/mad-boundary/docs/design.md:287)、[异步内存策略](/Users/changyue/Desktop/mad-boundary/docs/design.md:347)、[回收与泄漏判定](/Users/changyue/Desktop/mad-boundary/docs/design.md:351)。
