# Swift Rust 架构总结与新版 mad-boundary 设计输入

整理日期：2026-10-23

**新版 mad-boundary 应将 Swift ↔ Rust 作为独立后端接入，优先复用 UniFFI Swift，补齐取消、并发隔离、资源生命周期和 Apple 制品验证。** Rust 契约可以与其他消费者共用，Swift 的运行协议和消费证据需要独立建立。

范围包括 Swift 调用 Rust，以及 Rust 通过公开 trait / 回调调用 Swift 宿主实现。交付重点为 Apple 平台，其他 Swift 目标另行登记。MadDemo 继续由 KMP 管理的业务能力，需要保留其协调和资源职责；新增直连应先确定独立产品或能力边界。

配套明细：[Swift Rust 跨语言边界工程清单](/Users/changyue/Desktop/mad设计/Swift_Rust/Swift_Rust_跨语言边界工程清单.md)，覆盖六组、26 项问题。

## 1 已明确的架构结论

| 结论 | 对新设计的要求 |
|---|---|
| **Swift 直连是独立边界** | 与 Swift → Kotlin/Native → Rust 分开描述；不能借用后者的运行结果宣称直连已验证 |
| **共享契约不等于共享后端能力** | UniFFI Swift 与 Gobley 分别登记版本、生成行为、目标和限制 |
| **Rust 可作为模型权威源** | Rust 声明生成 Swift 类型；有明确领域隔离需求时才增加额外模型 |
| **类型化接口不要求业务 JSON** | 复用绑定表示转换；内部缓冲格式不作为稳定网络或持久化协议 |
| **取消按版本和方向描述** | 绑定接线、停止等待、停止工作与副作用撤销分别验证 |
| **引用寿命与资源状态分开** | 复用 ARC / Arc 与生成句柄管理；另外定义 owner、关闭与在途操作 |
| **并发安全覆盖两端** | Swift 隔离、Rust 同步、外部回调和 unsafe 使用同一访问协议 |
| **交付策略决定验证范围** | Swift 源码包装和预编译 Swift 模块分别设计消费矩阵 |

### 1.1 调用路径与职责

| 路径 | 主要用途 | 架构要求 |
|---|---|---|
| **Swift → 生成绑定 → Rust** | 独立 SDK 的存储、推理、算法等原生能力 | Swift SDK 有完整的错误、取消、关闭与制品契约 |
| **Rust → 生成回调桥 → Swift** | Keychain、平台服务、事件交付等宿主能力 | Swift 实现的保活、隔离、同步返回值和失败协议明确 |
| **Swift → Kotlin/Native → Rust** | 现有 KMP 业务逻辑和生命周期的原生 UI 消费 | 保留 KMP 的业务协调和资源管理，不重复建立 owner |

MadDemo 的会话页调用 Kotlin Presenter，Rust 库合入 MadKit，SwiftPM 壳只引入这一份二进制。[会话页](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:4)、[打包职责](/Users/changyue/Desktop/MadDemo/tools/package-ios-framework.py:3)、[SwiftPM 配置](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Package.swift:1)

如果独立 Swift SDK 与 KMP SDK 共存，应明确资源是否共享、由谁初始化和关闭、链接哪一份内核。唯一关闭责任可以与多个语言包装及共享引用并存。

### 1.2 模型与数据传递

| Rust 契约 | UniFFI 的 Swift 表达 | 语义约束 |
|---|---|---|
| **Record** | 原生 struct | 修改传入或返回的值数据不自动写回 Rust；包含资源代理时不视为深度独立快照 |
| **带数据 Enum** | 带关联值的 enum | 可直接模式匹配；跨领域映射依赖明确语义 |
| **Option** | Optional | nil 与默认值分开 |
| **固定宽度整数** | UInt64、Int64 等对应类型 | 改成业务类型时检查范围和单位 |
| **字节数据** | Data | 复制和借用由所选接口协议决定 |
| **Object** | 包装类与协议 | 绑定引用的释放与业务 close 分开 |

以上映射由 UniFFI Swift 后端生成。[官方说明](https://mozilla.github.io/uniffi-rs/latest/swift/overview.html)

Rust 导出声明负责公开能力，生成器处理 ABI 接线和表示转换；Swift 开发者通常直接使用生成类型。只有隔离 SDK 版本、调整领域语义或适配 UI 时才增加 Facade / 投影。复杂类型经过内部缓冲转换，类型化不等于无编码或无复制。[转换机制](https://mozilla.github.io/uniffi-rs/latest/internals/lifting_and_lowering.html)

## 2 新方案必须覆盖的问题范围

| 问题组 | 契约内容 | 工具职责 |
|---|---|---|
| **公开类型与 ABI** | 后端能力、命名、值或代理、数值、空值、字符串和字节 | 元数据读取、生成、类型检查、布局与转换探针 |
| **错误与宿主接口** | 业务错误、未知回调错误、panic、同步返回值和平台隔离 | 错误映射、回调 Adapter、故障注入 |
| **异步与取消** | Future 驱动、任务归属、取消方向、完成认领、副作用 | 取消接线、结果交接、竞态验证 |
| **所有权与关闭** | 创建与关闭责任、借用、共享、回调保活、在途操作 | 资源包装、清理接线、关闭诊断 |
| **Swift 并发** | Actor 隔离、Sendable、阻塞性、回调线程、重入 | 执行器适配、编译检查、同步协议测试 |
| **事件与 UI** | 容量、顺序、溢出、共享分发、观察作用域、终止 | AsyncSequence 接入、队列原语、生命周期模板 |
| **性能** | 跨界频率、复制、分配、峰值内存 | 批处理支持、真实载荷基准、预算检查 |
| **兼容与交付** | 工具链、API / ABI / 行为、平台变体、Swift 模块和重复库 | 版本锁、差异检查、打包、真实消费 |
| **验证与诊断** | 双向场景、符号、错误关联、证据覆盖 | 测试夹具、运行器、报告、缺口说明 |

其中五项行为不能从函数签名推导：

- **取消能否停止底层工作。** 网络等待、推理计算、平台授权流程可能采用不同协议。
- **关闭何时完成。** 停止准入、排水、撤销句柄和释放内存是不同步骤。
- **回调返回值表示什么。** 同步接收确认不能被异步投递成功冒充。
- **事件能否丢弃或合并。** UI 状态、存储增量、请求响应需要不同交付保证。
- **谁拥有原生订阅。** 页面停止观察不必然意味着退订、断开连接或关闭账户。

## 3 工具生态在新架构中的位置

| 工具或路线 | 负责什么 | 使用边界 |
|---|---|---|
| **UniFFI Swift** | Rust 契约元数据、ABI 脚手架、Swift 类型与调用绑定 | 优先复用；语义与运行协议另行声明 |
| **uniffi-bindgen-swift** | 生成 Swift、C 头和 modulemap，支持 XCFramework 所需布局 | 属于 UniFFI 工具链；生成输出不等于完成多目标打包 |
| **swift-bridge** | 专门生成 Swift ↔ Rust 双向桥，包括受支持的异步与类型形状 | 适合两种语言紧密集成；借用寿命、可变别名和版本支持独立验证 |
| **C ABI + cbindgen + Swift 包装** | 为显式 Rust C 接口生成头文件，供 Swift 导入 | 安全 ABI 实现、错误、资源和异步包装由项目或扩展生成器负责 |
| **Swift Concurrency 与 Rust 并发设施** | Task、Actor、队列、锁和取消信号等基础能力 | 不自动建立跨语言取消和所有权语义 |
| **XCFramework 与 SwiftPM** | 原生变体和 Swift API 的分发 | Swift 源码包装与预编译模块采用不同兼容策略 |
| **mad-boundary** | 统一契约、行为规则、适配、测试与制品证据 | 复用后端能力，保留业务策略扩展点 |

依据：[Swift 生成工具](https://mozilla.github.io/uniffi-rs/latest/swift/uniffi-bindgen-swift.html)、[swift-bridge](https://chinedufn.github.io/swift-bridge/)、[安全约束](https://chinedufn.github.io/swift-bridge/safety/index.html)、[cbindgen](https://github.com/mozilla/cbindgen)、[Apple 分发](https://developer.apple.com/documentation/xcode/distributing-binary-frameworks-as-swift-packages)。

Gobley 服务 KMP 绑定；SKIE 和 KMP-NativeCoroutines 服务 Kotlin → Swift；rust-bindgen 生成 Rust 接入 C/C++ 的声明。它们不应被登记为 Swift ↔ Rust 的等价生成器。

### 3.1 固定版本的取消能力

核对 UniFFI 0.32.1 的 Swift 模板后，两个方向需要分别建模：

| 方向 | 模板行为 | SDK 必须补充的协议 |
|---|---|---|
| **Swift 调用 Rust async** | 创建并轮询 Rust Future，退出时释放；没有把 Swift Task 取消自动连接到 Rust Future 取消 | 按接口提供协作取消、操作取消，或只结束等待并保留收尾；验证注册与取消竞态 |
| **Rust 调用 Swift async** | 反向 Future 被释放时，对对应 Swift Task 调用 cancel | Swift 宿主实现合作响应；明确平台操作是否真的停止 |

依据：[固定版本 Async.swift](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/uniffi_bindgen/src/bindings/swift/templates/Async.swift)。该结论描述这个模板的接线，不能替代具体操作的停止和回滚保证。

工具不能在取消时自行释放仍被轮询或回调访问的句柄。取消等待后留下的结果、缓冲、回调和原生工作必须有管理者，底层已产生的副作用按领域契约处理。

### 3.2 事件与资源包装的边界

AsyncStream 可以承接回调，但其 continuation yield 立即返回，默认缓冲无界。有限容量需要定义丢弃策略，生产者减速需要底层协议；多个观察者的分发与各自取消也需要独立设计。[Swift 设计](https://github.com/swiftlang/swift-evolution/blob/main/proposals/0314-async-stream.md)

UniFFI 已有 Swift 包装类释放句柄的实现，正常 deinit 是引用回收的一部分。业务 close 负责停止准入、排水等资源协议；跨语言引用环依然需要显式断开。[对象模板](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/uniffi_bindgen/src/bindings/swift/templates/ObjectTemplate.swift)、[引用环说明](https://mozilla.github.io/uniffi-rs/latest/foreign_traits.html#avoid-cycles)

## 4 业界与项目的工程经验

| 案例 | 应沉淀的规则或测试 |
|---|---|
| UniFFI 0.31.1 修复过 Swift 异步内存泄漏和启用 ASan 时的 iOS 崩溃 | 生成器版本进入异步释放和目标运行回归矩阵 |
| UniFFI 0.31.2 修复过字符串首位 U+FEFF 被移除及回调表并发警告 | 类型转换使用语义样例；严格并发检查覆盖生成源码 |
| swift-bridge 文档给出 Swift 违反 Rust 引用寿命与可变别名要求的案例 | 借用与独占访问不可仅凭生成器名称判定安全；需要受限 API 和针对性验证 |
| MadDemo 网络取消只放下等待，远端名额仍可能被占用 | 等待结束与工作结束分别计数；迟到结果有归属 |
| MadDemo 推理在原生线程读取取消回调 | Swift 宿主实现必须支持对应并发访问，不能把同步取消查询改为异步 UI 投递 |
| mad 关户最后一批事件同步交付 | 回调契约包含同步完成、执行线程与重入约束 |
| MadDemo 存储每库只有一次常驻订阅 | Swift 多页面观察由共享分发层承接，不能逐页重复注册 |
| MadDemo 将 K/N 框架与 Rust 库合入唯一 MadKit | 新直连后端与 KMP 共存时检查链接、初始化和关闭职责 |

上游依据：[UniFFI 发布记录](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/CHANGELOG.md)、[swift-bridge 安全说明](https://chinedufn.github.io/swift-bridge/safety/index.html)。

项目依据：[请求取消](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:12)、[推理回调](/Users/changyue/Desktop/MadDemo/capability/infer/engine/src/commonMain/kotlin/com/mad/infer/engine/ffi/UniffiInferKernelPort.kt:12)、[mad 事件交付](/Users/changyue/Desktop/学习2/mad-platform/capability/im/engine/src/nativeMain/kotlin/com/mad/capability/im/engine/ffi/UniffiKernelPort.kt:129)、[订阅约束](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226)、[唯一制品](/Users/changyue/Desktop/MadDemo/tools/package-ios-framework.py:3)。

这些项目案例反映底层协议和既有 Kotlin/Native 集成经验。新增 Swift 直连应把相同约束落到 Swift API 和独立消费测试中，不据此声称已发生或已验证相应的 Swift 故障。

## 5 新版 mad-boundary 的模块职责建议

| 模块 | 单一职责 | 输入与输出 |
|---|---|---|
| **契约模型与能力检查** | 统一接口、类型、方向、版本、目标和行为保证 | Rust 元数据、能力表、策略 → 契约视图与缺口 |
| **Swift 绑定后端** | 包装 UniFFI Swift 或其他明确选定的接入路线 | 版本锁、生成配置、目标 → Swift / 头 / modulemap 及构建任务 |
| **类型与错误适配生成** | 补充可机械推导的数值、ID、错误及必要领域映射 | 契约、映射规则 → Swift Facade 与校验 |
| **Swift 运行协议适配** | 执行已声明的隔离、取消、回调、保活和关闭协议 | 绑定 API、行为策略 → 任务、订阅、资源包装 |
| **语言 API 与 UI 接入** | 提供 async throws、AsyncSequence 和正确的页面作用域 | SDK、作用域规则 → Swift API、SwiftUI / UIKit 接入模板 |
| **验证与诊断** | 检查双向消费、竞态、内存、并发和性能 | 场景、制品、运行结果 → Findings、Gaps、证据 |
| **Apple 构建与交付** | 管理原生变体、Swift 模块、符号和工具链的一致性 | 构建计划、锁与产物 → 可追溯 Swift SDK |

这些职责映射到现有 model / rules、ContractReader、Generator、Verifier、Toolchain、sdk/runtime、language-api 和 ui-integration；新增 Swift 适配器与夹具，共用核心协议。[现有模块](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)

设计原则落实为代码约束：

- **单一职责与依赖倒置**：规则只消费契约与观察结果，Cargo、Xcode、文件和进程操作留在适配器。
- **Adapter 与 Strategy**：不同生成器和运行策略显式登记，避免模板中散布版本和平台判断。
- **Facade**：隐藏重复转换，保留受理、取消、结束和关闭的业务含义。
- **状态机与作用域管理**：明确注册、进行中、完成、取消和关闭状态，复用已有资源 owner。
- **组合优先**：复用生成绑定的引用管理；复杂领域适配通过窄接口接入，避免复制底层句柄体系。
- **整洁代码**：生成区与手写区分离，策略有名称和测试，错误集中分类；验证协议不变量而非镜像实现步骤。

Swift Actor 隔离与 Rust 同步仍是各自实现的责任。不能通过全局 MainActor、unchecked Sendable 或无限队列掩盖契约缺口。[Sendable 要求](https://docs.swift.org/latest/documentation/swift/sendable/)

## 6 自动生成与手写的分界

| 内容 | 可以机械生成 | 根据声明生成或执行 | 开发者负责 |
|---|---|---|---|
| **公开接口与类型** | Swift 类型、函数、回调、头文件、modulemap | ID 包装、数值范围、命名与错误适配 | 公开能力、字段语义、单位、领域模型边界 |
| **异步与调度** | 参数和结果接线、标准回调包装 | 执行器选择、取消传播、一次完成与结果交接 | 阻塞性、底层停止能力、任务 owner、受理语义 |
| **资源与内存** | 标准引用释放接入、诊断埋点 | 保活、关闭准入、排水和作用域接入 | 创建与关闭责任、底层关闭实现、unsafe 与共享访问正确性 |
| **事件与 UI** | 类型化观察入口、UI 接入模板、按需 Combine 适配 | 容量、共享分发、溢出信号、终止清理 | 交付保证、快照恢复、业务幂等和重放 |
| **工程保障** | 生成物漂移、接口 diff、打包清单、消费夹具骨架 | 平台与版本矩阵、验收门槛、性能预算 | 独立业务期望值、恢复策略、支持范围 |

每类信息有明确权威源：Rust 声明与实际编译元数据描述公开接口；行为策略补充无法从类型推导的语义；Swift 领域映射只记录必要差异。中间模型由工具派生，不让开发者重复维护完整业务 IDL。

复杂对象图、未知生命周期、不支持的类型和特殊平台服务进入显式扩展点。工具应报告缺口，避免用静默默认值、强制转换、无限任务或自动改成 JSON 掩盖问题。

## 7 下一轮设计的决策与验收

优先顺序分三层：

1. **P0 边界与支持范围**：确定 Swift 直连能力、与 KMP 的关系、资源 owner；锁定 Swift 后端和目标；声明双向取消、回调、关闭及制品策略。
2. **P1 完整消费与运行协议**：建立 Record / Enum / Object / 回调 / 错误消费夹具，接入取消和关闭状态机，验证 Swift 6、模拟器、真机与 Release；同步生成受检映射。
3. **P2 开发体验与性能**：完善 AsyncSequence、SwiftUI / UIKit 与按需 Combine 接入；依据测量扩展批处理、借用缓冲和其他生成后端。

验收逐层建立：

**契约检查 → 确定性生成 → Rust 与 Swift 编译 → 双向真实消费 → 取消 关闭与回调交错 → Apple 制品与版本矩阵 → 性能和诊断验证。**

| 验收层 | 最少覆盖的内容 |
|---|---|
| **类型与错误** | 数值边界、nil、Unicode、字节、关联值 enum、命名、业务错误、未知回调错误 |
| **异步与并发** | 调用前已取消、注册与取消相撞、同步首回调、重复完成、迟到资源结果、Swift 6 隔离、重入 |
| **资源** | 引用环、回调保活、最后引用释放、并发关闭、关闭超时、在途借用与错误路径释放 |
| **事件与 UI** | 队列满、慢消费者、顺序、丢批恢复、多观察者、离页与销毁、账户切换 |
| **交付** | 绑定与库匹配、目标特性、真机与模拟器、最低系统、Debug / Release、干净环境、承诺的 Xcode 组合、KMP 共存 |
| **性能与诊断** | 真实载荷下延迟、吞吐、复制与内存；符号、构建身份、操作关联和日志脱敏 |

交付先选择 Swift 源码包装还是预编译 Swift 框架。前者与原生 XCFramework 配套，由消费者编译包装；后者需要相应的 Swift 模块接口与库演进策略。真机和模拟器分别构建为平台变体，不将同架构误当作同目标。[Apple 打包要求](https://developer.apple.com/documentation/xcode/creating-a-multi-platform-binary-framework-bundle)

测试结论绑定源码、生成器、工具链、目标、生成物与原生制品。Rust 单测、Swift 包装单测、模拟器真实 FFI、真机和性能证据分别记录；没有对应证据的支持声明保留缺口。[证据机制](/Users/changyue/Desktop/mad-boundary/tests/test_evidence.py:44)

## 8 旧设计与讨论需要统一的表述

| 待统一内容 | 新方案采用的口径 |
|---|---|
| Swift Rust 一行写成同 Kotlin Rust | 共享 Rust 契约，独立描述 Swift 后端、并发、取消、交付和消费证据 |
| Swift 0.32 取消能力统一写无 | 0.32.1 正向缺自动 Task 取消接线，反向释放会请求取消 Swift Task；底层效果另行声明 |
| 所有模型都经过 Kotlin | Rust SDK 可直接生成 Swift 原生模型；KMP 是否参与取决于业务职责 |
| 所有 struct 都是完全独立快照 | 检查嵌套对象引用和共享资源；只有符合约束的数据可视为独立快照 |
| ARC 与 Arc 自动解决跨语言生命周期 | 保留显式关闭、在途保活、引用环和回调终止协议 |
| deinit 只能诊断 | 复用后端的正常引用回收；确定性关闭与重清理由专门协议负责 |
| Task 取消等于底层操作停止 | 区分取消请求、停止等待、停止工作与副作用撤销 |
| AsyncStream 同时提供背压和广播 | 显式设计生产者反馈、溢出、共享分发和观察者终止 |
| unchecked Sendable 等于线程安全证明 | 同步正确性由实现与验证承担，注解不是自动加锁 |
| 零拷贝适用于任意异步数据 | 借用只在协议允许的有效期内使用；异步存活需要复制、转移或安全共享 |
| XCFramework 可打包就可跨工具链消费 | 明确 Swift 模块交付方式并验证承诺的消费矩阵 |
| Kotlin/Native 消费通过即可覆盖 Swift 直连 | 新增独立 Swift 生成、编译、双向运行和生命周期证据 |

相关旧设计位置：[后端能力](/Users/changyue/Desktop/mad-boundary/docs/design.md:133)、[取消表](/Users/changyue/Desktop/mad-boundary/docs/design.md:449)、[Swift API](/Users/changyue/Desktop/mad-boundary/docs/design.md:607)、[制品交付](/Users/changyue/Desktop/mad-boundary/docs/design.md:794)。
