# Swift C/C++ 跨语言边界工程清单

整理日期：2026-10-23

**Swift ↔ C/C++ 应复用编译器的语言互操作能力，由边界工具补齐所有权、异步协议、开发体验和交付验证。** 是否增加 C 接口、Objective-C++ 包装或独立 Swift 模型，应由公开能力、兼容目标和资源语义决定。

范围包括 Swift 调用 C/C++，以及 C/C++ 调用 Swift 函数、回调和宿主服务。以 Apple 平台为主要交付场景；其他 Swift 目标分别登记工具链与运行能力。本清单延续对话中的四组、24 项问题，补充工具、项目依据和验收重点。

项目证据分开使用：旧 mad 的 NativeAtomicFile 是 Swift 直接调用 C 的案例；MadDemo 的 IMLink C 接口目前由 Rust 消费，提供可复用的原生协议经验；MadDemo iOS 主链路消费 Kotlin/Native 导出，不能替代 Swift ↔ C++ 直连验证。

配套决策：[Swift C/C++ 架构总结与新版 mad-boundary 设计输入](/Users/changyue/Desktop/mad设计/Swift_C_CPP/Swift_C_CPP_架构总结与新版_mad-boundary_设计输入.md)。

## 一 接口与数据

目标：确定调用路线和接口权威源，让类型表达保留业务语义。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **1. 路线与类型支持范围** | 区分 C 导入、直接 C++、Objective-C++ 包装；分别登记正反方向、目标和版本能力；同一接口只维护一个权威源 | Swift/Clang 编译探针、Clang AST、头文件或导出声明基线、能力表 | Swift 官方支持双向 C++ 互操作，但支持范围受类型和方向约束。[官方指南](https://www.swift.org/documentation/cxx-interop/)、[支持范围](https://www.swift.org/documentation/cxx-interop/status/) | 不支持的签名在生成或编译阶段明确失败；不把一个模板实例的成功当成任意模板均可用；编译配置参与检查 |
| **2. 值语义 引用语义与模型** | 区分可复制值、借用视图、共享引用和需关闭资源；优先直接使用合适的导入类型；按需增加 Facade 或独立快照 | 编译器导入规则、所有权注解、受限 Swift 包装、复制测试 | C++ 类型可按值导入，复制和销毁涉及其 C++ 特殊成员；适用类型也可映射为引用类型。[类型映射](https://www.swift.org/documentation/cxx-interop/) | 复制包装不产生两个关闭责任者；含共享对象的结构不被误称为深度独立快照；不默认生成三套模型 |
| **3. 数值 空值与枚举** | 明确位宽、符号、单位、范围、空值和未知枚举策略；在收窄或无符号转换前校验 | 固定宽度类型、受检转换、Optional 适配、边界值夹具 | MadDemo 的原生事件使用固定宽度字段，并检查结构大小和偏移。[原生事件布局](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:73) | 覆盖极值、负数、无效枚举和空指针；size_t 转 Int32 不静默截断；Int64/UInt64 不因其他语言习惯一律改成字符串 |
| **4. 字符串 字节与布局** | 文本声明编码和长度单位；二进制显式携带长度；读取结构或零拷贝前检查大小、对齐、初始化和别名条件 | String、Data、长度受限转换、受检算术、布局探针 | mad_link.h 明确字符串采用指针与长度，并在返回前拷贝；业务额外限制字符串内容。[输入契约](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:1) | 不以 strlen 处理二进制；Unicode、空数据和大载荷正确；不把任意 Data 地址强转为已初始化的原生结构 |
| **5. 错误与异常** | 将 C 状态码和必要的 errno 信息及时转换；C++ 异常留在 C++ 边界处理；反向 Swift 失败通过显式结果协议返回 | 错误目录、Swift Error/Result、C++ try/catch、无异常构建的状态协议 | Swift 不能捕获越界传播的 C++ 异常；旧 mad 包装 Darwin 调用错误；MadDemo 部分 C++ 入口捕获异常并返回内部错误。[官方限制](https://www.swift.org/documentation/cxx-interop/status/)、[C 错误包装](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ios/BootLedger/Sources/MadBoot/NativeAtomicFile.swift:14)、[原生实现](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/bridge.cc:18) | noexcept 不被当成自动错误转换；失败不伪装成有效空值；错误读取不被后续调用覆盖；不使用异常处理掩盖内存破坏 |

Swift 6.3 起可用正式的 @c 将符合要求的 Swift 函数和枚举暴露给 C，并生成声明；@c 与 @implementation 组合可校验对已有 C 声明的实现。较旧工具链应采用明确验证的兼容路线，不把带下划线的历史属性当作通用稳定接口。[Swift 6.3](https://www.swift.org/blog/swift-6.3-released/)

生成头文件只解决声明和调用表达；它不会自动决定取消、资源释放或业务成功条件。

## 二 所有权与内存

目标：让地址、对象、操作和回调的有效期一致，保持唯一的关闭责任。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **6. 创建 释放与分配器配对** | 每类资源明确创建者、借用者、接收所有权者、释放入口和允许的执行位置；复用后端已有引用管理 | RAII、专用 deleter、受限资源包装、所有权声明 | 原生引擎分别提供 new、stop、free，释放接口承担自身资源回收。[引擎接口](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:90) | 不混用 free/delete/专用释放器；成功、失败、取消路径回收配对；多个语言包装不各自销毁同一资源 |
| **7. 临时指针与异步保留** | 同步借用限制在有效作用域；异步前由原生侧拷贝、转移所有权或建立明确稳定的存储 | withUnsafeBytes/withCString、原生缓冲 owner、操作保活 | Swift 文档明确临时指针不能逃逸其有效作用域；旧 mad 在 withUnsafeBytes 内同步完成写入。[临时指针](https://docs.swift.org/latest/documentation/diagnostics/temporary-pointers/)、[同步写入](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ios/BootLedger/Sources/MadBoot/NativeAtomicFile.swift:29) | 仅保留 Data 对象不被当成临时地址长期有效的证明；取消等待后不提前释放仍被 native 使用的缓冲 |
| **8. C++ 视图 借用与可变别名** | 记录返回视图依赖的 owner、修改失效条件和访问权限；优先限制借用范围，必要时复制 | 生命周期与边界注解、API Notes、Span、安全互操作检查 | 官方安全互操作支持借用和边界表达，部分包装能力依赖工具链与功能开关。[安全互操作](https://www.swift.org/documentation/cxx-interop/safe-interop/) | string_view/span 不超过底层存储寿命；owner 活着但容器重分配仍可能失效；注解与实现一致；未覆盖的契约明确保留人工审查 |
| **9. 回调上下文寿命** | C 回调使用可调用入口与 context；登记、保活、注销及在途访问采用同一协议；支持的 C++ std::function 路线复用其闭包管理 | C trampoline、受控 Unmanaged、回调注册对象、在途计数 | 直接 C++ 互操作在受支持版本可用捕获闭包构造 std::function；这不等同于 C 函数指针可捕获上下文。[回调能力](https://www.swift.org/documentation/cxx-interop/#using-stdfunction) | 未注册成功也释放上下文；注销返回含义明确；仅在未来及在途回调均不再访问 context 后释放；重复回调不重复消费 retained 引用 |
| **10. 跨语言引用环** | 显式绘制强引用关系；区分回调保活和业务生命周期；通过弱引用或注销入口断开循环 | weak、回调 token、显式退订、资源计数、内存图 | Swift 对象持有原生对象，原生闭包再捕获 Swift 对象时可能形成循环；MadDemo 页面对观察任务使用弱捕获和销毁时取消。[页面任务](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:46) | 关闭后回调和页面可回收；页面弱引用不替代原生 context 保活；ARC 与 shared_ptr 不被当作循环回收器 |
| **11. 关闭 析构与在途使用** | 关闭先停止准入，再等待或终止在途操作，最后释放；区分请求关闭与关闭完成；析构执行位置符合原生要求 | 幂等 close、Open/Closing/Closed 状态机、使用租约、清理执行器 | MadDemo 区分 stop 和等待 I/O 线程退出的 free。[停止与释放](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:92) | 关闭超时不授权强行销毁；最后引用释放不假定在主线程；异步渲染结束前资源仍有效；回调内关闭不等待自己 |

正常 ARC/RAII 回收和显式业务关闭可以并存。简单同步值不需要强行增加 close；连接、线程、渲染资源等需要确定性终止时，才增加对应协议。单一所有权主要约束关闭责任，不禁止合法共享引用和借用。

## 三 异步 多线程与生命周期

目标：分清调度、并发隔离、实际停止和业务完成，避免等待者结束后失去清理责任。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **12. 阻塞性与执行位置** | 声明同步耗时、可能阻塞和回调执行位置；重工作进入容量受控的执行设施 | 工作队列、专用执行器、耗时预算、主线程检测 | MadDemo 的 poll 可选择等待；原生 free 会等待线程退出，不能只依据 Swift 方法是否 async 判断阻塞。[poll](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:107)、[free](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:94) | Task 不被当作自动后台线程；actor 上的长时间同步工作仍计入阻塞预算；禁止无限扩张任务承接过载 |
| **13. Swift 并发隔离与共享状态** | 将原生对象放在明确隔离域；共享时提供真实同步；结果到 UI 前进入 MainActor；同时约束原生线程访问 | Actor、MainActor、Sendable 检查、锁或原生串行化 | Sendable 表示并发语义保证，unchecked 由开发者负责正确性。[Sendable](https://docs.swift.org/latest/documentation/swift/sendable/) | 不用 unchecked Sendable 或 preconcurrency 掩盖未解决的数据竞争；actor 隔离不自动阻止 C++ 自有线程访问同一内存 |
| **14. 原生线程亲和性** | 分开声明串行、固定线程、主线程和可并发；为真实固定线程需求提供专用设施 | 专用线程、线程断言、执行器适配、创建与销毁线程测试 | 架构约束示例：原生图形或第三方句柄要求特定线程调用；普通 actor 的串行保证不等于绑定一个 OS 线程 | 创建、调用、回调和销毁符合各自约束；原生线程同步回调 Swift 时不假设已进入正确 actor |
| **15. 回调转 async 与完成认领** | 先登记再触发；成功、失败、取消通过统一终态认领；允许同步首回调；终态清理与恢复等待者分别定义 | CheckedContinuation、Operation 状态机、锁或等价同步、可控交错测试 | continuation 需要恰好恢复一次；MadDemo 相邻边界采用登记等待者后发送的顺序。[官方约束](https://developer.apple.com/documentation/swift/checkedcontinuation)、[登记顺序](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:81) | 覆盖注册失败、同步完成、重复完成和取消竞争；不只检查是否非空后无同步地 resume；永不回调时有约定的终止方案 |
| **16. 取消 超时与后台收尾** | 区分停止观察、停止等待、停止工作和撤销副作用；原生停止请求与终态确认分开；迟到资源仍有 owner | cancellation handler、原生停止接口、取消状态、后台清理责任 | MadDemo 网络等待取消不代表远端工作停止；C 接口的 send 返回只表示投递阶段。[等待取消](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:12)、[发送阶段](/Users/changyue/Desktop/MadDemo/kernel/libs/imlink-native/native/mad_link.h:99) | 已取消后注册仍安全；等待结束不释放原生仍使用的地址；取消查询支持其实际调用线程；业务副作用不伪装成已撤销 |
| **17. 重入 锁顺序与死锁** | 默认不持业务锁调用宿主；必要例外显式审查；避免原生线程与 Swift 执行器相互同步等待 | 锁顺序、回调分类、异步应答、重入与关闭测试 | 原生同步回调 Swift，Swift 再同步关闭并等待原生线程，是需要主动构造的失败场景 | 回调内取消、退订和关闭不自等待；结果转换不在持锁区执行任意用户代码；不靠递归锁掩盖生命周期问题 |
| **18. 流 背压与页面作用域** | 明确容量、丢弃、顺序、恢复和多观察者分发；区分页面离开、对象销毁和资源关闭 | AsyncStream/AsyncSequence、有界队列、序号、Subscription、UIKit/SwiftUI 适配 | MadDemo 页面的观察在 viewDidLoad 启动、deinit 取消，不等于每次离页取消；底层存储另有单次常驻订阅约束。[页面](/Users/changyue/Desktop/MadDemo/shell/ios/swift/MadShellKit/Sources/MadShellKit/ConversationViewController.swift:40)、[底层订阅](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226) | 慢消费者和队列满有确定行为；有限缓冲不自动形成生产者背压；多页面不重复登记唯一底层订阅；离页和销毁分别测试 |

C++ 调用 Swift 的同步返回值如果代表业务完成，就不能擅自改成异步投递成功。直接暴露 Swift async/throws 的能力受后端限制时，应明确设计请求与结果协议，而不是假设会自动映射为 C++ future 或异常。

## 四 构建 性能与交付

目标：让公开接口、编译环境、二进制和实际消费结果一致。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **19. 编译环境与模块配置** | 固定 Swift、Clang、SDK、目标、宏、C++ 标准及互操作模式；读取实际构建参数 | SwiftPM、CMake、Xcode、Clang AST、编译数据库、工具链锁 | 直接 C++ 互操作需要配置模块和编译模式，也可能影响下游 SwiftPM 消费配置。[构建说明](https://www.swift.org/documentation/cxx-interop/project-build-setup/) | 每种承诺组合真正编译；同一头在不同宏下的形状可追溯；不把 Clang module map 与 C++20 modules 混为一谈 |
| **20. API ABI 与行为演进** | 分开管理 Swift API、C/C++ ABI、行为契约和源码/二进制分发；明确可替换边界 | API 基线、符号与布局探针、旧消费者、Swift 模块接口检查 | Swift Crypto 明确其源码分发不承诺稳定 ABI；Swift 官方描述 C++ 互操作兼容版本机制。[源码分发实例](https://github.com/apple/swift-crypto)、[兼容说明](https://www.swift.org/documentation/cxx-interop/#source-stability-guarantees-for-mixed-language-codebases) | 签名不变但取消或线程语义改变也可识别；extern C 不等于完整 ABI 协议；swiftinterface 不替代 C++ 标准库和布局兼容 |
| **21. 多平台制品与首次消费** | 按平台变体构建原生库；声明、模块、依赖和库配套交付；首次包解析前准备所需制品 | XCFramework、xcodebuild archive、SwiftPM binaryTarget、干净环境消费 | MadDemo 专门处理首次构建缺制品及仅有 arm64 模拟器切片时的构建配置。[项目脚本](/Users/changyue/Desktop/MadDemo/tools/ios.sh:105)、[Apple 打包](https://developer.apple.com/documentation/xcode/creating-a-multi-platform-binary-framework-bundle) | 真机与模拟器分开；覆盖最低系统、Release 和承诺的 Xcode；能打包不等于跨工具链可消费；非 Apple 目标另定交付方案 |
| **22. 依赖 符号与代码寿命** | 明确标准库、传递依赖、静态/动态链接和单实例归属；可卸载场景先确认对象、线程和回调均结束 | nm、otool、符号白名单、依赖图、装载测试、构建身份 | MadDemo 将内核合入唯一 MadKit，不让壳再次链接同一内核，并校验应用符号。[打包职责](/Users/changyue/Desktop/MadDemo/tools/package-ios-framework.py:3)、[符号检查](/Users/changyue/Desktop/MadDemo/tools/ios.sh:133) | 不因重复库产生两套全局状态；运行库与工具链相容；仍有函数指针或析构代码被使用时不卸载对应库 |
| **23. 隐式复制与端到端性能** | 测量字符串、容器、结果快照、跨界频率和积压；先优化批量与数据形状，再按契约引入零拷贝 | Instruments、原生计数、复制计数、真机基准、性能预算 | 官方指出部分 C++ 容器操作可能有额外深拷贝。[性能约束](https://www.swift.org/documentation/cxx-interop/status/) | 同时覆盖延迟、吞吐、主线程耗时、复制量和峰值内存；不以一个空函数微基准代表真实 SDK；保活成本纳入零拷贝评估 |
| **24. 真实验证与故障定位** | 分层验证正反调用、内存、失败路径、并发及制品；记录证据对应的构建和覆盖范围 | Swift Testing/XCTest、适用的 ASan/TSan/UBSan、模糊测试、dSYM UUID、资源计数、结构化日志 | mad-boundary 的 Verifier 将检查与制品、输入及证据关联；MadDemo 使用真实应用链接后的符号检查。[证据机制](/Users/changyue/Desktop/mad-boundary/docs/design.md:200)、[应用校验](/Users/changyue/Desktop/MadDemo/tools/ios.sh:133) | 仅编译、仅主机测试、模拟器和真机证据分开；未运行不写成通过；符号匹配实际二进制；未插桩原生库的覆盖局限明确 |

## mad-boundary 的职责划分

- **契约与能力模型**：登记调用方向、路线、版本及所有权、线程、取消、关闭协议；明确缺失信息。
- **编译器与绑定适配**：复用 Swift/Clang 导入和导出能力；生成必要的薄适配，不重写通用 C++ 编译器。
- **运行时协议**：提供操作、回调、订阅和资源原语；执行已声明的生命周期，复用既有 owner。
- **Swift API**：按需生成受检类型、Facade、async 和流接口，让普通业务不操作裸指针。
- **验证与交付**：建立正反消费、竞争、内存、性能及制品矩阵，保留可追溯结果。
- **SDK 作者**：决定领域模型、失败语义、停止能力、同步和恢复策略，并保证原生实现符合契约。

## 通用规则需要统一的口径

| 容易误用的说法 | 采用的口径 |
|---|---|
| Swift 调 C++ 必须先写 Objective-C++ | 直接 C++ 是官方路线；按 API 支持范围和交付目标选型 |
| 统一增加一层 C 就自动安全稳定 | C 接口仍需所有权、布局、调用约定、分配器和版本协议 |
| 所有原生类型都转换为独立 Swift 模型 | 优先直接使用合适导入类型；Facade 和快照按需求增加 |
| 保留 Data 就能长期保留临时指针 | 临时借用按作用域有效；异步须建立明确的稳定存储 |
| @c 可直接导出任意 Swift API | 只适用于支持的声明和类型，并受工具链版本约束 |
| C 函数指针和 std::function 闭包相同 | C 入口通常另传 context；受支持的 C++ 闭包路线采用自己的管理机制 |
| Actor 等于固定线程且保护所有 native 访问 | 普通 actor 提供隔离语义；原生线程和线程亲和性另行约束 |
| Task/AsyncStream 已经解决取消和背压 | 需要原生停止、容量、生产者反馈、终态与清理协议 |
| deinit 必须承担一切关闭操作 | 复用正常引用回收；需要确定性关闭或特定线程清理时提供显式协议 |
| C++ 互操作没有源码兼容安排 | 官方描述兼容版本机制；具体组合与二进制兼容仍需验证 |
| XCFramework 生成成功即完成企业交付 | 首次消费、切片、Swift 模块、依赖、Release 和版本矩阵仍需检查 |

相关旧设计：[Swift C/C++ 后端](/Users/changyue/Desktop/mad-boundary/docs/design.md:134)、[通用模块](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)、[语言运行时](/Users/changyue/Desktop/mad-boundary/docs/design.md:165)、[Apple 制品](/Users/changyue/Desktop/mad-boundary/docs/design.md:794)。
