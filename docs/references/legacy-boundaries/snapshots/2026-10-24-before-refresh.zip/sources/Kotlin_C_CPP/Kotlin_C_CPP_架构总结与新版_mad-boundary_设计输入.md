# Kotlin C/C++ 架构总结与新版 mad-boundary 设计输入

整理日期：2026-10-23

**新版 mad-boundary 应共享边界契约、Kotlin API 设计与验证规则，分别对接 Kotlin/JVM 和 Kotlin/Native 的绑定与运行时机制。** 主要价值是把已明确的所有权、缓冲区、异步、线程和交付协议变为可靠的 SDK 接线与验证。

范围包括 Kotlin 调用 C/C++，以及 C/C++ 反向调用 Kotlin 方法、导出函数和回调。Android/JVM、Kotlin/Native 与现代 JDK 分别登记能力；鸿蒙目标同时记录项目实际使用的 Kotlin 工具链。以下作为新版工具的架构与实施输入。

配套明细：[Kotlin C/C++ 跨语言边界工程清单](/Users/changyue/Desktop/mad设计/Kotlin_C_CPP/Kotlin_C_CPP_跨语言边界工程清单.md)，包含四组、25 项问题、方案、工具、案例和验收重点。

## 1 已明确的架构结论

| 结论 | 对设计的要求 |
|---|---|
| **运行时先于语言名称** | Kotlin/JVM 与 K/N 使用不同绑定、引用和线程接入机制，不能统一假设 JNI |
| **接口与语义可以共享** | commonMain 保留业务接口和可移植模型，平台绑定留在对应 source set |
| **C++ 包装取决于消费目标** | JNI 内部可以直接调用 C++；K/N 通常通过 C/Objective-C 可见接口接入 |
| **权威声明只有一份** | 参数与类型由原生头、导出声明或 JVM 桥接面派生，行为策略不重复手写签名 |
| **数据转换按需发生** | 直接映射、Facade、独立快照分别选择，不默认 JSON 或三套模型 |
| **生命周期跨越协程寿命** | 停止等待后，原生工作、回调和结果仍可能需要独立的清理责任者 |
| **完成与交付分别处理** | native 完成不等于 Kotlin 调用方成功收到资源，取消竞争必须覆盖 |
| **所有权不代替同步** | 引用计数、GC、StableRef 与句柄包装不能自动消除原生数据竞争 |
| **制品与绑定一起验收** | 编译成功之外，还要验证 Release、R8、依赖、平台矩阵和真实消费者 |

### 1.1 调用路线与选型

| 路线 | 接入方式 | 优先考虑的场景 | 约束与成本 |
|---|---|---|---|
| **Android/JVM 与 JNI** | Kotlin 桥接方法 → JNI C/C++ 适配 → 原生实现 | Android 原生能力、复杂 C++ 接口、需要控制转换和调用成本 | 维护 JVM 描述符、引用、线程、错误与混淆规则；JNI 包装内部不必再套公共 C 接口 |
| **JVM 与 JNA** | Kotlin 使用 JNA 声明 → C ABI | 已有 C 接口、接口适中、已有 JNA 资产 | 检查类型布局、编码、回调保活与动态调用成本；JNA 自身包含原生支持层 |
| **JVM 与 JavaCPP** | Kotlin 使用生成的 Java API → JNI → C++ | 接入较大的现有 C++ 库 | 仍需声明映射、所有权和构建策略；不直接服务 K/N |
| **K/N 与 C** | C 头 + .def → cinterop 绑定 → C 库 | 系统 C API、多语言公共接口 | 指针、借用、回调、输出参数与释放协议需要额外包装 |
| **K/N 与 C++** | C/Objective-C 可见包装 → C++ 实现 | 需要 K/N 消费的 C++ 功能 | 公共 C 接口适合多消费者；Objective-C++ 包装用于 Apple 特定能力 |
| **现代 JDK 与 FFM** | Kotlin/JVM → FFM 调用 C ABI；可由 jextract 生成 Java 绑定 | 使用合适 JDK 的桌面或服务端 | JDK、jextract 与部署方式需匹配；Arena 作用域与线程约束明确；不直接等同 Android 支持 |

官方与项目依据：[Android JNI](https://developer.android.com/ndk/guides/jni-tips)、[JNA](https://github.com/java-native-access/jna)、[JavaCPP](https://github.com/bytedeco/javacpp)、[K/N 定义文件](https://kotlinlang.org/docs/native-definition-file.html)、[JDK FFM](https://docs.oracle.com/en/java/javase/22/docs/api/java.base/java/lang/foreign/package-summary.html)、[jextract](https://github.com/openjdk/jextract)。

MadDemo 当前内核绑定在 Android/JVM 使用 JNA，在 K/N 使用 cinterop。新工具应首先兼容这些资产；是否增加直接 JNI 或迁移某条路径，应由能力需求和测量决定。[现有构建配置](/Users/changyue/Desktop/MadDemo/build-logic/src/main/kotlin/mad.kernel-bindings.gradle.kts:31)

### 1.2 反向调用与导出

| 方向 | 方式 | 必须补充的协议 |
|---|---|---|
| **C/C++ → Kotlin/JVM** | JNI 调用编译后的方法；通过对象实现回调 | 类加载器、实际描述符、对象引用、线程接入、待处理异常与 R8 保留 |
| **C/C++ → K/N 导出 API** | K/N 生成的 C 接口，或当前工具链验证过的 @CName 入口 | 导出符号、函数签名、运行时初始化、对象/字符串释放方式 |
| **C/C++ → K/N 回调** | staticCFunction + context；需要时用 StableRef 找回 Kotlin 状态 | context 存活期、注册失败、同步调用、注销、在途回调与异常封装 |
| **C → JVM 的 JNA 回调** | JNA Callback | 强引用保活、调用约定、回调线程与取消/注销协议 |
| **C → JVM 的 FFM upcall** | Upcall stub | stub 与 Arena 的寿命、调用线程、异常处理及 native 停止使用的确认 |

staticCFunction 不能直接捕获任意 Kotlin 局部状态，通常需要单独 context；StableRef 应按实际保留期创建和释放。[K/N 回调机制](https://kotlinlang.org/docs/native-c-interop.html)

K/N 生成的 C API 对对象句柄与字符串提供相应的释放服务；应使用匹配工具链的生成声明，不手猜布局或直接 free。@CName 属于需要按工具链验证的导出路线，不把某个项目版本的成功推广为任意 Kotlin 版本都兼容。[K/N 动态库](https://kotlinlang.org/docs/native-dynamic-libraries.html)

### 1.3 Kotlin 开发者看到的接口

| 表达方式 | 使用条件 | 工具处理 |
|---|---|---|
| **直接使用简单映射类型** | 整数、字符串和小型值对象已经适合调用方 | 检查范围、空值、编码和支持能力 |
| **Kotlin Facade** | 需要隐藏指针、合并多个底层步骤、统一错误或提供异步 API | 根据协议生成调用接线，复用已有领域模型 |
| **独立 DTO 快照** | 要跨 source set、独立数据寿命或控制复制与共享 | 按选择的字段和一致性规则转换 |
| **资源对象** | 原生资源有关闭、线程或在途使用要求 | 生成有生命周期的包装，隐藏裸句柄 |

Facade 不必复制全部模型；独立 DTO 也不自动意味着深拷贝。快照的读取位置、嵌套资源和后续更新方式需明确。业务接口可以用 commonMain interface 加平台工厂实现，不必把每个原生函数都设计成 expect/actual。

## 2 新方案必须表达的边界契约

| 契约类别 | 必须明确的信息 | 工具可执行的工作 |
|---|---|---|
| **身份与能力** | 运行时、调用方向、后端、目标、工具链及权威声明 | 解析声明、准入检查、能力缺口报告 |
| **数据** | 数值范围、编码、空值、布局、长度与容量 | 转换、前后置检查、布局探针与输入测试 |
| **资源** | 创建者、关闭责任者、释放器、转移时刻、允许的共享 | 资源包装、调用许可、释放接线与计数 |
| **借用** | 输入保留期、稳定地址要求、结果依赖的 owner、修改失效条件 | 作用域包装、必要复制、保活及逃逸诊断 |
| **调用与完成** | 同步返回表示受理还是完成；是否阻塞；失败输出是否有效 | 返回值包装、完成状态机、错误清理 |
| **回调** | 是否同步触发、调用次数、线程、context 保留期、注销语义 | trampoline、引用注册、终态认领、在途跟踪 |
| **取消与交付** | 停止等待/观察/工作/撤销副作用；交付失败的资源归属 | 取消接线、迟到结果处理、resume 交接清理 |
| **关闭与并发** | 关闭准入、停止确认、线程亲和性、重入和共享状态同步 | 调度适配、关闭状态机、断言与竞争测试 |
| **流** | 状态或事件、顺序、容量、丢弃、共享订阅和恢复 | 有界分发、Flow 包装、消费生命周期接入 |
| **交付与演进** | API/ABI/行为兼容、支持矩阵、依赖与性能预算 | 构建指纹、兼容检查、真实消费、性能报告 |

例如，const uint8_t* 只表达一部分类型信息，无法证明原生函数不保存指针；一个 cancel 函数也无法证明返回时所有工作与回调都结束。缺少这些信息时，应要求补充契约、限制可生成的 API 或保留人工适配，不根据命名猜测。

## 3 工具生态与职责

| 工具或机制 | 主要解决什么 | 不负责什么 |
|---|---|---|
| **JNI + NDK/CMake** | JVM 与原生调用、编译和链接 | 业务模型、取消和所有权决策 |
| **fbjni** | C++ 侧 JNI 引用、类型转换、描述符和异常处理辅助 | 完整 KMP SDK 生成、K/N 运行时 |
| **JNA** | 通过 Java/Kotlin 声明调用 C ABI，提供回调机制 | 自动理解指针保留期、业务关闭和任意 C++ 对象 ABI |
| **JavaCPP** | 生成 Java/JNI 与 C++ 的绑定 | 自动推导所有领域转换与原生同步协议 |
| **Kotlin/Native cinterop** | 将受支持 C/Objective-C 声明转换为 K/N 绑定 | 自动提供安全的高层资源、suspend、Flow |
| **FFM + jextract** | 现代 JDK 的外部函数、内存作用域与 C 头绑定 | Android/K/N 的统一后端、修复原生越界 |
| **Clang + JVM 字节码分析** | 读取真实 C 声明、布局和 JVM 描述符 | 仅凭类型判断取消、恢复和线程语义 |
| **kotlinx.coroutines** | 任务、取消、异步适配和 Flow | 自动终止任意 C/C++ 工作或安全释放 callback context |
| **R8 + 构建与诊断工具** | 优化、保留规则、依赖打包、平台验证 | 替代真实 Release 反向调用和生命周期测试 |
| **mad-boundary** | 组合以上能力，生成协议适配，统一诊断和交付证据 | 自行重建通用 C++ 编译器或猜测业务行为 |

fbjni 的定位是 JNI 辅助库，JavaCPP 的定位是绑定生成；两者不是同一种职责。[fbjni](https://github.com/facebookincubator/fbjni)、[JavaCPP](https://github.com/bytedeco/javacpp)

rust-bindgen/cbindgen 在有 Rust 参与的路径上有价值，但不是这条直接 Kotlin ↔ C/C++ 路线的通用替代绑定器。已有 Kotlin ↔ Rust 产物应作为独立边界管理，不为所有 C++ 功能强行插入 Rust。

## 4 业界与项目的工程经验

| 来源 | 可确认的机制或代码事实 | 对新方案的输入 |
|---|---|---|
| **Android JNI 指南** | JNIEnv 按线程使用，局部与全局引用职责不同，字符串存在 Modified UTF-8 规则 | JVM 后端需要专门的引用、线程和编码策略。[官方指南](https://developer.android.com/ndk/guides/jni-tips) |
| **Android R8 指南** | native 反向访问需要精确保留；普通 native 方法规则不能覆盖所有回调 | 从同一接口清单生成消费者规则，并测试混淆后的应用。[R8 示例](https://developer.android.com/topic/performance/app-optimization/keep-rule-examples) |
| **JNA 回调文档** | 原生保存回调时，Java 侧必须保证回调对象仍可达 | 以注册对象持有回调，结合注销和在途协议回收。[回调说明](https://github.com/java-native-access/jna/blob/master/www/CallbacksAndClosures.md) |
| **协程资源交接文档** | resume 后可能在调度恢复前发生取消，资源未必交付 | async 模板增加交付失败清理，而非只包装 resume。[协程 API](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines/suspend-cancellable-coroutine.html) |
| **MadDemo 的内核构建** | Android/JVM 使用 JNA，K/N 使用 cinterop；消费前验证候选文件 | 按运行时注册后端，共享制品身份与消费验证；这条链路目标是 Rust 导出的 ABI。[构建插件](/Users/changyue/Desktop/MadDemo/build-logic/src/main/kotlin/mad.kernel-bindings.gradle.kts:31) |
| **MadDemo 的 SecurityRandom** | K/N 在 usePinned 内同步调用 SecRandomCopyBytes，并检查状态 | 可形成同步借用缓冲区模板；异步场景不能照搬其存活期。[实际实现](/Users/changyue/Desktop/MadDemo/shell/ios/src/iosMain/kotlin/com/mad/shell/ios/IosHost.kt:101) |
| **旧 mad 的 HUKS 适配** | .def 暴露有限 C 接口；空输入使用 null + 0；输出由状态与长度决定 | 自动生成零长度处理、成功后读取 out 参数、长度与容量校验。[定义文件](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ohos/kn/src/nativeInterop/huks/mad_huks.def:1)、[Kotlin 适配](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ohos/kn/src/ohosArm64Main/kotlin/com/mad/shellkit/ohos/HostSecureKeyStore.kt:196) |
| **MadDemo 的 @CName/dlsym** | Kotlin 导出入口与 C++ 函数指针分别维护 | 从权威声明派生或编译验证消费声明，防止签名漂移。[Kotlin 入口](/Users/changyue/Desktop/MadDemo/app/mad/src/ohosArm64Main/kotlin/com/mad/app/OhosEntry.kt:21)、[C++ 壳](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/cpp/napi_init.cpp:15) |
| **MadDemo Android 检查** | APK 对齐和全部 .so 的 LOAD 对齐一起检查，涵盖第三方库 | 门禁覆盖最终消费者的传递依赖，并增加实际环境验证。[检查脚本](/Users/changyue/Desktop/MadDemo/tools/android.sh:68) |
| **mad-boundary 的覆盖表** | 将 C++ → K/N 入口作为独立项，主要做启发式签名比对 | 补全直接 Kotlin ↔ C/C++ 的 JVM/Native 后端与验收范围。[现有覆盖表](/Users/changyue/Desktop/mad-boundary/docs/design.md:124) |

HUKS 的具体可补强点是：目前适配读取 outLen 并转换后才检查返回码，成功后也未显式验证长度不超过容量。更稳妥的模板应先验证状态，再检查原始长度范围，然后转换和复制。这是代码层面的边界加固建议，不表述为已经发生的线上事故。调用方检查返回长度，也不能弥补 native 侧已经发生的越界写入；两端都要遵守容量契约。

## 5 新版 mad-boundary 的模块职责建议

| 逻辑模块 | 单一职责 | 输入与输出 |
|---|---|---|
| **契约与能力模型** | 表达方向、类型、资源、执行语义和能力范围 | 权威源与语义策略 → 派生契约和缺口 |
| **声明读取与后端规划** | 读取编译上下文，选择适用绑定路线 | C/导出/JVM 声明 + 目标 → 构建与生成计划 |
| **JVM 绑定适配** | 对接 JNI/JNA，按需加入 JavaCPP/FFM | 契约与实际签名 → 平台绑定、注册与引用接线 |
| **K/N 绑定适配** | 对接 cinterop、C 导出与回调入口 | 头、.def、工具链 → 平台绑定及受限转换 |
| **运行时协议** | 管理资源、操作、回调、取消和分发 | 底层调用与策略 → 安全使用原语 |
| **Kotlin API 生成** | 生成适合业务消费的 Facade、资源、suspend 与 Flow | 契约与运行原语 → 业务接口与平台实现 |
| **验证与交付** | 执行检查和测试，组织可追溯制品 | 候选、消费者、矩阵 → 诊断、证据和交付物 |

以上是逻辑边界，不要求为每一项新建独立服务或仓库。可以映射到现有架构：

- 契约进入 model/rules；行为和支持范围进入既有配置协议。
- 声明读取进入 ContractReader；真实目标宏、头文件和 JVM 字节码都是输入。
- 后端通过 Generator/Toolchain 端口接入；能力选择集中在 registry/planning。
- JVM 与 K/N 的引用、指针实现分别进入平台运行时；共享业务语义可放在共同接口。
- Kotlin Facade 放入 sdk/language-api，观察作用域接入放入 ui-integration。
- 验证进入 Verifier，场景及故障注入进入 testkit，产物进入现有制品机制。

与现有模块的对应依据：[模块表](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)、[运行时与语言 API](/Users/changyue/Desktop/mad-boundary/docs/design.md:165)、[验证协议](/Users/changyue/Desktop/mad-boundary/docs/design.md:200)。

### 5.1 设计原则如何落实到代码

| 原则或模式 | 具体约束 |
|---|---|
| **单一职责** | 解析器不负责执行构建；转换器不决定业务重试；资源包装不管理账户生命周期 |
| **依赖倒置** | 核心模型和规则不依赖 JNI、cinterop、Gradle 或文件系统；外部工具通过窄端口接入 |
| **Adapter 与 Strategy** | 用适配器接外部工具，用集中策略选择后端和能力；避免模板中散落平台 if/else |
| **Facade 与接口隔离** | commonMain 暴露有限业务能力；JNIEnv、CPointer、JNA Structure 不进入普通消费者 API |
| **状态机** | 原生执行、等待者交付、资源关闭分别记录必要状态；不把三个阶段压成一个 completed 布尔值 |
| **RAII 与显式关闭** | 引用和短期借用尽量作用域化；需要确定性终止的资源保留关闭完成协议 |
| **组合优先** | 复用后端已有 owner；共享策略和测试，不强行共享 JVM 与 K/N 的引用实现 |
| **整洁代码** | 生成文件与手写扩展分开；不手改生成文件；错误目录集中；测试对准行为不变量 |

Kotlin 注解、扩展函数和委托可以降低日常接入成本，但不能靠语法推导原生内存与线程保证。属性访问也应避免隐藏阻塞调用、资源创建和其他不明显的副作用。

## 6 自动生成与手写的分界

| 内容 | 可以机械生成或调用现成工具 | 依据声明生成或执行 | SDK 作者负责 |
|---|---|---|---|
| **接口与构建** | cinterop 绑定、JNI 声明、注册表、构建清单 | 类型白名单、后端与目标选择 | 导出范围和公共能力 |
| **类型与错误** | 简单字段、数值检查、空值和编码转换 | 领域 ID、状态码和快照映射 | 单位、业务失败、复杂对象和恢复含义 |
| **资源与缓冲** | close 接线、长度检查、引用包装、已知复制 | 借用期限、拥有型缓冲、调用许可和清理执行位置 | 真实所有权、释放器、原生内部越界与别名正确性 |
| **单次异步** | trampoline、操作登记、suspend 外壳 | 完成认领、取消接线、交付失败及迟到清理 | 原生停止能力、重复结果语义、最终可释放时刻 |
| **Flow 与生命周期** | 订阅包装、scope 入口、诊断记录 | 容量、合并、共享、注销与恢复策略 | 状态或事件、重要性、丢失后的业务处理 |
| **并发与线程** | 已声明的调度、线程断言和测试场景 | 固定线程、串行化和关闭协调 | C/C++ 内部锁协议、线程安全和性能限制 |
| **交付与验证** | ABI/描述符 diff、R8 规则、依赖清单、测试骨架 | 版本矩阵、性能预算与升级验证 | 支持承诺、独立预期结果、发布和兼容决策 |

生成器的正确性与原生实现的正确性都需要验证。生成的测试骨架可以自动填入边界值和交错点，但不能完全根据同一段实现推导所有预期结果。

### 6.1 异步解码如何生成

下面是说明资源交接的协议示例，不是现有 mad-boundary 的 API 声明。

假设 C++ 解码函数返回后继续读取输入，稍后通过回调交付需要释放的图像。Kotlin 业务希望调用一个 suspend decode，并在用完图像后关闭资源。

首先必须声明：

| 项目 | 必须回答的问题 |
|---|---|
| **启动与输入** | 启动失败后是否可能回调；是否存在同步回调；输入何时不再被使用 |
| **结果所有权** | 每个结果是否转移独立资源；重复通知是同一资源还是新资源；由哪个函数释放 |
| **回调存活** | context 保留到何时；注销是否只阻止新回调，还是同时等待在途回调结束 |
| **取消** | 能否中断解码；什么时候确认已停止；只停止等待时谁继续收尾 |
| **线程** | 启动、回调、取消和销毁各自允许在哪个线程 |
| **关闭** | decoder 关闭是否影响已经返回的 image；渲染仍在使用 image 时能否释放 |

有了这些契约，工具才能生成下列流程：

1. 在调用 native 之前建立操作记录和回调保活；为异步读取准备符合协议的稳定输入存储。
2. 启动操作并处理异常或失败，同时允许 native 在启动尚未返回时就同步回调。
3. 用统一完成认领处理成功、失败和取消竞争；不能仅通过 isActive 检查后直接 resume。
4. 将成功结果包装为有明确 owner 的资源，并通过支持交付失败清理的恢复方式交给等待者。
5. 如果取消在资源交付前发生，按释放器和线程协议清理结果；不假设 resume 返回就代表消费方已经取得资源。
6. 如果原生工作仍未停止，保留其输入和 context；迟到结果按原生所有权协议处理，不重复释放同一对象。
7. 只有启动路径、原生保留期和相关在途回调都结束，才回收操作的上下文与临时资源；已成功交付的图像由其自身生命周期管理。

协程库提供资源交接所需的底层机制，但 native stop、注销和最终清理仍必须由协议衔接。[suspendCancellableCoroutine](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines/suspend-cancellable-coroutine.html)

## 7 实施顺序与验收

| 阶段 | 工作范围 | 完成条件 |
|---|---|---|
| **P0 契约和范围** | 盘点 JNA、cinterop、@CName 等现有入口；选真实 C/C++ 能力；确定权威源、类型子集、所有权和支持矩阵 | 每条选定路径有明确 owner、回调/取消协议和编译上下文；未知项有可执行的处理决定 |
| **P1 最小完整闭环** | 先在一条实际路径完成创建、调用、回调、取消、交付和关闭；再验证共享协议在另一个运行时的适配 | 正反调用和关键竞争通过；业务使用普通 Kotlin API；无未解释的资源残留 |
| **P2 后端与交付完善** | 根据需要补直接 JNI/JavaCPP 等路径；加入描述符生成、R8、ABI、版本与制品检查 | 声明的目标与 Release 消费通过；绑定、头和库配套；全新环境可复现 |
| **P3 体验和性能** | 完善 Flow、生命周期模板、诊断；根据真实负载优化批量、复制与并发；有需求再增加 FFM | 达到性能预算且不削弱生命周期保证；新后端有独立消费与竞态证据 |

已有 JNA 路线不因“统一架构”被自动迁移。K/N 直接 C 调用和既有 Rust 导出绑定也分别验证，避免把间接路径的成功当成新直接路径的成功。

验收按从契约到真实制品的顺序执行：

| 验收层 | 最少覆盖内容 |
|---|---|
| **接口与数据** | 描述符、导出符号、数值极值、空值、未知枚举、Unicode、空缓冲、输出容量与失败输出 |
| **内存与资源** | 分配器配对、临时指针、StableRef/GlobalRef/Callback 引用、关闭竞争、共享引用和视图失效 |
| **调用与取消** | 启动前取消、同步回调、注册失败、重复完成、resume 后取消、迟到结果与停止确认 |
| **线程与流** | 原生线程接入、固定线程、阻塞预算、回调重入、队列满、慢消费者、多观察者和作用域退出 |
| **构建与分发** | 实际编译宏、工具链、全部承诺 ABI、最低系统、混淆 Release、传递 .so、16 KB 环境和干净消费者 |
| **性能与诊断** | 跨界次数、复制量、端到端延迟、峰值内存、资源计数、符号与构建身份匹配 |

Verifier 结果应记录实际测试的库、应用和工具链身份。主机测试、模拟器、设备与插桩范围分开；passed、failed、skipped 与工具错误不混用。[现有证据协议](/Users/changyue/Desktop/mad-boundary/docs/design.md:200)

## 8 旧设计与讨论需要统一的表述

| 待统一内容 | 新方案采用的口径 |
|---|---|
| 所有 Kotlin 原生接口共用 JNI 后端 | 共享业务与契约，分开 JVM/Native 的绑定和引用实现 |
| JNI 内部调用 C++ 必须再套 C 门面 | 根据消费者与 ABI 需求决定，不做无目的的重复包装 |
| Kotlin 跨语言必经 JSON | 直接类型、缓冲、句柄和 DTO 均可；序列化按需求引入 |
| cinterop/JavaCPP 已经生成全部安全语义 | 它们生成绑定，所有权与运行协议需要明确补充 |
| StableRef 等于对象和数据地址都固定 | 它提供稳定间接引用，不代替数组地址的 pin/借用协议 |
| 协程完成等于原生完成和资源交付 | 三者存在不同竞争窗口，需要独立的责任与状态 |
| awaitClose 或取消处理器可以立即释放 context | 仍需确认 native 不再保留且在途回调不再访问 |
| 引用计数和 K/N GC 自动提供线程安全 | 业务共享状态和 C/C++ 内部数据仍需同步 |
| @CName/dlsym 签名扫描覆盖全部 Kotlin C++ 工程问题 | 还需 JVM 描述符、引用、R8、K/N 借用、制品与双向测试 |
| 既有 Kotlin Rust ABI 成功就是 C++ 直连成功 | 复用经验与工具资产，新边界保留独立验收 |
| FFM 可以立即替换所有 JVM/Android/K/N 方案 | 按运行时、部署 JDK、依赖与测试矩阵评估 |

