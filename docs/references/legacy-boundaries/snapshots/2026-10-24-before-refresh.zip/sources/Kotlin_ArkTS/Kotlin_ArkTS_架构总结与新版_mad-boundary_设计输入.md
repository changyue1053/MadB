# Kotlin ArkTS 架构总结与新版 mad-boundary 设计输入

整理日期：2026-10-23

新版 mad-boundary 应围绕“明确跨语言契约、生成重复代码、执行声明过的协议、验证真实消费结果”设计。调用桥、数据格式、异步语义和资源生命周期需要分别建模。

范围是 **Kotlin/Native ↔ ArkTS**，包括双向方法调用、宿主能力注入、状态订阅和生命周期回调。平台能力以目标 HarmonyOS / OpenHarmony SDK、API Level、运行时和锁定工具链为准。

本文作为后续架构设计的输入。现有方案、工程案例与新版模块建议分别说明；建议模块不代表当前工具已经提供全部能力。

配套明细：[Kotlin ArkTS 跨语言边界工程清单](/Users/changyue/Desktop/mad设计/Kotlin_ArkTS/Kotlin_ArkTS_跨语言边界工程清单.md)。该清单覆盖六组、28 项问题，本文归纳决策与设计约束。

## 1 已明确的架构结论

| 结论 | 对新设计的要求 |
|---|---|
| **调用机制与数据表示分开** | Node-API 是互操作底座；akinterop / KNOI 是调用桥；JSON 是载荷表示 |
| **JSON 是可选方案** | 同一 SDK 可以同时使用类型化参数、受限 DTO、JSON 载荷和二进制缓冲区；具体组合按后端能力准入 |
| **类型化 API 可以封装 JSON** | 业务开发者调用 `send()`、`observe()`，内部采用什么表示由适配层处理 |
| **Flow 与 JSON 没有必然关系** | Flow 需要订阅协议；每次回调可以携带 DTO，也可以携带 JSON |
| **直接传对象仍有成本** | 需要处理转换、代理身份、引用管理和跨界次数；不能直接等同于零拷贝或更快 |
| **单一所有权是关闭责任明确** | 可以有多个引用和观察者，但资源关闭由明确的 owner 决定 |
| **工具只能执行明确的语义** | “取消是否停止工作”“成功代表哪个阶段”等，必须由 SDK 作者声明 |

MadDemo 当前已经采用混合路径：平台能力走类型化接口，会话页通过 akinterop 传递受检 JSON。当前 wire-codegen 专门生成 JSON 载荷协议代码，尚不能据此推导出 DTO / JSON / 二进制后端可以一键切换。[平台接口](/Users/changyue/Desktop/MadDemo/abi-baseline/ffi_export.d.ts:10)、[会话接入决策](/Users/changyue/Desktop/MadDemo/docs/adr/ADR-028-conversation-wire.md:15)、[生成器设计](/Users/changyue/Desktop/mad-boundary/docs/design.md:583)

## 2 新方案必须覆盖的问题范围

原来的 28 项清单归纳为九组，作为模块设计与验收范围。

| 问题组 | 必须明确的内容 | 工具可以承担的工作 |
|---|---|---|
| **公开接口与类型** | enum / sealed / 泛型、可空值、稳定 ID、受支持的类型形状 | 能力检查、绑定生成、受限类型映射、导出面检查 |
| **载荷协议** | 字段、标签、数值范围、未知字段、默认值、大小限制 | 类型与编解码生成、接收端校验、协议差异检查 |
| **异步与订阅** | 同步首回调、重入、重复完成、迟到回调、取消、回放、背压 | 订阅 token、完成状态机、调度适配、清理模板 |
| **内存与所有权** | 创建 / 持有 / 关闭责任、借用期、缓冲区复制或转移、跨语言引用环 | 受管引用、作用域适配、释放检查、运行时诊断 |
| **线程与环境** | `napi_env` 所属线程、Main 初始化、Worker、多环境、环境退出 | 线程断言、按 env 隔离上下文、TSFN 调度与退出协议 |
| **UI 集成** | 可见、隐藏、销毁、后台、输入回声、列表更新 | 生命周期模板、状态选择器、ArkUI V1 / V2 适配 |
| **性能** | 调用频率、全量快照、编码解析、复制、队列和内存峰值 | 埋点、基准测试、预算检查、批量与增量接口支持 |
| **兼容与交付** | Kotlin fork / KSP / SDK 组合、d.ts、native ABI、载荷和行为兼容 | 版本锁、能力矩阵、基线检查、生成物与制品配对 |
| **验证与诊断** | 真实 ArkTS 消费、关闭竞态、失败路径、符号化 | 正反夹具、故障注入、目标编译、设备测试、证据记录 |

以下规则应进入契约和验收：

- **业务 ID 与运行时句柄分开**：业务 ID 可以按领域规则持久化；运行时句柄受实例和生命周期约束。
- **释放引用、停止观察、停止等待、停止工作、关闭资源分别定义**。降低 N-API 引用计数、删除引用句柄和取消业务任务不能合并成一个语义。
- **状态与事件分别定义**：状态可以按契约合并；事件的丢弃、重放和确认需要独立契约。
- **数值转换前校验**：不能先丢精度，再转成字符串。完整 64 位整数与 safe-int53 范围必须区分。
- **空值分别表达**：`null`、`undefined`、缺字段、空字符串和默认值不能相互掩盖错误。
- **能力绑定具体版本、方向、类型和执行环境**，不能笼统写“支持 Kotlin ↔ ArkTS”。
- **UI 观测不由类型断言产生**：解析后的对象仍需要按所选 ArkUI 状态机制接入。

依据：[Node-API 开发规范](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/napi-guidelines.md)、[引用与异步 API](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/reference/native-lib/napi.md)、[StateFlow 语义](https://kotlinlang.org/api/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines.flow/-state-flow/)。

## 3 工具生态在新架构中的位置

| 工具或机制 | 定位 | 使用边界 |
|---|---|---|
| **OpenHarmony Node-API + cinterop** | 底层互操作能力，以及特殊接口的补充路径 | 提供调用和引用等基础设施；线程、异常、内存协议仍需正确实现 |
| **akinterop** | 调用桥后端，复用其导出和代理生成能力 | 按版本、导出模式、调用方向和类型验证能力 |
| **KNOI** | 可评估的另一种调用桥后端 | 需要独立验证工具链兼容、初始化、类型转换和运行语义 |
| **kotlinx.serialization** | Kotlin 侧序列化基础设施 | 不负责 ArkTS 调用桥，也不自动生成 ArkTS SDK |
| **KSP** | 自定义生成器的开发基础设施 | 需要处理器与转换规则，不会自动推导业务语义 |
| **Kuikly Module** | 已采用 Kuikly 时的框架通信通道 | 按其模块接口和数据表示规则接入 |
| **coroutines、Node-API 调度设施** | 实现异步、订阅与线程协议的基础能力 | 单有 Promise、Job 或 TSFN 不代表取消与生命周期协议完整 |
| **DevEco / hvigor、Hypium / UiTest、Profiler / HiTrace** | 编译、真实消费测试和性能验证 | 编译、运行、性能分别形成证据 |
| **mad-boundary** | 统一契约、生成、适配、诊断和交付 | 复用成熟后端；业务决策与恢复策略由消费者定义 |

[KNOI](https://github.com/Tencent-TDS/KuiklyBase-components/tree/master/knoi)、[Kuikly Module](https://github.com/Tencent-TDS/KuiklyUI/blob/main/docs/DevGuide/expand-native-api.md) 和 [ByteKMP 实践](https://developer.volcengine.com/articles/7599494073556140086)展示了不同工程路径。业界调研用于形成候选方案，后端是否纳入支持范围，需要消费测试证明。

工具基础说明：[cinterop](https://kotlinlang.org/docs/native-c-interop.html)、[kotlinx.serialization](https://kotlinlang.org/docs/serialization.html)、[KSP](https://kotlinlang.org/docs/ksp-overview.html)。验证工具说明：[Hypium / UiTest](https://github.com/openharmony/testfwk_arkxtest/blob/master/README_en.md)、[Profiler / HiTrace](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/dfx/hitracemeter-view.md)。

## 4 mad 与 MadDemo 的工程经验

| 实际问题或风险 | 应沉淀的规则或测试 |
|---|---|
| 数字载荷转换成空串，随后被当作合法空命令 | 转换失败必须保留错误身份，不能被默认值掩盖 |
| 错误监听器触发 Kotlin 异常，随后残留 N-API 异常导致崩溃 | 同时验证语言异常与 pending exception；区分同步调用和异步通知 |
| 数值订阅 ID 存在收窄后误命中的风险 | 使用不透明句柄，并校验有效期与作用域 |
| 用 `toString()` 表达带数据状态 | 使用显式标签、字段和兼容策略 |
| 编码失败导致永久退订，页面停止更新 | 区分编码失败、协议拒收、投递失败，分别声明恢复策略 |
| `dispatch()` 返回 true，但业务尚未完成 | 分开表达“已转交、已受理、已完成” |
| 列表仅使用 ID 时状态更新不显示 | 单独验证 UI 观测与列表身份；不能把“状态拼进 key”推广为统一规则 |
| 生成代码通过测试，手写适配路径仍缺验证 | 验收覆盖生成代码、手写映射、运行时协议和实际页面 |

问题与风险出处：[数值 ID 与错误监听器复盘](/Users/changyue/Desktop/MadDemo/docs/progress/S4.md:792)、[错误载荷复盘](/Users/changyue/Desktop/MadDemo/docs/progress/S4.md:896)、[列表刷新复盘](/Users/changyue/Desktop/MadDemo/docs/progress/S4.md:746)。

当前处理与语义出处：[订阅适配](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/AkInteropAdapters.kt:37)、[动作入口](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/ConversationBridge.kt:56)、[载荷决策与演进](/Users/changyue/Desktop/MadDemo/docs/adr/ADR-028-conversation-wire.md:15)。

S11 收口仍记录三条手写路径缺少针对性测试：越界 seq 的行级降级、编码失败跳过本帧并保留订阅、ArkTS 拒收帧后保留上一份状态。生成器测试不能替代这些适配行为的测试。[遗留记录](/Users/changyue/Desktop/MadDemo/docs/adr/ADR-028-conversation-wire.md:96)

## 5 新版 mad-boundary 的模块职责建议

以下是后续设计的职责边界。

| 模块 | 单一职责 |
|---|---|
| **契约模型与能力检查** | 描述接口、数据、行为、所有权及后端支持范围 |
| **调用后端适配** | 接入 akinterop、KNOI 等，隔离后端差异 |
| **载荷生成** | 按选定表示生成类型、转换和校验代码 |
| **运行时适配** | 实现声明过的订阅、调度、取消、引用与关闭协议 |
| **语言 API 与 UI 集成** | 提供类型化 Facade，并适配 ArkUI 生命周期和状态机制 |
| **验证与诊断** | 执行规则、契约测试、消费测试，报告失败和证据缺口 |
| **构建与交付** | 固定工具链、管理生成物、检查兼容、配对 SDK 制品 |

设计原则对应到代码：

- **单一职责、依赖倒置**：核心契约和规则不依赖某个桥接工具。
- **Adapter / Strategy**：后端通过小接口接入，支持组合必须显式声明。
- **Facade**：隐藏编解码和句柄细节，同时保留取消、受理和关闭语义。
- **状态机**：处理注册、完成、取消、关闭及其竞态。
- **函数核心、命令外壳**：规则计算与文件、进程、编译器调用分离。
- **组合优于继承**：复用后端已有能力，避免叠加重复的引用管理和关闭体系。

模块可以继承当前设计中的 Reader、Generator、Verifier、Toolchain 等职责分离原则；需要重新核对的是契约字段、后端能力组合与适配协议，而不是仅按语言增加更多包装层。[现有模块与原则](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)

## 6 自动生成与手写的分界

| 可以机械生成 | 根据声明生成或执行 | 必须由开发者决定 |
|---|---|---|
| 类型、绑定、字段转换、编码解码、校验、类型声明 | 线程切换、订阅登记、取消接线、资源清理、生命周期模板 | 公开哪些能力、领域模型如何映射、谁拥有资源 |
| 基线差异、生成物漂移、编译检查、测试骨架 | 未知值处理、错误映射、队列策略、兼容策略 | 何时算受理、是否重试、如何补偿、允许怎样降级 |

**每类信息应有明确的权威源。** 导出接口可以来自语言声明；序列化载荷可以来自 Schema；无法从类型推断的行为通过显式策略补充。相同字段不应在 Kotlin、ArkTS 和配置中各维护一份。

生成代码与手写扩展点分开；生成区可以确定性重建。业务含义不明确、类型不支持或生命周期无法建立时，应报告具体缺口，不能静默降级成另一种数据表示或忽略检查。

## 7 下一轮设计的决策与验收

优先确定五件事：

1. **后端支持范围**：首批覆盖哪些 akinterop / KNOI 版本及工具链组合。
2. **数据表示选择**：哪些接口直接映射，哪些使用 JSON，哪些使用二进制；明确支持的 DTO 子集。
3. **运行时协议**：订阅、取消、关闭、回调线程和环境退出分别如何表达。
4. **开发者 API**：哪些直接生成，哪些生成一次骨架，哪些通过手写扩展点接入。
5. **验证标准**：哪些能力需要目标编译、真实运行时或设备证据。

验收逐层建立：

**契约检查 → 确定性生成 → 两端协议测试 → 真实 ArkTS 编译 → N-API 消费与竞态测试 → 制品及性能验证。**

Node / JVM 测试可以验证部分协议行为；真实 ArkTS 编译和设备运行需要独立证据。“生成成功”“编译通过”“启发式未发现问题”应分别报告，不能统一表达为“边界已安全”。

每个支持组合应对应明确的测试输入、生成物、原生库、应用包与工具链身份。未知能力、未执行测试和过期证据应单独呈现，不得算作通过。

## 8 旧设计需要统一的表述

| 待统一内容 | 新方案采用的口径 |
|---|---|
| 问题清单、工具能力、业界候选混写 | 问题清单描述需要覆盖的风险；能力矩阵描述支持组合；调研案例形成候选方案 |
| 把按场景选择数据表示全部写成未来扩展 | 当前已经存在混合路径；通用生成器跨表示切换需要单独设计 |
| 把“句柄 / ID”合并并统一禁止持久化 | 区分业务身份与运行时资源身份 |
| 用单次 `napi_reference_unref` 代表完整引用清理 | 区分引用计数、引用句柄删除与业务取消，并由 owner 按协议配对 |
| 把“ArkTS 只有 as、没有校验”继续写成现状 | 保留为历史案例；当前页面已调用生成的受检解码器 |
| 把客户端样例视为任意 SDK 自动生成能力 | 明确机械生成、模板接入和手写扩展的范围 |

对应旧表述：[ID 与句柄](/Users/changyue/Desktop/mad-boundary/docs/design.md:287)、[引用清理映射](/Users/changyue/Desktop/mad-boundary/docs/design.md:492)、[旧校验描述](/Users/changyue/Desktop/mad-boundary/docs/design.md:306)。当前行为可核对[状态接收端](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/ets/pages/ConversationNative.ets:42)与[类型化客户端样例](/Users/changyue/Desktop/mad-boundary/examples/arkui-v1-conversation/ConversationClient.ets:1)。
