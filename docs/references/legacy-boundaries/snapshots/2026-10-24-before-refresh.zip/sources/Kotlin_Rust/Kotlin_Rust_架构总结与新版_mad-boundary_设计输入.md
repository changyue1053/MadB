# Kotlin Rust 架构总结与新版 mad-boundary 设计输入

整理日期：2026-10-23

**新版 mad-boundary 应复用成熟绑定后端，把 Kotlin ↔ Rust 的类型适配、运行协议和制品验证统一起来。** 对 MadDemo，优先沉淀受检映射、取消与关闭契约、真实 JVM / Native 消费测试；新后端和性能优化按验证结果准入。

范围包括 Kotlin/JVM（含 Android）↔ Rust、Kotlin/Native ↔ Rust，以及 Rust 调用 Kotlin 实现的宿主接口与回调。C/C++ 只作为原生能力内部依赖或 C ABI 接入路线讨论。

配套明细：[Kotlin Rust 跨语言边界工程清单](/Users/changyue/Desktop/mad设计/Kotlin_Rust/Kotlin_Rust_跨语言边界工程清单.md)，覆盖六组、26 项问题。本文沿用 Kotlin ArkTS、Kotlin/Native Swift 总结的结构，归纳后续工具设计的决策与约束。

## 1 已明确的架构结论

| 结论 | 对新设计的要求 |
|---|---|
| **Kotlin 运行环境必须区分** | JVM 与 Native 使用独立的后端能力、线程和装载规则，共享 API 不代表底层机制相同 |
| **上游与 fork 必须区分** | 能力绑定实际版本和补丁集合，不按工具名称直接推断 |
| **类型化调用不要求业务 JSON** | 复用绑定的参数与返回值转换；内部缓冲编码不作为公开持久化协议 |
| **模型权威源按边界确定** | Rust SDK 可以以 Rust 声明为源；Kotlin 领域模型仅在有隔离需求时另做映射 |
| **引用有效与资源可操作分开** | Arc、GC 和绑定引用保证的一部分内存寿命，不能替代业务关闭状态 |
| **取消效果逐接口声明** | 停止等待、停止工作、停止观察和撤销副作用分别表达 |
| **通用工具执行明确协议** | 生成重复代码和验证契约；领域协调与恢复策略由消费者定义 |

### 1.1 MadDemo 的实际路径

| 环境 | 调用路径 | 验证重点 |
|---|---|---|
| **Android / JVM** | Kotlin → 生成绑定 → JNA → 动态 Rust 库 | 装载、JNA 与目标 ABI、回调线程、运行期校验 |
| **iOS / 鸿蒙** | Kotlin/Native → 生成绑定 → cinterop → 静态链接的 Rust 库 | 原生接口、链接、回调保活、目标库与绑定配对 |
| **Rust 调用 Kotlin** | Rust 约定的 trait / callback → 生成桥 → Kotlin 实现 | 回调签名、线程、异常、保活和释放 |

MadDemo 共用 `commonMain` 绑定，平台实现接入各自源集；Android 复用 JVM 绑定，Native 用 cinterop。绑定与内核装载集中在 `capability/kernel`。[构建配置](/Users/changyue/Desktop/MadDemo/build-logic/src/main/kotlin/mad.kernel-bindings.gradle.kts:1)、[模块职责](/Users/changyue/Desktop/MadDemo/capability/kernel/build.gradle.kts:1)

当前 Gobley fork 源自 0.3.7，适配 UniFFI 0.32.1。它显式拒绝 async 和 Rust Object；不能据此宣称上游也不支持。新版工具应把这类支持子集建成后端能力数据。[fork 说明](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/FORK-PROVENANCE.md:1)

### 1.2 数据和资源的三种表示

| 表示 | 适合什么 | 必须明确什么 |
|---|---|---|
| **Record / Enum 等值数据** | 配置、查询结果、错误详情、状态投影 | 字段、范围、复制成本及嵌套内容；生成 Kotlin 类型不要求额外领域 DTO |
| **生成的 Object / trait 代理** | 后端已支持并验证的共享资源与对象能力 | 引用释放、并发访问、业务 close；MadDemo 当前 fork 不开放 Rust Object 导出 |
| **不透明句柄加函数** | 受限后端或显式资源表 | 创建、有效期、准入、关闭、复用规则与诊断；句柄不是业务 ID |

UniFFI 通过生成的 ABI 层转换参数与结果，复杂类型使用内部缓冲表示。该内部格式可能随版本变化，不能当作长期存储或网络协议。[转换机制](https://mozilla.github.io/uniffi-rs/latest/internals/lifting_and_lowering.html)

MadDemo 的 Rust 门公开存储、网络和推理能力，KMP 的 Port 适配器隔离领域模型与绑定类型。这一分层支持生成机械映射，也保留领域差异的手写入口。[Rust 门](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/lib.rs:1)、[Kotlin 适配](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ffi/UniffiImLinkPort.kt:23)

## 2 新方案必须覆盖的问题范围

26 项清单归纳为九组，作为模块与验收设计的范围。

| 问题组 | 契约内容 | 工具职责 |
|---|---|---|
| **导出与类型** | 运行环境、方向、类型子集、命名、泛型、集合、数值与可空值 | 能力判定、生成、受检转换、类型探针 |
| **模型与 ABI** | 权威源、值数据或代理、布局、编码、输入约束 | 元数据读取、表示适配、参数检查 |
| **错误与异步** | 业务失败、panic、回调异常、任务运行时、完成与取消 | 错误映射、异步接线、竞态验证 |
| **状态与事件** | 容量、顺序、回放、确认、溢出、订阅与退订能力 | 订阅适配、队列原语、场景测试 |
| **所有权与关闭** | owner、借用、保活、句柄有效性、关闭准入与在途工作 | 资源包装、清理接线、生命周期诊断 |
| **线程与并发** | 调用与回调执行器、阻塞性、同步协议、重入 | 调度适配、线程检查、交错测试 |
| **UI 与性能** | 页面观察与账户资源的关系、跨界频率、复制、峰值内存 | 作用域模板、批量接口支持、基准与预算 |
| **兼容与交付** | 工具链、API / ABI / 行为、装载、重复库、绑定与制品配对 | 版本锁、差异检查、manifest、平台消费 |
| **验证与诊断** | 双端运行、故障注入、符号、证据覆盖 | 夹具、运行器、报告和缺口说明 |

其中四条协议不能从函数签名推导：

- **取消是否停止底层工作。** MadDemo 网络超时只放下等待，推理通过取消信号协作停止，两者需要不同声明。
- **关闭何时完成。** 停止新调用、撤销句柄、排水、释放引用和释放底层资源是不同步骤。
- **回调失败如何恢复。** 存储增量可以通过快照恢复，网络响应丢失可能要求断开链路；工具不能自行替换策略。
- **观察者是否拥有订阅。** 原生接口只支持一次常驻订阅时，页面取消观察不能自动变成原生退订或资源关闭。

## 3 工具生态在新架构中的位置

| 工具或路线 | 负责什么 | 使用边界 |
|---|---|---|
| **UniFFI** | Rust 契约元数据、ABI 脚手架与语言绑定基础能力 | 不替代领域语义、资源关闭和恢复策略 |
| **Gobley** | 基于 UniFFI 生成 KMP 绑定，并提供构建集成 | 上游与自维护 fork 独立验证；官方目标支持不能自动外推到任意平台 fork |
| **C ABI + cbindgen + cinterop** | 从 Rust C 接口生成头文件，供 Kotlin/Native 接入 | 安全包装与所有权仍需设计；JVM 需要另外的接入方式 |
| **JNI / jni-rs** | Android / JVM 的专门原生接入 | 处理 JNI 引用、线程与异常；不覆盖 Kotlin/Native |
| **rust-bindgen** | 从 C/C++ 头生成 Rust 声明 | 用于 Rust 接原生库，不是 Kotlin SDK 生成器 |
| **coroutines 与 Rust 并发设施** | 提供任务、同步、队列、取消信号等基础能力 | 两侧执行协议和任务归属必须一致 |
| **mad-boundary** | 统一契约、生成适配、执行验证和管理制品证据 | 复用成熟后端，保留业务决策与特殊实现扩展点 |

依据：[Gobley](https://gobley.dev/docs/)、[cbindgen](https://github.com/mozilla/cbindgen)、[cinterop](https://kotlinlang.org/docs/native-c-interop.html)、[JNI 实践](https://developer.android.com/ndk/guides/jni-tips)、[rust-bindgen](https://rust-lang.github.io/rust-bindgen/)。

UniFFI 的异步桥需要按生成器版本和目标确认。上游 Kotlin 模板已有取消等待及释放相关接线；是否停止派生任务或撤销副作用，由实际库协议决定。MadDemo 的同步加回调路线不需要为统一外观而强行改为 Rust async。[异步模板](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/uniffi_bindgen/src/bindings/kotlin/templates/Async.kt)

## 4 mad 与 MadDemo 的工程经验

| 案例 | 应沉淀的规则或测试 |
|---|---|
| 数值直接转换存在越界风险，随后集中到 `WireRange` | 自动生成受检转换，按字段声明范围与溢出策略，不使用统一的静默截断 |
| 网络请求取消后，远端工作仍可能继续 | 等待者数量与真实工作占用分开；迟到响应有归属，名额释放可验证 |
| 取消可能跳过关库，下一次打开报已打开 | 必需清理由正确 owner 驱动，覆盖派发前取消和阻塞关闭超时 |
| mad 的普通事件与关户最后一批事件来自不同执行路径 | 回调契约包括同步交付与具体线程，不假定“所有回调都是后台异步” |
| 存储单订阅和页面多观察者需求不同 | 生成 Flow 前检查订阅能力；必要的共享关系由作用域适配承接 |
| Native 静态链接不做运行期逐函数校验 | 构建期按来源、特性、元数据和摘要配对，并运行真实 Native 消费 |
| Rust 错误字段可能撞 Kotlin Throwable 成员 | 生成前检查目标语言 API 冲突，输出可定位的诊断 |
| 上游曾修复 ARM32 返回值与 aarch64 checksum 问题 | 生成器进入真实目标矩阵；宿主构建通过不能替代平台证据 |

项目依据：[受检转换](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ffi/WireRange.kt:3)、[在途与取消](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:12)、[关库清理](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ImParticipant.kt:92)、[mad 回调](/Users/changyue/Desktop/学习2/mad-platform/capability/im/engine/src/nativeMain/kotlin/com/mad/capability/im/engine/ffi/UniffiKernelPort.kt:129)。

生成与交付依据：[订阅能力](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226)、[Native 配对](/Users/changyue/Desktop/MadDemo/capability/kernel/src/nativeMain/kotlin/com/mad/kernel/KernelLoader.native.kt:6)、[名称冲突检查](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/src/gen_kotlin_multiplatform/mod.rs:287)、[UniFFI 修复记录](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/CHANGELOG.md)。

MadDemo 的重构把业务协调收回 KMP，Rust 门承担原生能力接入与协议转换。该责任划分应保留在工具设计中：可以检查协调逻辑是否越界，但不能把发件箱调度、重连、ACK 认领和业务恢复复制成通用工具运行时。[边界决策](/Users/changyue/Desktop/MadDemo/docs/adr/ADR-024-kernel-boundary-store-link.md:1)

## 5 新版 mad-boundary 的模块职责建议

| 模块 | 单一职责 | 输入与输出 |
|---|---|---|
| **契约模型与能力检查** | 描述接口、运行环境、方向、类型、所有权和行为保证 | Rust 元数据、语义策略、能力表 → 契约视图与缺口 |
| **绑定后端适配** | 包装锁定版本的 UniFFI / Gobley 或 C ABI 接入路径 | 后端配置、目标和工具链 → 生成及编译任务 |
| **类型适配生成** | 补充领域与绑定间可机械推导的数值、ID、枚举、错误及简单 Port 映射 | 契约视图、映射规则 → Kotlin / Rust 适配与校验 |
| **运行时协议适配** | 执行声明过的线程、回调、保活、取消与关闭协议 | 成熟绑定与行为策略 → 受控任务、订阅、资源包装 |
| **语言 API 与作用域集成** | 提供惯用 Kotlin 接口，将观察、任务和资源接入正确作用域 | 类型化 SDK、owner 策略 → Facade 与接入模板 |
| **验证与诊断** | 检查导出、竞态、真实消费和性能，记录失败与证据缺口 | 场景、制品、测试结果 → Findings、Gaps、证据 |
| **构建与交付** | 管理生成物、二进制、工具链、目标和符号的一致性 | 构建计划、版本锁 → 可追溯 SDK 制品 |

职责可以映射到现有 Reader、Generator、Verifier、Toolchain、`model/rules` 和 SDK adapters，不要求为每种语言再复制一套核心。[现有模块](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)

设计原则落实为代码约束：

- **单一职责与依赖倒置**：核心契约和规则不依赖 Cargo、Gradle 或特定生成器，外部调用通过窄端口完成。
- **Adapter 与 Strategy**：后端实现可替换，支持组合显式登记，差异不散落到业务模板。
- **Facade**：隐藏重复转换，保留取消、受理和关闭的语义。
- **状态机与作用域管理**：用明确状态表示注册、完成、取消、关闭；复用现有资源 owner，避免双重关闭体系。
- **函数核心与命令外壳**：规则计算保持纯函数，文件、进程和制品写入留在外层。
- **整洁代码**：生成区和手写区分离，错误分类集中，接口小而具体；测试验证协议不变量，而非复制实现步骤。

## 6 自动生成与手写的分界

| 内容 | 可以机械生成 | 根据声明生成或执行 | 开发者负责 |
|---|---|---|---|
| **公开接口与类型** | 绑定、基本类型转换、字段映射、名称检查 | 范围校验、ID 包装、未知值处理 | 公开能力、字段语义、单位和领域边界 |
| **调用与异步** | 参数接线、结果转换、回调包装 | 执行器切换、取消传播、一次完成协议 | 阻塞性、任务归属、受理与完成的含义 |
| **资源生命周期** | 标准清理模板、诊断埋点 | 保活、关闭准入、排水与作用域接入 | owner、借用期、底层资源关闭实现 |
| **状态与事件** | 类型化观察入口、场景骨架 | 队列容量、共享订阅和溢出信号 | 交付保证、快照恢复、幂等与重放 |
| **工程保障** | 漂移检查、元数据差异、打包清单 | 平台矩阵、验收门槛、性能预算检查 | 独立期望值、业务不变量和支持策略 |

**每类信息有明确权威源。** Rust 声明和实际编译元数据描述公开接口，行为策略补充无法从类型推断的语义；领域映射只描述必要差异。派生的中间模型用于生成与验证，不要求开发者再维护一份完整业务 IDL。

复杂对象图、未知生命周期或不支持的类型进入显式扩展点。生成器不能通过默认值、强制转换、全局作用域或静默换成 JSON 来掩盖缺失契约。

## 7 下一轮设计的决策与验收

优先顺序分三层：

1. **P0 契约与支持范围**：固定 JVM / Native、上游 / fork 的能力组合；明确取消效果、关闭责任、回调执行位置和制品身份。
2. **P1 重复适配与验证**：生成受检数值、枚举、错误和简单 Port 映射；建立真实双向消费、取消与关闭竞态夹具。
3. **P2 能力扩展与性能**：评估上游升级、Object / async、更高效的缓冲路径；以兼容证据与性能数据准入。

验收逐层建立：

**契约检查 → 确定性生成 → Rust / Kotlin 编译 → JVM 与 Native 双向消费 → 生命周期与交错测试 → Release 与制品验证 → 性能和诊断验证。**

| 验收层 | 最少覆盖的内容 |
|---|---|
| **类型** | 数值边界、空值、嵌套集合、枚举、回调、名称冲突；实际生成 API 可使用 |
| **调用** | 同步首回调、重入、重复完成、取消与应答相撞、结果无人接收、回调抛错 |
| **资源** | 并发关闭、调用者取消、关闭超时、在途保活、旧句柄、引用环、单订阅与多观察者 |
| **事件** | 慢消费者、队列满、丢批、重复批、快照期间增量、迟到 ACK、容量归还 |
| **制品** | 错版本拒载、元数据一致、特性一致、目标架构、静态与动态链接、干净环境、Release |
| **诊断与性能** | 正确符号与构建身份、错误可定位、载荷脱敏；真实数据量下延迟、复制和内存预算 |

业务契约版本、UniFFI / 生成器版本、函数签名检查和文件摘要是不同维度。静态链接与动态装载可以使用不同校验机制，但都需要证明消费的绑定和原生实现匹配。

测试结论绑定具体源码、工具链、生成物和制品。Rust 单测、Kotlin 单测、JVM 真实 FFI、Native 真实 FFI、设备与性能证据分别记录；缺证据、未支持和启发式零命中不计作完整通过。[证据测试](/Users/changyue/Desktop/mad-boundary/tests/test_evidence.py:44)、[漏报探针](/Users/changyue/Desktop/mad-boundary/tests/test_known_misses.py:1)

## 8 旧设计与讨论需要统一的表述

| 待统一内容 | 新方案采用的口径 |
|---|---|
| Kotlin Rust 只有一种调用方式 | JVM 与 Native 分开，正向调用与反向回调分开 |
| 当前 fork 的限制就是 UniFFI 能力 | 以版本、补丁和目标组合表达支持范围 |
| UniFFI 完全没有取消 | 核对具体绑定的等待、释放和任务接线；业务停止与回滚另行声明 |
| 所有模型都定义在 Kotlin | Rust SDK 契约可定义在 Rust；领域模型权威源按职责确定 |
| 类型化传输没有编码或复制成本 | 内部表示转换与业务序列化协议分开，性能以测量为准 |
| 有 Arc 或 GC 就无生命周期问题 | 区分内存寿命、引用环、资源有效性和确定性关闭 |
| 跨异步边界一律复制 | 按协议选择复制、所有权转移或安全共享 |
| Drop 或析构发生就算泄漏 | 正常回收与违反关闭契约分别诊断 |
| 回调包装成 Flow 就获得完整订阅语义 | 检查原生注册、退订、共享、背压及终止能力 |
| 两端枚举都可按 ordinal 对齐 | 跨领域映射按明确语义；生成协议内部标签由同一绑定体系维护 |
| 链接或编译成功等于 SDK 兼容 | 增加真实消费、行为、目标及制品一致性验证 |

相关旧设计位置：[后端能力](/Users/changyue/Desktop/mad-boundary/docs/design.md:126)、[ID 与句柄](/Users/changyue/Desktop/mad-boundary/docs/design.md:287)、[异步内存策略](/Users/changyue/Desktop/mad-boundary/docs/design.md:347)、[回收与泄漏](/Users/changyue/Desktop/mad-boundary/docs/design.md:351)。
