# Kotlin Rust 跨语言边界工程清单

整理日期：2026-10-23

**Kotlin ↔ Rust 的工程边界由绑定、数据语义、运行协议和制品验证共同组成。** UniFFI / Gobley 可以生成大量重复代码；资源归属、取消效果、事件可靠性与恢复策略需要 SDK 作者明确，再交给工具执行和验证。

范围包括 Kotlin/JVM（含 Android）↔ Rust、Kotlin/Native ↔ Rust，以及 Rust 通过受支持的 trait / 回调接口调用 Kotlin。按公开契约、调用协议、运行安全、UI 与性能、工程交付、验证诊断六层组织，共 26 项，不列实现进度。

MadDemo 当前使用 UniFFI 0.32.1 加 Gobley 0.3.7 派生的 fork：Android / JVM 经 JNA 调用，iOS / 鸿蒙经 cinterop 静态链接。fork 明确拒绝 async、Rust Object、Box / Set 等未验证的导出形状；这些限制不能推广为上游整体能力。[构建配置](/Users/changyue/Desktop/MadDemo/build-logic/src/main/kotlin/mad.kernel-bindings.gradle.kts:1)、[fork 来源](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/FORK-PROVENANCE.md:1)、[生成器限制](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/src/gen_kotlin_multiplatform/mod.rs:279)

配套决策：[Kotlin Rust 架构总结与新版 mad-boundary 设计输入](/Users/changyue/Desktop/mad设计/Kotlin_Rust/Kotlin_Rust_架构总结与新版_mad-boundary_设计输入.md)。

## 一 公开契约与数据

目标：公开能力可表达，传递后的数据含义不变。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **1. 后端与导出能力** | 按运行环境、生成器版本、调用方向和类型形状建立能力表；不支持时明确拒绝 | UniFFI 元数据、Gobley、能力探针、目标编译 | MadDemo fork 明确拒绝 async / Object，避免输出未经验证的 ABI。[限制](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/src/gen_kotlin_multiplatform/mod.rs:279) | JVM 支持不能自动算 Native 支持；上游能力不能自动算 fork 能力 |
| **2. 模型权威源与数据语义** | Rust SDK 契约可以定义在 Rust；生成 Kotlin 类型，领域隔离需要时再做 Port 映射；区分值数据、资源代理与句柄 | Record / Enum 生成、受限 Adapter、类型契约 | MadDemo 的 `uniffi.toml` 生成只读字段记录，领域端通过 `UniffiImLinkPort` 映射；`val` 不自动保证所有嵌套内容不可变。[配置](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/uniffi.toml:1)、[适配](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ffi/UniffiImLinkPort.kt:23) | 是否复制、是否共享、修改是否回写有明确说明；不重复维护等价业务模型 |
| **3. 数值 可空值与稳定 ID** | 区分 `u64 / ULong / Long`、范围、单位、空值和业务身份；跨模型枚举按语义映射 | 受检转换、强类型 ID、穷尽映射、边界值测试 | MadDemo 集中使用 `WireRange`，入参越界拒发，入站越界按协议处理；上限字段的饱和转换另有明确规则。[代码](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ffi/WireRange.kt:3) | 不截断、不误用默认值；不把句柄当业务 ID；不靠两套枚举的 ordinal 对齐 |
| **4. ABI 表示与输入校验** | 使用选定后端的 ABI；手写 C ABI 时明确布局、长度、编码及释放函数；业务入口另验范围和大小 | 生成绑定、cbindgen、cinterop、布局探针、参数校验 | UniFFI 对复杂数据采用内部缓冲区表示，并非直接暴露任意 Rust 类型布局。[转换机制](https://mozilla.github.io/uniffi-rs/latest/internals/lifting_and_lowering.html) | 目标宽度与布局正确；非法输入得到稳定错误；不能将 Rust `String / Vec` 的内部布局当公共 C ABI |
| **5. 名称与生成 API 冲突** | 检查关键字、目标语言基类成员、重载与跨模块名称；允许显式重命名 | 生成前诊断、实际 Kotlin 编译、API 基线 | MadDemo fork 拒绝与 Kotlin Throwable 的 `message / cause` 属性冲突的错误字段。[代码](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/src/gen_kotlin_multiplatform/mod.rs:287) | Kotlin 接口可直接编译使用；改名可追踪，不能静默丢字段 |

生成器负责 ABI 与表示转换。公开字段的含义、单位、默认值、业务 ID 和独立领域模型的选择属于 SDK 契约设计。

## 二 调用与异步协议

目标：调用结果、线程、取消与事件交付具有可验证的含义。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **6. 业务失败与 panic** | 业务失败使用 Result / 稳定错误；panic 在边界封闭，并定义故障后资源是否仍可用 | UniFFI Error、错误目录、panic 边界、故障注入 | MadDemo 的错误码在 Rust 统一定义，导出门通过 `guarded` 捕获展开式 panic。[错误表](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/error.rs:1)、[边界](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/lib.rs:40) | 不把内部故障当普通业务拒绝；不能因捕获 panic 就认定状态可安全继续 |
| **7. Kotlin 反向回调失败** | 明确允许的回调错误、未知异常和交付失败；将恢复动作交给所属领域 | trait / callback 绑定、错误适配、交付状态、回调故障测试 | MadDemo 存储监听器失败按接不住处理；网络监听器失败进入链路交付失败路径。[存储回调](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:206)、[网络回调](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/link.rs:29) | 异常不静默吞掉，不把丢失的批次当成功；恢复范围与错误分类一致 |
| **8. 执行位置与阻塞** | 分别声明调用执行器、回调执行器和阻塞性；存储、推理等阻塞调用使用适当执行位置 | Dispatcher、主线程守卫、执行器适配、耗时测试 | MadDemo 的 `KernelRuntime.call` 集中执行主线程检查；检查本身不负责切线程。[代码](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/KernelRuntime.kt:64) | 重 I/O 和长计算不占 UI 线程；同步函数、非阻塞受理、async 分开建模 |
| **9. async 运行时与任务归属** | 确认绑定支持；明确 Future 由谁驱动、是否依赖 Tokio 等运行时、任务随谁结束 | 选定版本的异步桥、运行时 Adapter、Scope 策略 | 上游 UniFFI 能桥接 async；MadDemo fork 将其排除在验证范围外。[官方机制](https://mozilla.github.io/uniffi-rs/latest/internals/async-overview.html)、[fork 说明](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/FORK-PROVENANCE.md:1) | async 不被当作自动后台执行；运行时要求满足；任务无隐式永久存活 |
| **10. 取消 超时与副作用** | 区分停止等待、请求停止工作和撤销结果；结果未知时采用领域定义的查询、幂等或补偿 | 取消接线、操作 ID、协作式取消、超时测试 | MadDemo 网络超时只放下等待，远端在途名额仍保留；推理通过回调读取取消信号。[请求等待](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:12)、[推理](/Users/changyue/Desktop/MadDemo/capability/infer/engine/src/commonMain/kotlin/com/mad/infer/engine/ffi/UniffiInferKernelPort.kt:28) | 取消效果准确；不提前归还仍被占用的容量；已提交事务不被误认为撤销 |
| **11. 重入 完成竞态与结果交接** | 允许声明同步回调；先登记再触发；完成与取消通过明确的认领协议协调，未被接收的资源结果按契约释放 | 一次完成状态机、取消清理、屏障与交错测试 | mad 关户最后一批事件在关闭调用线程同步交付；MadDemo 在发送前登记等待者。[mad 回调](/Users/changyue/Desktop/学习2/mad-platform/capability/im/engine/src/nativeMain/kotlin/com/mad/capability/im/engine/ffi/UniffiKernelPort.kt:129)、[登记顺序](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:81) | 同步首回调、重复完成、迟到结果、完成与取消相撞都可重复验证 |
| **12. 订阅 背压与事件恢复** | 明确订阅数量、退订能力、容量、顺序、溢出和快照水位；状态合并与可靠事件分开 | Channel、Flow Adapter、序号与水位、故障注入 | MadDemo 存储常驻单订阅，以 `commit_seq` 与快照恢复；网络响应不能合并，队列满按链路失效处理。[订阅约束](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226)、[存储流](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/EventStream.kt:9)、[网络队列](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/LinkInbox.kt:8) | Flow 包装不凭空创造退订能力；慢消费者行为明确；恢复后不跳号、不重复应用 |

取消需要核对具体绑定版本。上游 0.32.1 的 Kotlin 异步模板包含可取消等待与 finally 释放，反向异步调用也有任务取消接线；这不等于任意 Rust 后台工作都会停止，更不代表业务副作用回滚。[模板](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/uniffi_bindgen/src/bindings/kotlin/templates/Async.kt)

`catch_unwind` 只处理展开式 panic，不捕获 abort，也不能修复非法内存访问。MadDemo 的构建档位选择 unwind 与其 panic 边界配套；第三方原生库仍需遵守各自异常协议。[Rust 说明](https://doc.rust-lang.org/std/panic/fn.catch_unwind.html)、[构建配置](/Users/changyue/Desktop/MadDemo/kernel/Cargo.toml:56)

## 三 所有权 内存与多线程

目标：内存仍然有效，操作仍被允许，关闭最终到达明确状态。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **13. 资源 owner 与句柄有效期** | 明确唯一关闭责任、允许的共享引用、句柄作用域和准入规则；复用句柄槽位时防止旧身份误命中 | 资源包装、注册表、状态机、保活引用 | MadDemo 存储表区分 Opening / Ready / Closing，关闭时撤句柄，在途引用与底层关闭另行协调。[代码](/Users/changyue/Desktop/MadDemo/kernel/crates/im-store/src/registry.rs:1) | 释放引用与关闭业务资源分开；不会因 Arc 尚在就允许对已关资源继续操作 |
| **14. 缓冲区寿命与释放配对** | 声明复制、借用或所有权转移；分配与释放使用配套模块；借用指针不逃逸其有效期 | UniFFI 缓冲转换、cinterop 作用域、受控批量复制、内存测试 | UniFFI 的 RustBuffer 与手写 C ABI 有不同管理协议，应由对应后端承接。[表示机制](https://mozilla.github.io/uniffi-rs/latest/internals/lifting_and_lowering.html)、[cinterop](https://kotlinlang.org/docs/native-c-interop.html) | 错误、取消、转换失败路径也释放；零拷贝有独立的寿命与并发证明 |
| **15. GC 与 Rust 引用环** | 登记和撤销回调配对，解除 Kotlin 对象与 Rust 资源互持；确定性资源显式关闭 | 绑定生命周期 API、弱引用、解除注册、长期运行观测 | UniFFI foreign trait 可能形成跨语言循环引用，绑定工具不会自动消除所有环。[官方说明](https://mozilla.github.io/uniffi-rs/latest/foreign_traits.html) | Kotlin GC 与 Rust Arc / Drop 的存在不被当作无泄漏保证；正常析构不报成泄漏 |
| **16. 关闭的取消与超时** | 关闭由正确 owner 驱动，区分已完成、仍在关闭与放弃；不能因等待超时提前释放在途内存 | 专用关闭作用域、必要的不可取消段、排水、关闭报告 | MadDemo 关库使用 `NonCancellable + lifecycle`，避免派发前取消导致关库被跳过；阻塞关闭仍可能超过等待预算。[代码](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ImParticipant.kt:92) | 调用者取消不会让必需清理永久丢失；超时状态与实际资源状态一致 |
| **17. 两侧同步与回调重入** | Rust 和 Kotlin 遵守同一访问协议；不持业务锁等待回调；区分线程安全与操作原子性 | Rust Mutex / Arc、Kotlin 原子或 Mutex、串行域、适用范围内的竞态工具 | Rust 的 Send + Sync 无法替外部 Kotlin 实现证明线程安全；MadDemo 回调入队，协调集中到串行域。[官方约束](https://mozilla.github.io/uniffi-rs/latest/types/callback_interfaces.html)、[接入](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/LinkInbox.kt:8) | 并发关闭、重入、共享可变字段均受保护；无锁内跨语言调用形成的互等 |

业务 ID 与运行时句柄分开：业务 ID 可以按领域规则持久化；句柄受资源实例和生命周期约束。生成的绑定引用释放 API 也不能统一解释成“底层库已排水并关闭”。

## 四 UI 集成与性能

目标：界面生命周期不破坏账户资源，跨界成本可测量。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **18. 页面作用域与共享订阅** | 页面管理自身观察；账户或 SDK owner 管理原生订阅与资源；原生接口只支持单订阅时明确共享策略 | CoroutineScope、Flow、生命周期 Adapter、订阅登记 | MadDemo 存储每库只订阅一次并常驻，不能让每个页面各自订阅或离开就关闭底层库。[接口约束](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226) | 反复进出页面无重复注册；页面取消不影响其他观察者；切号无旧数据串入 |
| **19. 跨界频率 复制与容量** | 优先批量调用、受限快照和增量；测量每次编码、分配、复制及队列增长，达到瓶颈后再优化缓冲策略 | 基准测试、平台 Profiler、批处理、预算检查 | MadDemo 网络按批次回调，存储按会话合并变化；两者的合并语义不同。[网络接入](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ffi/UniffiImLinkPort.kt:23)、[存储合并](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/EventStream.kt:9) | 使用真实载荷测延迟、吞吐、复制量和峰值内存；类型化 API 不被误认为零成本 |

## 五 工程交付

目标：绑定、二进制与运行环境相互匹配。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **20. 工具链与 fork 组合** | 锁定 Rust、UniFFI、生成器、Kotlin、JNA、NDK / Xcode 组合；fork 独立记录补丁与支持范围 | 版本锁、来源记录、兼容矩阵、生成器回归 | MadDemo fork 适配指定 UniFFI 元数据和回调布局，要求生成结果实际消费原生库。[说明](/Users/changyue/Desktop/MadDemo/kernel/tools/bindgen/FORK-PROVENANCE.md:1) | 升级不只检查源码能否编译；不能将上游版本相近当兼容证明 |
| **21. API ABI 与行为兼容** | 分别验证公开 API、生成协议和业务语义；业务契约版本、UniFFI 版本、签名校验和分别记录 | 元数据比对、API diff、checksum、旧消费者测试 | MadDemo 的业务门契约号是 2；Native 不做运行期逐函数校验，靠构建期配对与额外验证。[装载说明](/Users/changyue/Desktop/MadDemo/capability/kernel/src/nativeMain/kotlin/com/mad/kernel/KernelLoader.native.kt:6) | 不能把业务契约 2 当 UniFFI 软件版本；链接成功或头文本未变不等于全面兼容 |
| **22. 装载 链接与制品配对** | 将绑定、头、库、目标、特性、构建档位与工具链身份组成可追溯制品；检查动态依赖和目标支持 | manifest、逐文件摘要、构建依赖、符号门、真实消费 | MadDemo Android 使用 JNA AAR，Native 使用静态库；平台构建消费候选，并核对文件摘要。[配置](/Users/changyue/Desktop/MadDemo/build-logic/src/main/kotlin/mad.kernel-bindings.gradle.kts:1) | 干净环境、Debug / Release、声明支持的架构都可消费；错误制品被拒用 |
| **23. 原生库与状态实例重复** | 定义每个资源的实例归属，检查多个模块是否重复编译、装载或初始化同一内核；避免符号冲突 | 依赖图、链接映射、符号检查、初始化测试 | MadDemo 的绑定只在 `capability/kernel` 编译一次，IM 与推理共用门和运行时。[模块说明](/Users/changyue/Desktop/MadDemo/capability/kernel/build.gradle.kts:1) | 所谓单例确实作用于预期进程和组件；共享资源未被重复初始化或竞争关闭 |

上游 UniFFI 发布记录曾修复 Kotlin 的 ARM32 返回值符号问题，以及 aarch64 checksum 问题。生成器和 ABI 必须进入目标测试矩阵。[发布记录](https://github.com/mozilla/uniffi-rs/blob/v0.32.1/CHANGELOG.md)

## 六 验证与诊断

目标：故障可定位，工具结论有对应证据。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **24. 双端消费与竞态验证** | 同时测试 Rust 原语、Kotlin 适配和真实绑定；用屏障控制取消、完成、关闭及回调交错 | Rust tests、Kotlin tests、JVM / Native 消费夹具、故障注入 | MadDemo 将请求取消、订阅恢复等场景登记到既有测试；这些单元证据仍需与真实 FFI 消费区分。[验收设计](/Users/changyue/Desktop/MadDemo/docs/adr/ADR-029-boundary-tests.md:6) | JVM 结果不替代 Native；编译不替代运行；Sanitizer 按实际覆盖范围报告 |
| **25. 跨语言故障定位** | 关联操作 ID、资源与线程；保留错误分类、原生栈和构建身份；符号与实际库配对，载荷脱敏 | 结构化日志、Rust panic hook、平台崩溃工具、LLDB、符号归档 | MadDemo 提供 Rust 到宿主的统一日志出口，panic hook 避免记录可能包含用户数据的载荷。[日志](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/log_sink.rs:1)、[panic hook](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/lib.rs:72) | 可定位到正确库和源码；内部错误不依赖任意字符串解析；日志不会因边界失败再次失控 |
| **26. 生成与检查可信度** | 生成区可确定性重建，检查手写漂移；区分发现问题、缺证据和启发式未发现 | 正反夹具、生成物摘要、漂移检查、Gap 报告 | mad-boundary 维护证据与已知漏报测试；MadDemo 配置区分编译元数据来源和源码扫描降级来源。[证据](/Users/changyue/Desktop/mad-boundary/tests/test_evidence.py:44)、[漏报](/Users/changyue/Desktop/mad-boundary/tests/test_known_misses.py:1)、[来源配置](/Users/changyue/Desktop/MadDemo/tools/boundary/config.toml:125) | 未支持、未运行、旧制品证据不能算通过；手写业务断言不由生成器自行猜测 |

## mad-boundary 的职责划分

- **生成器**：复用 UniFFI / Gobley，补充受限数值、ID、枚举、错误和简单 Port 映射。
- **运行时适配层**：执行已声明的线程、回调、取消、保活与关闭协议，复用后端已有引用管理。
- **工程验证层**：检查支持组合、实际导出、生成物与二进制配对，并执行真实消费场景。
- **SDK 作者**：决定公开模型、谁关闭、何时算受理、取消效果、事件保证和恢复策略；实现底层算法、事务与同步。

## 通用规则需要统一的口径

| 容易误用的说法 | 采用的口径 |
|---|---|
| UniFFI 不支持 async 或完全没有取消 | 上游与 fork 分别判断；按具体绑定核对取消和释放接线，再说明底层工作与副作用的保证 |
| Kotlin Rust 都用 JNI | Android / JVM 与 Kotlin/Native 分开；MadDemo 前者经 JNA，后者经 cinterop |
| bindgen 都是同一种工具 | UniFFI / Gobley bindgen 生成语言绑定；rust-bindgen 读取 C/C++ 头生成 Rust 声明 |
| 生成绑定后就不需要适配 | 领域映射、生命周期和业务协调仍有明确责任方 |
| 跨异步边界一律复制 | 按后端协议选择复制、转移或安全共享；短期借用不得逃逸 |
| Drop 或 GC 触发就是泄漏 | 它们是正常回收机制；诊断违反关闭契约、引用环和异常滞留 |
| 静态链接成功就说明绑定匹配 | 需要元数据、构建输入、制品身份与真实消费证据 |

相关旧设计位置：[后端能力](/Users/changyue/Desktop/mad-boundary/docs/design.md:126)、[异步内存策略](/Users/changyue/Desktop/mad-boundary/docs/design.md:347)、[回收判定](/Users/changyue/Desktop/mad-boundary/docs/design.md:351)。
