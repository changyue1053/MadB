# ArkTS Rust 跨语言边界工程清单

整理日期：2026-10-23

**ArkTS ↔ Rust 可以封装成普通 SDK。企业工程化的重点是运行环境与线程、资源所有权、异步取消、事件可靠性，以及鸿蒙制品交付。** 新版 mad-boundary 应复用绑定后端，生成机械接线，执行已声明的运行协议，并验证真实 ArkTS 消费。

范围包括 ArkTS 调用 Rust，以及 Rust 通过公开回调请求 ArkTS 宿主能力。以下以 OpenHarmony Node-API 路线为主，ANI 单独登记支持范围。按公开契约、调用协议、运行安全、UI 与性能、工程交付、验证诊断六组组织，共 30 项。

MadDemo 当前相关业务主要经 ArkTS → akinterop / Node-API → Kotlin/Native → UniFFI / Gobley → Rust。其 C++ 壳负责装载和注册，逐函数包装由 akinterop 生成。项目案例说明已有底层协议和相邻边界的约束；Rust 直连需要独立消费验证。[装载壳](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/cpp/napi_init.cpp:1)

配套决策：[ArkTS Rust 架构总结与新版 mad-boundary 设计输入](/Users/changyue/Desktop/mad设计/ArkTS_Rust/ArkTS_Rust_架构总结与新版_mad-boundary_设计输入.md)。

## 一 公开契约与数据

目标：公开接口明确，类型转换保留业务含义，支持范围与实际运行时一致。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **1. 接入路线与运行时能力** | 将 Node-API、ANI、C ABI 适配分别登记；按 SDK、生成器、目标、方向和类型声明支持范围 | napi-ohos、napi-derive-ohos、ohrs、ANI 独立适配器、能力探针 | ohos-rs 提供 Node-API 风格 Rust 绑定；ani-rs 面向兼容 ArkTS 1.2 的 ANI 运行环境。[ohos-rs](https://github.com/ohos-rs/ohos-rs)、[ani-rs](https://github.com/ohos-rs/ani-rs) | 不把 Node.js 编译通过、某个 N-API feature 或 ANI 宏可生成等同于目标设备支持 |
| **2. 模型权威源与公开 DTO** | 独立 Rust SDK 以明确的 Rust 导出面为源；生成目标 ArkTS 支持的类型；区分值快照和资源代理 | 后端导出宏、生成声明、受限 DTO、必要的 Facade | napi-ohos 提供函数和类型接线；MadDemo 现有业务协调仍在 Kotlin，直连不自动继承其业务协议。[后端入口](https://github.com/ohos-rs/ohos-rs)、[现有边界](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/cpp/napi_init.cpp:3) | 不导出内部对象图、锁和裸指针；DTO 修改不被误认为写回内核；不重复手写多份权威模型 |
| **3. 整数范围 单位与稳定 ID** | Node-API 路线的任意 i64/u64 不直接映射为 number；采用受检十进制字符串或经验证的 BigInt；业务 ID 与临时句柄分开 | 数值范围转换、格式校验、不透明 ID、边界值夹具 | MadDemo 用字符串订阅 ID 避免底层 Int 转换把非法值截断为其他 ID。[订阅适配](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/AkInteropAdapters.kt:28) | 覆盖 2^53−1、负数、溢出、NaN 和非整数；禁止先损失精度再转字符串；单位不隐式改变 |
| **4. 空值 缺失与带数据枚举** | 明确 Option 的目标表达；三态修改显式建模；带数据 enum 转换为目标编译器支持的标签与载荷结构 | 后端类型能力表、类型 Adapter、ArkTS 编译夹具 | ani-rs 的映射包含 i64 → long、可空整数装箱，说明不同运行时必须使用各自类型规则。[ANI 映射](https://github.com/ohos-rs/ani-rs#type-mappings) | 空值不变成 0；未修改与清空不同；标签载荷组合有效；未知标签策略明确 |
| **5. 字符串 字节与 JSON 选择** | 文本与任意字节分开；优先类型化 DTO 和 ArrayBuffer；JSON 用于明确的消息协议或兼容通道；检查编码与长度 | 生成转换、ArrayBuffer、受限序列化协议、Unicode 与空缓冲样例 | ohos-rs 说明 N-API Buffer 与 ArkTS 的 buffer 模块不同，建议优先 ArrayBuffer；运行时差异需按版本验证。[Buffer](https://ohos.rs/docs/more/buffer)、[差异说明](https://ohos.rs/docs/more/diff) | 空缓冲、中文、嵌入零字符和大载荷正确；不把字节数当字符数；不默认 Base64 或 JSON |
| **6. 运行时校验 错误与 panic** | 声明文件之外校验范围、大小、句柄状态和调用条件；统一业务错误、取消、宿主异常与内部故障；明确 panic 后状态 | 生成校验器、稳定错误码、Result 映射、异常边界、故障注入 | MadDemo 记录过非法监听器与挂起 N-API 异常；Rust 门通过 guarded 限制展开式 panic。[监听器处理](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/AkInteropAdapters.kt:31)、[Rust 边界](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/lib.rs:40) | 错误不静默变成空串或成功；不依赖文案分类；同步调用与异步回调的异常交付方式明确 |

类型化接口仍可能分配和复制。JSON 是一种表示策略，不能代替类型、取消、线程与所有权契约。Rust String、Vec 和 trait 的内部布局也不能直接作为公共 C ABI；采用 C ABI 时需要明确的数据布局和释放函数。

panic 防火墙只处理可展开的 panic，不能捕获 abort 或修复非法内存访问；异常被捕获也不证明资源状态可以继续使用。[Rust catch_unwind](https://doc.rust-lang.org/std/panic/fn.catch_unwind.html)

## 二 调用与异步协议

目标：运行位置、返回值、取消与事件交付都具有可验证的含义。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **7. 阻塞调用与异步运行时** | 区分短同步调用、阻塞工作、Future 驱动与回调投递；为后台任务指定 owner | napi-ohos 异步接线、明确配置的 Rust 运行时、工作队列、耗时检查 | ohos-rs 提供 async 接入；MadDemo 推理入口调用同步原生函数。[后端说明](https://github.com/ohos-rs/ohos-rs)、[推理入口](/Users/changyue/Desktop/MadDemo/capability/infer/engine/src/commonMain/kotlin/com/mad/infer/engine/ffi/UniffiInferKernelPort.kt:28) | 返回 Promise 不被当作同步重工作已离开 ArkTS 线程；派生任务和线程池容量有管理者 |
| **8. 取消 超时与副作用** | 分别声明停止观察、停止等待、请求停止工作和撤销副作用；以底层终态确认取消效果 | 操作句柄、原生原子信号、取消令牌、超时状态机 | MadDemo 网络取消只放下等待；推理线程读取取消回调，属于不同取消协议。[请求表](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:12)、[推理取消](/Users/changyue/Desktop/MadDemo/capability/infer/engine/src/commonMain/kotlin/com/mad/infer/engine/ffi/UniffiInferKernelPort.kt:12) | 不把 Promise、超时或取消接口返回成功当作底层停止；取消后留下的工作、缓冲和结果仍有归属 |
| **9. 一次完成与迟到结果** | 先登记操作再触发；成功、失败和取消使用统一完成认领；无人接收的资源结果按协议回收 | 操作状态机、完成门、迟到结果清理、可控交错测试 | MadDemo 请求表先登记等待者，防止响应早于发送返回。[登记顺序](/Users/changyue/Desktop/MadDemo/capability/kernel/src/commonMain/kotlin/com/mad/kernel/LinkRequests.kt:81) | 同步首回调不丢失；终态只认领一次；重复完成不造成重复释放；关闭后不更新失效页面 |
| **10. 反向回调与业务完成阶段** | 区分单向通知、异步请求和同步返回；明确返回值代表入队、接收、执行还是持久化 | 回调 Adapter、异步应答协议、请求关联、原生状态镜像 | 旧 mad 台账回调跨线程等待 ArkTS 实际执行，不能只入队就返回成功。[台账桥](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ohos/har/src/main/cpp/napi_init.cpp:98) | 不把需要同步布尔值的 Rust 回调随意改成异步通知；查询取消状态优先读取原生原子标志 |
| **11. 同步回调 重入与死锁** | 不持业务锁调用外部代码；不让 ArkTS 线程同步等待必须回到该线程的工作；声明重入规则 | 锁边界审查、执行器约束、重入守卫、超时与屏障夹具 | 旧 mad 明确提示：工作线程等待台账回调期间，主线程再同步等待该线程就会互等。[项目约束](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ohos/har/src/main/cpp/napi_init.cpp:99) | 回调可触发取消、退订或关闭时仍正确；关闭不会阻塞唯一能执行剩余回调的线程 |
| **12. 有界事件 顺序与恢复** | 显式指定队列容量、满队列策略与业务序号；状态可按约定合并，可靠事件不能静默丢弃 | TSFN、有界 Rust 队列、批处理、溢出事件、快照恢复 | ohos-rs TSFN 的容量 0 表示无限队列；MadDemo 以 commit_seq 识别存储变化缺口。[TSFN](https://ohos.rs/docs/usage/tsfn)、[存储契约](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226) | 入队失败有人处理；慢消费者不会无限增长内存；跨生产者顺序不依赖偶然调度；可靠性由端到端协议保证 |

TSFN 提供跨线程调用通道，业务确认、生产者减速和事件恢复需要额外协议。N-API async_work、Rust Future、Promise 分属不同层，取消能力要逐后端、逐操作验证，不能统一标记为完全支持或完全不支持。

## 三 所有权 内存与多线程

目标：ArkTS 环境寿命、Rust 内存寿命与业务资源状态相互一致。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **13. env 与执行线程归属** | 所属环境的 ArkTS 对象在允许的线程操作；工作线程携带原生数据，通过环境安全的通道回送 | EnvScope、TSFN、线程断言、执行器 Adapter | MadDemo 用 MainDispatcherBridge 先建立回 ArkTS 主线程的通道。[项目接入](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/MainDispatcherBridge.kt:10) | Rust 线程安全不等于 ArkTS 对象可跨线程；不通过 unsafe Send / Sync 强行绕过环境约束 |
| **14. 多环境 Worker 与对象隔离** | 每个环境维护自己的回调、引用和关闭状态；共享 Rust 服务只交换原生数据 | 按环境登记、环境代次、Worker 消费夹具、过期引用检查 | 官方 FAQ 说明 env 与执行线程绑定，环境退出后继续使用可能失效。[稳定性 FAQ](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/napi-faq-about-stability.md) | 不默认全进程只有一个 main_env；一个 Worker 退出不误关其他环境或应用拥有的服务 |
| **15. 局部句柄 长期引用与引用环** | 区分 handle scope、napi_ref、Rust Arc 与业务 close；注册和解除成对；断开跨语言长期互持 | 后端引用包装、弱引用或显式解绑、引用计数诊断 | Node-API 为局部值、长期引用和作用域提供不同机制。[生命周期文档](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/use-napi-life-cycle.md) | napi_ref 延长寿命不授予跨线程权限；引用减计数、删除引用和关闭原生资源不混用 |
| **16. 唯一关闭责任与在途操作** | 明确创建者、关闭者和引用持有者；关闭先停止准入，再按协议处理在途操作；保留完成清理的 owner | 幂等 close、资源状态机、在途保活、关闭结果 | MadDemo Rust 句柄管理与 Kotlin 资源生命周期需要保持一致；直连 SDK 也需指定关闭责任。[资源生命周期](/Users/changyue/Desktop/MadDemo/capability/im/engine/src/commonMain/kotlin/com/mad/im/engine/ImParticipant.kt:92) | 多个包装不产生多个关闭 owner；关闭超时不等于内存可立即释放；逻辑关闭与最后引用释放分别检查 |
| **17. 环境退出与异步清理** | 环境关闭后禁止新投递；停止或脱离生产者；按后端拥有关系处理 TSFN、引用和未投递原生数据 | 受支持的 cleanup hook、关闭状态机、RAII 配合、环境销毁夹具 | 官方 FAQ 提醒缓存 env 需要处理环境退出；mad-boundary 已扫描 TSFN 收尾形态。[FAQ](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/napi-faq-about-stability.md)、[扫描器](/Users/changyue/Desktop/mad-boundary/mad_boundary/adapters/source_analysis/napi.py:91) | 不在环境失效后创建 ArkTS 值；不等待无法再执行的 ArkTS 回调；不与后端析构重复释放 |
| **18. 缓冲寿命 转移与分配器配对** | 默认复制；零拷贝单独声明拥有者、可变性、有效期和线程；由分配协议指定释放方 | ArrayBuffer 转换、受限外部缓冲、专用释放入口、内存检查 | ohos-rs 记录过空缓冲和 TypedArray 行为差异，不能照搬 Node.js 内存假设。[运行时差异](https://ohos.rs/docs/more/diff) | 不把短期借用指针交给异步任务；所有失败路径配对释放；空数组、偏移和长度均覆盖 |
| **19. Rust 共享状态与析构执行位置** | 通过不可变数据、锁或消息串行化控制 Rust 共享状态；明确 Drop、回调与重清理的位置 | Rust Send / Sync 约束、锁与队列、析构线程夹具、显式关闭 | MadDemo 推理取消回调仅在推理线程读取原子状态。[推理约束](/Users/changyue/Desktop/MadDemo/capability/infer/engine/src/commonMain/kotlin/com/mad/infer/engine/ffi/UniffiInferKernelPort.kt:12) | 不持锁调用 ArkTS；析构不假定发生在 UI 线程；后台重清理不会越过环境或资源寿命 |

清理顺序必须与选定后端的引用管理配合。工具不应在发现 TSFN 后统一补一条 release，也不能把 GC finalizer 当作所有业务资源的确定性关闭入口。环境已无法回调时，剩余原生载荷仍需安全释放或交还其 owner。

## 四 UI 集成与性能

目标：页面作用域不会改变底层资源所有权，跨语言成本可以测量与控制。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **20. 页面生命周期与共享订阅** | 分开页面观察、SDK 原生订阅、账户资源与运行环境；页面只解除自身观察；多页面共享底层分发 | Subscription 包装、ArkUI 生命周期接入、共享分发器、页面代次 | MadDemo 页面在 aboutToDisappear 解除观察，而存储门每库只允许一次常驻订阅。[页面](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/ets/pages/ConversationNative.ets:73)、[内核约束](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226) | 重进页面不重复原生注册；观察停止不误关账户；账户切换后旧事件不写入新页面 |
| **21. 跨界频率 复制与内存峰值** | 优先批量、增量与受限快照；为队列和工作项设置预算；测量后再引入零拷贝 | 设备性能分析、Rust 指标、队列水位、真实载荷基准 | 推理进度和消息变化适合批量投递；已有存储接口对单批容量作约束。[存储入口](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226) | 测主线程耗时、吞吐、复制量和慢消费者内存；不以空载调用微基准代替实际场景 |

ArkUI 接入可以隐藏订阅和状态投影的重复代码，但后台任务是否继续、页面隐藏是否退订、账户是否关闭，仍需由产品生命周期契约决定。

## 五 工程交付

目标：声明、原生库、工具链、依赖与设备运行环境可追溯地配套发布。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **22. 工具链 后端与 feature 组合** | 锁定 Rust、OHOS SDK、ArkTS 编译器、生成器、运行时和 feature；后端升级跑契约回归 | Cargo 锁、能力清单、生成器版本记录、构建探针 | ani-rs 提醒未启用 async / tokio_rt 时某些异步绑定仍能编译，但 Promise 会立即拒绝。[ANI 异步要求](https://github.com/ohos-rs/ani-rs#async-functions-promise) | 编译成功不掩盖运行能力缺失；Node-API 与 ANI 使用独立支持矩阵 |
| **23. OHOS 目标与原生依赖** | 使用匹配 target、sysroot、链接器和最低 SDK；覆盖依赖的 C/C++ 库、运行库及所需符号 | Cargo、ohrs、OHOS SDK、适用的 CMake、ELF 依赖检查 | Rust 官方列出 OHOS 目标与交叉编译要求；MadDemo C++ 壳链接 libace_napi.z.so。[Rust 平台说明](https://doc.rust-lang.org/rustc/platform-support/openharmony.html)、[壳构建](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/cpp/CMakeLists.txt:1) | 不混用 Android 或普通 Linux 库；传递依赖在真实设备装载；各承诺架构分别验证 |
| **24. ArkTS API ABI 与行为兼容** | 分开比较导出 API、原生 ABI、数据表示及取消关闭行为；公共枚举与错误码有演进规则 | 声明基线、符号检查、契约差异、旧消费者测试 | mad-boundary 的 ContractReader 与 Verifier 可承接边界差异和消费证据。[模块设计](/Users/changyue/Desktop/mad-boundary/docs/design.md:157) | 签名不变不代表行为兼容；不把 napi-ohos 宏版本等同于稳定公共 ABI |
| **25. 声明 库与包的一致性** | 将声明、包装、原生库、依赖清单与构建身份配套发布；使用真实消费工程检查包布局 | ohrs 构建、hvigor / ohpm 消费任务、制品清单、摘要与握手 | MadDemo 模块名需与包声明及 libraryName 一致，装载时验证入口符号。[装载约束](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/cpp/napi_init.cpp:26) | 干净环境可消费；新声明配旧库可被发现；Debug 与 Release 均覆盖 |
| **26. KMP 共存与内核实例归属** | 确定共用还是隔离原生实例；检查静态链接、装载和初始化；禁止跨实例传递临时句柄 | 链接图、ELF 符号与依赖检查、实例身份、初始化关闭测试 | MadDemo 的 Rust staticlib 用于鸿蒙链接期注入；增加独立 Rust .so 后需要审查是否复制全局状态。[制品定义](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/Cargo.toml:9) | 不出现两套句柄表却被当作一套服务；共享资源只由约定 owner 关闭；允许的隔离实例有独立命名空间 |

独立 SDK 可提供带类型入口与原生库的鸿蒙库包，具体包形态由消费工程和发布渠道决定。Native 目标可编译只说明构建条件满足，无法替代 ArkTS 类型检查、模块装载和运行协议验收。

## 六 验证与诊断

目标：双向真实消费可运行，失败可以定位，支持声明有对应证据。

| 问题 | 解决方案 | 工具或手段 | 实际案例 / 依据 | 验收重点 |
|---|---|---|---|---|
| **27. 真实 ArkTS 双向消费** | Rust 单测、包装测试、ArkTS 编译和设备 FFI 测试分层；覆盖正向调用与反向回调 | ArkTS 最小消费应用、设备运行器、绑定夹具、故障注入 | OpenHarmony 提供异步工作和跨线程调用的开发说明，宿主约束需要在目标运行时验证。[异步工作](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/use-napi-asynchronous-task.md)、[线程安全](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/use-napi-thread-safety.md) | Node.js 或普通 TypeScript 测试不代替 ArkTS 设备证据；Kotlin 中转通过不等于 Rust 直连通过 |
| **28. 竞态 内存与错误路径** | 控制注册、首回调、取消、完成、退订、关闭、GC 与环境退出的交错；加入非法输入和资源失败 | 屏障夹具、压力测试、模糊测试、目标支持的 Sanitizer、资源计数 | MadDemo 已记录错误监听器触发挂起异常，旧 mad 存在需遵守的同步回调等待协议。[监听器探针记录](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/AkInteropAdapters.kt:42)、[回调等待](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ohos/har/src/main/cpp/napi_init.cpp:104) | 正常路径之外覆盖队列满、回调抛错、close 超时、迟到缓冲和 Worker 退出；资源释放恰好配对 |
| **29. 跨语言诊断与符号化** | 关联操作、环境、资源和构建身份；保留错误类别；符号归档匹配实际发布二进制 | 结构化日志、HiLog 接入、Rust panic hook、ELF build-id、符号文件与栈解析 | MadDemo panic hook 只输出位置与线程，避免输出用户载荷。[panic hook](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/lib.rs:72) | 能定位哪个环境、操作和制品失败；日志不携带敏感载荷；环境失效后日志路径不再调用 ArkTS |
| **30. 生成与验证结论可信度** | 区分声明、静态启发式和运行证据；记录生成器、库及应用包摘要；缺口明确报告 | 确定性生成、元数据读取、正反夹具、Findings / Gaps、证据关联 | 现有 NapiScanner 主要识别 C/C++ 原始调用形态；宏和后端内部行为需新增元数据与运行验证。[扫描器](/Users/changyue/Desktop/mad-boundary/mad_boundary/adapters/source_analysis/napi.py:42)、[Verifier 协议](/Users/changyue/Desktop/mad-boundary/docs/design.md:200) | 源文件同时出现 hook 与 release 不等于所有路径正确清理；无匹配、未运行和零告警分别呈现 |

## mad-boundary 的职责划分

- **绑定后端**：复用 napi-ohos；C ABI 与 ANI 按需求独立接入，生成参数、返回值、模块注册与声明。
- **语义适配**：依据明确规则生成受检数值、ID、DTO、错误和必要的语言 Facade。
- **运行时支持**：管理环境、操作、订阅、队列和关闭协议，复用后端已有引用管理。
- **工程验证**：覆盖 ArkTS 编译、真实双向消费、目标矩阵、竞态、性能和制品一致性。
- **SDK 作者**：选择公开能力，确定取消效果、事件保证、资源 owner、恢复策略，实现底层算法和同步协议。

## 通用规则需要统一的口径

| 容易误用的说法 | 采用的口径 |
|---|---|
| ArkTS Rust 都走 Node-API | 当前主方案以 Node-API 为基线；ANI 使用独立能力与验证矩阵 |
| UniFFI 可直接生成官方 ArkTS SDK | UniFFI 官方内置后端没有 ArkTS；共享 Rust 核心不等于共享绑定后端 |
| JSON 是必需的中间格式 | 类型化 DTO 和字节可以直接转换；JSON 按协议需求选择 |
| napi_ref 可以让对象任意跨线程 | 长期引用只解决保活，环境与线程约束依然存在 |
| Promise 支持就说明取消支持 | 请求取消、结束等待、停止工作和撤销副作用分开声明 |
| TSFN 入队成功就说明业务成功 | 入队、执行与持久化是不同完成阶段 |
| release 或 unref 等于资源已关闭 | 引用计数、引用删除、原生关闭和在途排水分别定义 |
| 统一加 cleanup hook 即可解决所有退出问题 | 根据后端拥有关系设计清理，不重复释放，不依赖已失效环境 |
| Rust 单测或 Node.js 测试可证明鸿蒙 SDK 可用 | 需要真实 ArkTS 编译、装载、双向调用与生命周期证据 |
| Rust 直连只是给现有内核加几个导出 | 同时检查业务协调、单一 owner、内核实例、初始化与关闭职责 |

工具职责依据：[UniFFI](https://github.com/mozilla/uniffi-rs)、[cbindgen](https://github.com/mozilla/cbindgen)。旧设计对照：[后端能力](/Users/changyue/Desktop/mad-boundary/docs/design.md:135)、[N-API 规则](/Users/changyue/Desktop/mad-boundary/docs/design.md:419)、[运行时模块](/Users/changyue/Desktop/mad-boundary/docs/design.md:165)。
