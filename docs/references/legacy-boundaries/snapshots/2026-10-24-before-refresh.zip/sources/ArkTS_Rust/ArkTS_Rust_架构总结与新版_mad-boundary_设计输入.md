# ArkTS Rust 架构总结与新版 mad-boundary 设计输入

整理日期：2026-10-23

**新版 mad-boundary 应把 ArkTS ↔ Rust 作为独立边界接入。Node-API 路线优先评估 napi-ohos，围绕环境与线程、协作取消、资源关闭和事件交付建立运行协议，再通过真实 ArkTS 消费交付可追溯的 SDK。** ANI 按兼容运行环境另行验证，共用核心契约，不混用底层机制。

范围包括 ArkTS 调用 Rust，以及 Rust 通过公开回调使用 ArkTS 宿主能力。MadDemo 中仍由 Kotlin 负责业务协调的能力继续保留 Kotlin 入口；直接 SDK 的能力边界和资源 owner 需要明确。

配套明细：[ArkTS Rust 跨语言边界工程清单](/Users/changyue/Desktop/mad设计/ArkTS_Rust/ArkTS_Rust_跨语言边界工程清单.md)，覆盖六组、30 项问题。

## 1 已明确的架构结论

| 结论 | 对新设计的要求 |
|---|---|
| **接入路线按运行时区分** | Node-API 与 ANI 使用独立的类型映射、线程规则、构建和消费矩阵 |
| **Rust 直连是独立边界** | 不借用 ArkTS → Kotlin → Rust 的运行结果宣称直连已验证 |
| **公开类型不依赖 JSON** | 优先类型化 DTO 与 ArrayBuffer；JSON 按消息协议或兼容需求使用 |
| **环境寿命是一级约束** | 每个环境拥有自己的回调、引用和清理状态；共享 Rust 服务交换原生数据 |
| **Promise 与取消效果分开** | 操作句柄或令牌连接原生协作取消，最终结果确认停止效果 |
| **回调不只有通知语义** | 同步返回、异步应答与单向通知分开；入队不能代替持久化确认 |
| **资源状态独立于引用数量** | GC、Arc、引用解绑、关闭准入和在途排水分别建模 |
| **共享业务与内核 owner 必须明确** | KMP 与直接 SDK 共存时审查实例、句柄、初始化和关闭 |
| **支持声明需要消费证据** | ArkTS 编译、真机装载和运行协议是交付门槛，桌面测试只覆盖其实际范围 |

### 1.1 调用路线与选择

| 路线 | 主要用途 | 选择条件 |
|---|---|---|
| **ArkTS → akinterop → Kotlin/Native → UniFFI / Gobley → Rust** | 使用既有 KMP 业务协调与原生能力 | 业务 owner 继续在 Kotlin，ArkTS 提供页面或平台服务 |
| **ArkTS → Node-API / napi-ohos → Rust** | 独立的存储、推理、算法等原生 SDK | 公开能力与运行协议明确，目标运行时通过验证 |
| **ArkTS → Node-API C/C++ → Rust C ABI** | 复用已有稳定 C 接口或多宿主接口 | 愿意维护显式 ABI、释放与回调契约 |
| **ArkTS → ANI / ani-rs → Rust** | 兼容 ArkTS 1.2 ANI 环境的直接接入 | SDK、加载机制和后端能力单独验证 |

MadDemo 的 C++ 壳只装载 libmad_shell.so 并调用 Compose 与 akinterop 注册；Rust staticlib 参与鸿蒙链接。这不等于已有一个独立 ArkTS Rust SDK。[装载职责](/Users/changyue/Desktop/MadDemo/shell/ohos/har/src/main/cpp/napi_init.cpp:1)、[Rust 制品](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/Cargo.toml:9)

新增直连的价值应来自能力边界、独立复用或经过测量的成本收益。Kotlin 中已有的发送、重连、状态协调和资源管理不会因为少一层绑定而自动转移到 Rust。

### 1.2 模型与数据表示

| 公开语义 | Node-API 路线的建议表达 | 必须明确的限制 |
|---|---|---|
| **普通 DTO** | 生成后端和 ArkTS 编译器支持的类型化对象 | 字段与命名稳定；对象图、循环和复杂泛型通过能力检查 |
| **业务 ID** | 受检字符串或明确支持的语言封装 | 不把原生指针和临时句柄当持久化身份 |
| **任意 64 位整数** | 十进制字符串，或经过目标矩阵验证的 BigInt | 不先转 number；符号、范围与单位明确 |
| **可空值与局部修改** | 约定的空值表示；需要三态时增加显式修改协议 | 缺失、清空和有效值不能合并 |
| **带数据枚举** | 受支持的标签与载荷模型 | 拒绝非法组合；未知变体策略明确 |
| **字节数据** | ArrayBuffer，默认复制 | 外部缓冲或零拷贝需要独立寿命协议 |
| **资源对象** | 包装类或不透明句柄 | 引用寿命不等于业务可操作状态 |

ohos-rs 文档区分 N-API Buffer 与 ArkTS buffer 模块，并列出运行时差异。生成器应对锁定版本作适配，不将某个版本的规避代码升级为永久规则。[Buffer](https://ohos.rs/docs/more/buffer)、[运行时差异](https://ohos.rs/docs/more/diff)

ANI 使用另一套类型映射，例如文档列出 i64 对应 long。两条路线可以表达相同领域模型，但不能共享未经验证的表示假设。[ANI 类型映射](https://github.com/ohos-rs/ani-rs#type-mappings)

## 2 新方案必须覆盖的问题范围

| 问题组 | 契约内容 | 工具职责 |
|---|---|---|
| **运行时与公开类型** | 后端、SDK、目标、方向、数值、空值、DTO、字节 | 能力检查、映射生成、真实 ArkTS 编译 |
| **错误与参数** | 业务失败、取消、内部故障、回调抛错、输入上限 | 错误适配、运行时校验、坏参数夹具 |
| **异步与执行器** | 调用执行位置、回调执行位置、阻塞性、任务 owner | 异步包装、工作队列接入、任务登记 |
| **取消与完成** | 请求、停止等待、停止工作、迟到结果、副作用 | 操作状态机、取消信号、结果认领与清理 |
| **环境与线程** | 所属 env、Worker、多环境隔离、退出规则 | EnvScope、TSFN 等后端机制、线程检查与清理 |
| **资源与内存** | 创建、共享、关闭、借用、转移、回调保活 | 资源包装、关闭接线、引用和内存诊断 |
| **事件与 UI** | 容量、顺序、可靠性、恢复、观察作用域 | 订阅、共享分发、溢出反馈、ArkUI 接入 |
| **工程交付** | 目标、依赖、包布局、兼容、内核实例 | 构建计划、制品清单、差异检查与消费验证 |
| **诊断与证据** | 构建身份、符号、操作关联、实际验证范围 | 报告、性能指标、符号归档、缺口记录 |

函数签名无法推导以下决策：取消是否停止工作；close 何时完成；回调的布尔值表示入队还是执行；事件能否合并；页面能否关闭共享服务。SDK 作者决定这些语义，工具据此生成接线和验证协议。

## 3 工具生态在新架构中的位置

| 工具或机制 | 负责什么 | 使用边界 |
|---|---|---|
| **OpenHarmony Node-API** | ArkTS 与原生代码之间的值、引用、调用和异步机制 | 宿主运行时接口，不等于完整 Node.js 环境 |
| **napi-ohos 与 napi-derive-ohos** | Rust 导出宏、参数与结果转换、绑定运行时接入 | 优先复用；类型、async 与线程行为按具体版本验证 |
| **ohrs** | ohos-rs 项目的构建工具入口 | 与消费工程、原生依赖和制品验证结合使用 |
| **Rust C ABI 与 cbindgen** | 为显式 Rust C API 生成 C/C++ 头文件 | cbindgen 不替项目实现安全 ABI、资源关闭或 ArkTS 包装 |
| **rust-bindgen** | 生成 Rust 调用 C/C++ 接口所需的声明 | 用于依赖原生 SDK 等场景，不是 ArkTS SDK 生成器 |
| **ani-rs** | 面向 ANI 的 Rust 接线与类型、异步适配 | 兼容运行环境独立准入，不作为 Node-API 的透明替换 |
| **UniFFI 与 Gobley** | 服务 Swift、Kotlin 及 KMP 等已有消费者 | 官方 UniFFI 内置后端没有 ArkTS；可共享内核，不能假定共享后端能力 |
| **Rust 并发设施** | 原子状态、锁、队列、Future 与工作执行 | 不自动建立 ArkTS 环境权限与业务取消语义 |
| **鸿蒙构建与消费工具** | ArkTS 编译、包消费、原生装载与运行 | 构建目标和最低 SDK 必须与实际交付一致 |
| **mad-boundary** | 统一契约、适配、运行规则、验证与制品证据 | 业务协调和底层 unsafe 正确性仍由实现负责 |

依据：[ohos-rs](https://github.com/ohos-rs/ohos-rs)、[cbindgen](https://github.com/mozilla/cbindgen)、[ani-rs](https://github.com/ohos-rs/ani-rs)、[UniFFI 支持范围](https://github.com/mozilla/uniffi-rs)、[Rust OHOS 目标](https://doc.rust-lang.org/rustc/platform-support/openharmony.html)。

### 3.1 Node-API 与 ANI 的准入

Node-API 后端以当前 MadDemo 的运行环境为优先基线。工具能力至少以运行时种类、SDK、目标架构、生成器版本、feature 和公开类型的组合登记；检测不支持的组合后明确拒绝生成或构建。

ANI 保留独立后端入口。ani-rs README 要求兼容 ArkTS 1.2 的运行环境，并记录了未开启异步 feature 时可能编译通过而 Promise 立即失败的情况。因此宏展开成功不是支持证明。[ANI 要求](https://github.com/ohos-rs/ani-rs#requirements)、[异步要求](https://github.com/ohos-rs/ani-rs#async-functions-promise)

两条路线共享领域契约、错误目录和验收意图；底层引用、环境、注册、线程接入与生成物分别实现。

### 3.2 取消与反向回调

以推理为例，目标调用协议如下：

1. ArkTS 启动操作，得到可以等待终态和请求取消的操作对象。
2. Rust 为工作登记 owner 和取消状态，推理在原生执行器上运行。
3. ArkTS 请求取消时，边界层修改原生取消标志。
4. 推理线程在允许停止的位置读取标志，按底层协议退出。
5. 终态通过所属环境的安全通道交付；环境已退出时，由原生 owner 完成剩余清理。

MadDemo 当前推理回调只读取原子取消状态。这一语义适合留在原生侧；直接把它替换成 Rust 工作线程同步调用 ArkTS isCancelled，会增加跨线程等待和死锁风险。[推理协议](/Users/changyue/Desktop/MadDemo/capability/infer/engine/src/commonMain/kotlin/com/mad/infer/engine/ffi/UniffiInferKernelPort.kt:12)

反向调用另分三种协议：通知只承诺投递；异步请求以明确应答完成；同步返回必须保证当前执行位置、重入和阻塞条件。需要在 ArkTS 线程执行的平台服务应优先设计为异步请求，不能把异步入队伪装成同步结果。

### 3.3 环境退出与资源关闭

资源作用域至少区分：应用或账户、ArkTS 环境、操作、页面观察。环境通常不是页面，页面离开不等于 VM 已退出，Worker 结束也不必关闭应用拥有的 Rust 服务。

正常资源关闭采用显式状态机：Open → Closing → Closed。Closing 拒绝新操作，按契约处理在途工作与结果，完成资源关闭后进入 Closed；关闭失败或超时仍保留可诊断状态和负责收尾的 owner。

环境退出是另一条终止路径：停止新投递，停止或解除原生生产者对该环境的依赖，处理排队载荷，并按后端约束释放引用和 TSFN。不能等待必须回到已失效环境的回调，也不能把正常 close 的完成条件强加给不可逆的环境销毁。

已有绑定的 RAII、引用保活和释放职责应继续复用。napi_reference_unref、删除引用与关闭数据库是不同操作；工具不得因新增 cleanup hook 再次释放后端已经拥有的资源。[生命周期机制](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/use-napi-life-cycle.md)、[环境稳定性](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/napi-faq-about-stability.md)

## 4 业界与项目的工程经验

| 案例 | 应沉淀的规则或测试 |
|---|---|
| OpenHarmony FAQ 列出跨线程 env、失效 napi_value 与环境退出后的访问 | 保活、线程权限与环境存活分开检查；故障注入覆盖 Worker 退出 |
| ohos-rs 记录 Buffer、ArrayBuffer 等运行时差异 | 每个承诺 SDK 运行转换夹具，尤其覆盖空数组、长度和字节偏移 |
| ohos-rs TSFN 提供容量选项，0 表示无限 | 企业 SDK 显式设置队列策略；慢消费者和队列满进入验收 |
| ani-rs 异步 feature 缺失可能只在调用时暴露 | 构建探针之外运行最小异步消费，能力报告不只看宏与编译 |
| MadDemo 先初始化 MainDispatcherBridge | 回调执行器在注册时明确绑定，不允许工作线程直接操作 ArkTS 对象 |
| 旧 mad 的台账桥必须等待 ArkTS 真正完成落盘回调 | 返回值包含完成阶段；双向同步等待进入死锁审查 |
| MadDemo 用字符串订阅 ID 并处理挂起 N-API 异常 | 受检参数和运行时校验属于 SDK 边界，不能只依赖声明文件 |
| MadDemo 推理取消在原生线程读取原子状态 | 保留轻量原生取消查询，避免循环跨语言同步回调 |
| MadDemo 存储每库只订阅一次，订阅在首个快照之前 | 页面观察由共享分发层承接，事件缺口和快照恢复显式定义 |
| mad-boundary 的 NapiScanner 使用源代码启发式识别 | 接入 Rust 宏后读取元数据、生成产物并新增真实消费证据 |

上游依据：[稳定性 FAQ](https://github.com/openharmony/docs/blob/master/zh-cn/application-dev/napi/napi-faq-about-stability.md)、[运行时差异](https://ohos.rs/docs/more/diff)、[TSFN](https://ohos.rs/docs/usage/tsfn)、[ANI 异步](https://github.com/ohos-rs/ani-rs#async-functions-promise)。

项目依据：[主线程接入](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/MainDispatcherBridge.kt:10)、[台账桥](/Users/changyue/Desktop/学习2/mad-platform/shell/shellkit-ohos/har/src/main/cpp/napi_init.cpp:98)、[订阅适配](/Users/changyue/Desktop/MadDemo/shell/ohos/kn/src/ohosArm64Main/kotlin/com/mad/shell/ohos/AkInteropAdapters.kt:28)、[存储订阅](/Users/changyue/Desktop/MadDemo/kernel/crates/mad-kernel-ffi/src/store.rs:226)、[N-API 扫描器](/Users/changyue/Desktop/mad-boundary/mad_boundary/adapters/source_analysis/napi.py:42)。

上述项目记录对应当前代码的协议、修复和风险约束。直连 SDK 的验收需要把这些约束落实为 ArkTS 与 Rust 的独立消费场景。

## 5 新版 mad-boundary 的模块职责建议

| 模块 | 单一职责 | 输入与输出 |
|---|---|---|
| **契约与能力检查** | 描述公开接口、目标运行时、所有权和行为保证 | Rust 导出元数据、能力表、策略 → 契约视图与缺口 |
| **ArkTS Rust 绑定后端** | 包装 napi-ohos；按需接入 C ABI 或 ANI | 版本锁、生成计划、目标 → 声明、桥接产物与构建任务 |
| **类型与错误适配生成** | 补充数值、ID、空值、DTO 和稳定错误映射 | 契约、显式规则 → 受限 Facade 与运行时校验 |
| **环境与运行协议支持** | 执行环境隔离、取消、回调、队列和关闭 | 绑定 API、行为策略 → EnvScope、Operation、Subscription、Resource |
| **语言 API 与 UI 接入** | 提供清晰的调用、观察和生命周期外观 | SDK、作用域规则 → ArkTS API 与 ArkUI 接入模板 |
| **构建与制品管理** | 管理 OHOS 目标、依赖、包布局和声明库配对 | 工具链身份、产物、目标矩阵 → SDK 包与清单 |
| **验证与诊断** | 执行编译、设备消费、竞态、性能和证据检查 | 场景、制品、运行结果 → Findings、Gaps 与报告 |

这些职责映射到现有 model / rules、ContractReader、Generator、Toolchain、Verifier、sdk/runtime、language-api 和 ui-integration。复用通用核心协议，增加 ArkTS Rust 后端和消费夹具。[现有模块](/Users/changyue/Desktop/mad-boundary/docs/design.md:144)

依赖方向保持为 ArkTS SDK → Rust 边界适配层 → Rust 内核。内核通过自己的窄接口和原生数据运行，不依赖 napi_env、ArkTS 页面或某个绑定生成器；边界适配层承担语言表示和宿主调度转换。

设计原则落实为代码约束：

- **单一职责与依赖倒置**：规则消费契约和观察结果，Cargo、SDK、文件和设备操作位于外部适配器。
- **Adapter 与 Strategy**：绑定后端、数值表示、事件溢出和执行策略分别组合，避免模板内散布平台条件。
- **Facade**：隐藏机械转换，保留受理、取消、终态和关闭的明确含义。
- **显式状态机与作用域**：操作、订阅、资源、环境分别管理状态；单一关闭责任允许多个受控引用。
- **组合与复用**：使用后端已有引用机制，追加业务关闭协议，避免重复创建一套 native 句柄体系。
- **整洁代码**：生成区与手写区分离；策略名称表达语义；复杂同步封装在小范围；测试协议不变量和失败路径。

Operation、Subscription 等名称表示公共运行概念，具体 API 由后端能力决定。不为所有路径强制同一种取消返回值、队列实现或析构时机。

## 6 自动生成与手写的分界

| 内容 | 可以机械生成 | 根据声明生成或执行 | 开发者负责 |
|---|---|---|---|
| **类型与接口** | 受支持的声明、参数和结果接线、模块注册 | 数值范围、ID、命名、空值与错误适配 | 公开能力、单位、领域含义、复杂模型转换 |
| **异步与回调** | Promise 和回调包装、操作登记骨架 | 执行器、取消接线、完成认领、异常交付 | 阻塞性、底层停止能力、业务完成阶段、平台宿主实现 |
| **资源与环境** | 标准引用管理接入、作用域包装、诊断埋点 | 环境终止、关闭准入、在途收尾和释放顺序 | 创建与关闭 owner、底层 close、共享访问与 unsafe 正确性 |
| **事件与 UI** | 类型化观察入口、订阅对象、页面接入模板 | 容量、共享分发、溢出反馈与终止清理 | 可靠性、可合并内容、重放、快照恢复、账户策略 |
| **工程交付** | 生成物漂移、构建任务、包清单、消费夹具骨架 | 目标矩阵、兼容门槛、性能预算 | 支持范围、独立业务期望值和发布恢复策略 |

每类信息保留一个权威源：Rust 导出面描述接口，行为策略补足签名无法表达的语义，语言适配规则只记录必要差异。中间契约视图由工具派生，不要求开发者再维护一份完整业务 IDL。

不支持的类型、未知所有权和复杂对象图进入明确扩展点。工具应报告缺口，避免静默改成 JSON、截断整数、扩大队列或绕过线程限制。

## 7 实施顺序与验收

| 阶段 | 工作范围 | 完成条件 |
|---|---|---|
| **P0 固定边界和最小完整协议** | 确定直连能力、与 KMP 的关系、单一 owner；锁定 Node-API 目标；完成一个 DTO 调用、一个异步操作、协作取消、有界订阅与关闭 | 真实 ArkTS 消费可运行；坏参数、取消完成相撞、队列满和环境退出都有确定结果 |
| **P1 扩大生成与企业交付** | 扩展受检模型与错误生成、ArkUI 接入；建立制品配对、API 基线、目标矩阵和设备回归 | 声明库匹配、干净环境、Release、多环境、重复进入退出与 KMP 共存均有对应证据 |
| **P2 性能与其他后端** | 依据测量优化批量、增量和缓冲；对有需求的 C ABI 或 ANI 组合独立准入 | 延迟与内存预算达标；新增后端通过相同语义场景及自身运行时检查 |

P0 应尽早在设备运行一个包含完整生命周期的消费样例，再扩展生成覆盖面。编译和设备装载问题不留到最后一次集成才暴露。

验收逐层建立：契约检查 → 确定性生成 → Rust 与 ArkTS 编译 → 设备装载 → 双向调用 → 取消关闭与环境交错 → 制品矩阵 → 性能和诊断。

| 验收层 | 最少覆盖的内容 |
|---|---|
| **数据与错误** | 数值边界、空值、Unicode、空字节数组、非法标签、长度上限、坏句柄、回调抛错 |
| **异步与取消** | 调用前取消、注册与取消相撞、同步首回调、重复完成、超时、迟到资源结果 |
| **环境与线程** | 主环境、Worker、多环境并行、环境退出、线程归属、回调重入、关闭互等 |
| **资源与事件** | 引用环、幂等 close、在途缓冲、队列满、慢消费者、顺序、共享订阅、快照恢复 |
| **交付与兼容** | 原生依赖、最低 SDK、承诺架构、声明库混配、Debug / Release、干净环境、KMP 共存 |
| **性能与诊断** | 实际载荷的延迟、吞吐、复制、内存与队列水位；发布符号匹配和跨语言操作关联 |

测试结论绑定源码、生成器、工具链、目标、生成物、原生库和实际消费应用。静态扫描、桌面测试、ArkTS 编译、模拟器与真机运行分别报告；未支持或未运行保留缺口。[Verifier 证据协议](/Users/changyue/Desktop/mad-boundary/docs/design.md:200)

## 8 旧设计与讨论需要统一的表述

| 待统一内容 | 新方案采用的口径 |
|---|---|
| ArkTS Rust 只是 napi-ohos 或 C ABI 的生成器选项 | 还包含运行环境、生命周期、行为适配、制品和真实消费协议 |
| 所有 ArkTS 都使用同一种原生桥 | Node-API 与 ANI 分别建模，按目标 SDK 和运行环境准入 |
| UniFFI 已覆盖 ArkTS | 官方内置后端没有 ArkTS；第三方后端也需单独核验其宿主与目标 |
| JSON 是跨语言传递的默认要求 | DTO 和 ArrayBuffer 优先；JSON 服务明确的协议需求 |
| 64 位整数的表示对所有 ArkTS 后端相同 | Node-API number 与 ANI long 的条件不同，类型规则绑定后端 |
| N-API 没有取消所以 ArkTS 只能停止观察 | Promise 不自动取消；可通过操作接口连接原生协作取消，效果逐操作声明 |
| 持有 napi_ref 后即可跨线程操作 | 引用保活不改变环境与线程权限 |
| unref 就是关闭资源 | 引用减计数、引用删除、原生资源关闭与在途排水分别定义 |
| TSFN 加 cleanup hook 就完整安全 | 需要完整拥有关系和退出协议，并避免与后端 RAII 重复释放 |
| TSFN 接收成功就说明业务成功 | 区分排队、执行、受理、持久化与最终结果 |
| 扫描到清理函数即可证明所有路径安全 | 启发式观察需要元数据、反例和真实运行验证补强 |
| 单元测试多数沿用 Node 就能固定评价整个后端 | 按具体版本盘点真实测试目标和设备证据，不能用历史概括替代能力清单 |
| 增加 Rust 直连不会影响现有所有权 | 重新检查业务协调、静态链接、内核实例、句柄归属与关闭职责 |

相关旧设计：[后端范围](/Users/changyue/Desktop/mad-boundary/docs/design.md:135)、[N-API 规则](/Users/changyue/Desktop/mad-boundary/docs/design.md:419)、[取消与引用表](/Users/changyue/Desktop/mad-boundary/docs/design.md:492)、[ArkTS 外观](/Users/changyue/Desktop/mad-boundary/docs/design.md:608)、[启发式实现](/Users/changyue/Desktop/mad-boundary/mad_boundary/adapters/source_analysis/napi.py:91)。
